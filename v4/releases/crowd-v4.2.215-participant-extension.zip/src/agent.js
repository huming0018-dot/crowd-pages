/* Alarm driven: each transition is durable; no long timers in a service worker. */
(function (root) {
  'use strict';
  const C = root.CrowdCore;
  class CrowdAgent {
    constructor(runtime, api) { this.r = runtime; this.api = api; this.active = null; this.generation = 0; this.recover = false; }
    async read() {
      await this.initializeGeneration();
      const owner=await this.r.owner?.();
      const s = {...C.initial(), ...await this.r.storage.get('agent')};
      if(this.r.owner && owner!==await this.r.owner())throw Error('cancelled');
      if(this.r.owner)s.owner_id=owner;
      // Old next_at remains authoritative. Only new navigations create a page wait.
      if (s.timing_version !== 1) {s.timing_version=1;s.wait_kind='legacy';s.retry_at=0;s.action_not_before=0;}
      s.run_generation = this.generation;
      return s;
    }
    async initializeGeneration() {
      const owner=this.r.owner ? await this.r.owner() : 'standalone';
      if(this.generationOwner!==owner || !this.initializing) {
        this.generationOwner=owner;
        this.initializing=(async()=>{
          const s=await this.r.storage.get('agent');
          if(this.r.owner && owner!==await this.r.owner())throw Error('cancelled');
          this.generation=Math.max(this.generation,s?.run_generation||0);
        })();
      }
      await this.initializing;
    }
    async save(s, stopping = false) {
      await this.initializeGeneration();
      const snapshot=JSON.parse(JSON.stringify(s));snapshot.run_generation ??= this.generation;
      if(this.r.owner && !Object.hasOwn(snapshot,'owner_id'))snapshot.owner_id=await this.r.owner();
      const pending=(this.writeTail||Promise.resolve()).catch(()=>{}).then(async()=>{
        if((this.stopping && !stopping) || snapshot.run_generation!==this.generation)throw Error('cancelled');
        if(this.r.owner && snapshot.owner_id!==await this.r.owner())throw Error('cancelled');
        await this.r.storage.set('agent',snapshot);
      });this.writeTail=pending;return pending;
    }
    async pageReady(target, keyword) {
      const s = await this.read();
      if (!s.enabled || s.wait_kind !== 'page' || s.last_error && !['page_loading','body_pending','content_unavailable','probe_timeout'].includes(s.last_error)) return;
      if (s.phase === 'search' ? keyword !== this.searchQuery(s) : target !== s.note_id) return;
      this.readyPending = {generation:this.generation,target,keyword};
      if (this.active) return;
      return this.tick();
    }
    keywordState(s, task=s.task) {
      let terms=task?.owner_base_keywords;
      if(task?.owner_base_task!==true)return null;
      if(terms===undefined){
        if(task.repair_only || task.repair_notes?.length || s.acceptance_supplement?.state==='admitted' || typeof task.query!=='string' || !task.query.trim())return null;
        terms=[task.query];
      }else if(!Array.isArray(terms) || terms.length<2 || terms.length>10 ||
        terms.some(x=>typeof x!=='string'||x.length<2||x.length>120||x!==x.trim()) || new Set(terms).size!==terms.length)throw Error('invalid_owner_keywords');
      const old=s.owner_keyword_search;
      const same=old?.task_id===task.id && JSON.stringify(old.terms)===JSON.stringify(terms);
      if(!same || old.lease!==task.lease_token)
        s.owner_keyword_search={task_id:task.id,lease:task.lease_token,terms:[...terms],index:0,hits:{},delivered:same?old.delivered||{}:{},page_cursor:0,link_cursor:0};
      return s.owner_keyword_search;
    }
    keywordLogKey(s) {return 'owner-keyword-pages:'+encodeURIComponent(s.owner_id||'standalone')+':'+s.task.id;}
    async keywordLog(s) {
      const state=this.keywordState(s);if(!state)return null;
      const log=await this.r.storage.get(this.keywordLogKey(s));
      if(log && (log.task_id!==s.task.id || JSON.stringify(log.terms)!==JSON.stringify(state.terms)||!Array.isArray(log.pages)||log.pages.some(page=>!page||typeof page.id!=='string'||!state.terms.includes(page.term)||!Array.isArray(page.links)||page.links.some(url=>typeof url!=='string'))))throw Error('owner_keyword_log_mismatch');
      return log||{task_id:s.task.id,terms:[...state.terms],pages:[]};
    }
    async releaseKeywordLog(s) {
      if(!s.task || !this.keywordState(s) || s.outbox?.length || s.enrichment || s.work_slots?.length)return;
      try{await this.r.storage.set(this.keywordLogKey(s),null);delete s.owner_keyword_search;}
      catch(_){s.keyword_log_cleanup_pending=s.task.id;}
    }
    async saveKeywordPage(s,links,cards=[]) {
      const state=this.keywordState(s),log=await this.keywordLog(s),id=String(state.index);
      const previous=log.pages.find(page=>page.id===id);
      const platform=C.taskPlatform(s.task),unique=new Map(),metadata={...(previous?.metadata||{})};
      for(const url of previous?.links||[])try{const item=platform.noteURL(url);unique.set(item.id,item.navigation);}catch(_){}
      for(const url of links)try{const item=platform.noteURL(url);unique.set(item.id,item.navigation);}catch(_){}
      for(const card of cards)try{const item=platform.noteURL(card.url);metadata[item.id]={title:card.title,author_display:card.author_display};}catch(_){}
      const saved=[...unique.values()];
      if(previous && saved.length===previous.links.length && saved.every((url,i)=>url===previous.links[i]) && JSON.stringify(metadata)===JSON.stringify(previous.metadata||{}))return saved;
      if(previous){previous.links=saved;previous.metadata=metadata;}else log.pages.push({id,term:state.terms[state.index],links:saved,metadata});
      try{await this.r.storage.set(this.keywordLogKey(s),log);}catch(error){throw Error(/quota|space/i.test(String(error?.message||error))?'owner_keyword_storage_full':'owner_keyword_storage_unavailable');}
      return saved;
    }
    async availableKeywordCandidates(s,known,limit) {
      const log=await this.keywordLog(s),platform=C.taskPlatform(s.task),found=new Set();
      for(const page of log.pages)for(const url of page.links){const id=platform.noteURL(url).id;
        if(!known.has(id)&&!s.seen.includes(id)&&!s.history.includes(id))found.add(id);
        if(found.size>=limit)return found.size;
      }
      return found.size;
    }
    async fillKeywordCandidates(s,known) {
      const state=this.keywordState(s),log=await this.keywordLog(s),platform=C.taskPlatform(s.task),picked=new Map();
      const single=state.terms.length===1&&!s.task.history_scope,normalize=value=>String(value||'').normalize('NFKC').toLowerCase().replace(/[\s\p{P}]/gu,'');
      state.priority_pass ||= 0;
      while(picked.size<80){
        if(state.page_cursor>=log.pages.length){if(single&&state.priority_pass===0){state.priority_pass=1;state.page_cursor=0;state.link_cursor=0;continue;}break;}
        const page=log.pages[state.page_cursor];
        while(state.link_cursor<page.links.length && picked.size<80){
          const url=page.links[state.link_cursor++],id=platform.noteURL(url).id;
          const meta=page.metadata?.[id]||{},scored=(s.task.anchor_terms||[]).some(term=>normalize(meta.title).includes(normalize(term)));
          if((!single || scored===(state.priority_pass===0))&&!known.has(id)&&!s.seen.includes(id)&&!s.history.includes(id)&&!picked.has(id))picked.set(id,{url,meta});
        }
        if(state.link_cursor>=page.links.length){state.page_cursor++;state.link_cursor=0;}
      }
      state.hits={};for(const id of picked.keys())state.hits[id]=[];
      for(const term of state.terms)for(const page of log.pages)if(page.term===term)for(const url of page.links){
        const id=platform.noteURL(url).id;if(picked.has(id)&&!state.hits[id].includes(term))state.hits[id].push(term);
      }
      const activeMeta=Object.fromEntries((s.work_slots||[]).filter(slot=>s.card_meta?.[slot.note_id]).map(slot=>[slot.note_id,s.card_meta[slot.note_id]]));
      s.card_meta={...activeMeta,...Object.fromEntries([...picked].map(([id,item])=>[id,item.meta]))};
      s.candidates=[...picked.values()].map(item=>item.url);
    }
    recordKeywordHits(s, links) {
      const state=this.keywordState(s);if(!state || state.terms.length===1)return;
      const term=state.terms[state.index],platform=C.taskPlatform(s.task);
      for(const url of links){let id;try{id=platform.noteURL(url).id;}catch(_){continue;}
        if(state.delivered?.[id] && !state.delivered[id].includes(term)){
          s.outbox ||= [];
          if(!s.outbox.some(x=>x.kind==='keyword_hit' && x.task===s.task.id && x.note_id===id && x.keyword===term))
            s.outbox.push({kind:'keyword_hit',request:this.r.uuid(),task:s.task.id,lease:s.task.lease_token,note_id:id,keyword:term});
        }
      }
    }
    keywordHits(s,id) {
      const state=this.keywordState(s);return state ? [...(state.hits[id]||[])] : [];
    }
    nextKeyword(s) {
      const state=this.keywordState(s);if(!state || state.index>=state.terms.length-1)return false;
      state.index++;return true;
    }
    historyBinding(s) {
      const installation=s.task?.node_run?.installation_id;
      if(!installation||!s.task?.lease_token||!s.task?.id)throw Error('history_recovery_required');
      return {task_id:s.task.id,installation_id:installation,lease_token:s.task.lease_token};
    }
    async verifyHistoryCheckpoint(s,alive,signal,{readOnly=false}={}) {
      const binding=this.historyBinding(s),local=s.history_progress;
      if(!local){if(readOnly)throw Error('history_recovery_required');return await this.recoverHistory(s,alive,signal);}
      if(local.task_id!==s.task.id)throw Error('history_recovery_required');
      if(!local.binding||Object.keys(binding).some(k=>local.binding[k]!==binding[k]))throw Error('history_recovery_required');
      const remote=await this.api.rpc('base_history_recovery',{p_task:binding.task_id,p_lease:binding.lease_token,p_installation:binding.installation_id},signal);alive();
      if(remote?.schema!=='crowd-base-history-recovery-v1'||!Array.isArray(remote.admitted_note_ids)||remote.admitted_note_ids.some(id=>typeof id!=='string'||!/^[a-f0-9]{24}$/.test(id))||!Number.isSafeInteger(remote.unresolved)||remote.unresolved<0)throw Error('history_recovery_required');
      const raw=await this.r.storage.get(this.keywordLogKey(s));alive();
      const log=await this.keywordLog(s),ids=new Set();
      for(const page of log.pages)for(const url of page.links)ids.add(C.taskPlatform(s.task).noteURL(url).id);
      const exact=p=>p&&Array.isArray(p.candidate_ids)&&p.candidate_ids.length===p.candidates&&new Set(p.candidate_ids).size===p.candidates&&p.candidate_ids.every(id=>ids.has(id))&&ids.size===p.candidates;
      const pending=local.pending,p=remote.progress;
      if(pending){
        if(!raw||!exact(pending)||pending.seq!==local.seq)throw Error('history_recovery_required');
        const same=p&&p.seq===pending.seq&&p.pages===pending.pages&&p.candidates===pending.candidates&&p.keyword_index===pending.keyword_index&&p.reason===pending.reason&&exact(p);
        const previous=(!p&&pending.seq===1)||(p&&p.seq===pending.seq-1&&Array.isArray(p.candidate_ids)&&p.candidate_ids.every(id=>ids.has(id)));
        if(!same&&!previous)throw Error('history_recovery_required');
        if(!readOnly)await this.historyCheckpoint(s,alive,signal);return true;
      }
      if(!p){if(local.seq!==0||ids.size||raw)throw Error('history_recovery_required');return false;}
      if(!raw||p.seq!==local.seq||p.pages!==local.pages||!exact(p))throw Error('history_recovery_required');
      return false;
    }
    async historyCheckpoint(s,alive,signal) {
      const pending=s.history_progress?.pending;
      if(!pending)return;
      const result=await this.api.rpc('base_history_progress',{p_task:s.task.id,p_lease:s.task.lease_token,p_progress:pending},signal);alive();
      if(result?.schema!=='crowd-base-history-progress-v1'||result.seq!==pending.seq)throw Error('history_progress_unavailable');
      s.history_progress.pending=null;await this.save(s);alive();
    }
    async recoverHistory(s,alive,signal) {
      const installation=s.task?.node_run?.installation_id;
      if(!installation)throw Error('history_recovery_required');
      const v=await this.api.rpc('base_history_recovery',{p_task:s.task.id,p_lease:s.task.lease_token,p_installation:installation},signal);alive();
      if(v?.schema!=='crowd-base-history-recovery-v1'||!Array.isArray(v.admitted_note_ids)||v.admitted_note_ids.some(x=>!/^[a-f0-9]{24}$/.test(x))||!Number.isSafeInteger(v.unresolved)||v.unresolved<0)throw Error('history_recovery_required');
      const state=this.keywordState(s),log=await this.keywordLog(s),ids=new Set();
      for(const p of log.pages)for(const url of p.links)ids.add(C.taskPlatform(s.task).noteURL(url).id);
      const p=v.progress;
      if(p===null){
        if(ids.size)throw Error('history_recovery_required');
        s.history_progress={task_id:s.task.id,seq:0,pages:0,pending:null,binding:this.historyBinding(s)};await this.save(s);alive();return false;
      }
      if(!p||!Number.isSafeInteger(p.seq)||p.seq<1||!Number.isSafeInteger(p.pages)||p.pages<1||!Number.isSafeInteger(p.candidates)||p.candidates<0||!Number.isSafeInteger(p.keyword_index)||p.keyword_index<0||p.keyword_index>=state.terms.length)throw Error('history_recovery_required');
      // Counters alone cannot recover URLs or a navigation checkpoint. Never
      // resume source discovery based solely on the server's page count.
      s.history_progress={task_id:s.task.id,seq:p.seq,pages:p.pages,pending:null,binding:this.historyBinding(s)};
      const exact=Array.isArray(p.candidate_ids)&&p.candidate_ids.length===p.candidates&&
        p.candidate_ids.every(id=>typeof id==='string'&&/^[a-f0-9]{24}$/.test(id))&&
        new Set(p.candidate_ids).size===p.candidate_ids.length&&p.candidate_ids.every(id=>ids.has(id))&&ids.size===p.candidates;
      if(!exact){
        s.history_recovery_blocked=true;
        await this.save(s);alive();
        throw Error('history_recovery_required');
      }
      s.seen=[...new Set([...(s.seen||[]),...v.admitted_note_ids])];
      state.index=p.keyword_index;state.page_cursor=0;state.link_cursor=0;state.priority_pass=0;
      s.history_recovered_no_search=true;s.candidates=[];s.phase='search_done';s.next_at=this.r.now();
      const pending={...p,seq:p.seq+1,reason:'recovery_partial'};
      s.history_progress={task_id:s.task.id,seq:pending.seq,pages:pending.pages,pending,binding:this.historyBinding(s)};
      await this.save(s);alive();await this.historyCheckpoint(s,alive,signal);return true;
    }
    async recordHistoryProgress(s,reason,alive,signal) {
      if(!s.history_progress){if(await this.recoverHistory(s,alive,signal))return;}
      const old=s.history_progress;
      if(old?.pending)throw Error('history_progress_unavailable');
      const state=this.keywordState(s),log=await this.keywordLog(s),unique=new Set();
      for(const p of log.pages)for(const url of p.links)try{unique.add(C.taskPlatform(s.task).noteURL(url).id);}catch(_){}
      const progress={seq:(old?.seq||0)+1,pages:(old?.pages||0)+1,candidates:unique.size,candidate_ids:[...unique].sort(),keyword_index:state.index,reason};
      s.history_progress={task_id:s.task.id,seq:progress.seq,pages:progress.pages,pending:progress,binding:this.historyBinding(s)};
      await this.save(s);alive();await this.historyCheckpoint(s,alive,signal);
    }
    searchQuery(s, task=s.task, begin=false) {
      if(!task)return task?.query;
      const multi=this.keywordState(s,task);
      if(multi && multi.terms.length>1){const query=multi.terms[multi.index];if(begin)s.search_checkpoint={task_id:task.id,task_query:task.query,platform:task.platform||'xiaohongshu',relevance_revision:task.relevance_revision||0,query};return query;}
      const g=s.acceptance_supplement,terms=task.anchor_terms;
      const anchor=Array.isArray(terms)&&terms.length===1&&typeof terms[0]==='string'?terms[0].normalize('NFC').trim():null;
      const precise=g?.schema==='crowd-acceptance-batch-v1'&&g.state==='admitted'&&g.task_id===19&&g.task_id===task.id&&Number.isSafeInteger(g.baseline_received)&&g.baseline_received>=0&&Number.isSafeInteger(g.extra_limit)&&g.extra_limit>=1&&g.extra_limit<=100&&g.target===g.baseline_received+g.extra_limit&&g.target===task.target&&Number.isSafeInteger(g.remaining)&&g.remaining>0&&g.remaining<=g.extra_limit&&anchor&&anchor.length<=200&&!/[\u0000-\u001f\u007f]/.test(anchor);
      const query=precise?anchor:task.query,revision=task.relevance_revision||0,platform=task.platform||'xiaohongshu',old=s.search_checkpoint;
      if(begin)s.search_checkpoint={task_id:task.id,task_query:task.query,platform,relevance_revision:revision,query};
      const saved=begin?s.search_checkpoint:old;
      return saved?.task_id===task.id&&saved.task_query===task.query&&saved.platform===platform&&saved.relevance_revision===revision&&(saved.query===task.query||saved.query===query)?saved.query:task.query;
    }
    acceptanceBatch(s) {
      const g=s.acceptance_supplement,t=s.task,uuid=v=>typeof v==='string'&&/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v);
      return g?.schema==='crowd-acceptance-batch-v1'&&g.state==='admitted'&&g.task_id===19&&t?.id===g.task_id&&uuid(g.id)&&uuid(g.installation_id)&&typeof s.owner_id==='string'&&!!s.owner_id&&s.owner_id===this.generationOwner&&['xiaohongshu','xhs',undefined].includes(t.platform)&&Number.isSafeInteger(g.baseline_received)&&g.baseline_received>=0&&Number.isSafeInteger(g.extra_limit)&&g.extra_limit>=1&&g.extra_limit<=100&&g.target===g.baseline_received+g.extra_limit&&t.target===g.target&&Number.isSafeInteger(t.received)&&t.received===s.received&&t.received>=g.baseline_received&&Number.isSafeInteger(g.remaining)&&g.remaining>0&&g.remaining<=g.extra_limit&&g.remaining===g.target-t.received&&t.remaining_today===g.remaining;
    }
    supplementTarget(g) {const target=g.schema==='crowd-acceptance-batch-v1'?g.target:g.baseline_received+g.extra_limit;if(!Number.isSafeInteger(target)||target<1||target>100100)throw Error('task_reconciliation_required');return target;}
    supplementGrant(value) {
      const g=value?.acceptance_supplement,uuid=v=>typeof v==='string'&&/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v);
      if(!g||typeof g!=='object'||Array.isArray(g)||!uuid(g.id)||!uuid(g.installation_id))return null;
      const batch=g.schema==='crowd-acceptance-batch-v1',keys=['schema','id','task_id','installation_id','baseline_received','extra_limit','remaining',batch?'target':'expires_at'];
      if(Object.keys(g).length!==keys.length||!keys.every(k=>Object.hasOwn(g,k)))return null;
      if(batch)return g.task_id===19&&Number.isSafeInteger(g.baseline_received)&&g.baseline_received>=0&&g.baseline_received<=100000&&Number.isSafeInteger(g.extra_limit)&&g.extra_limit>=1&&g.extra_limit<=100&&g.target===g.baseline_received+g.extra_limit&&g.target<=100100&&Number.isSafeInteger(g.remaining)&&g.remaining>=1&&g.remaining<=g.extra_limit?g:null;
      return g.schema==='crowd-acceptance-extra1-v1'&&[19,20].includes(g.task_id)&&g.baseline_received===2&&g.extra_limit===1&&g.remaining===1&&typeof g.expires_at==='string'&&Number.isFinite(Date.parse(g.expires_at))&&Date.parse(g.expires_at)>this.r.now()?g:null;
    }
    async acceptSupplement(s,value,alive) {
      const g=this.supplementGrant(value);if(!g||value.pilot_phase!=='awaiting_acceptance'||value.reason!==null||value.allowed!==true||value.paused!==false||(!['test_completed','control_unavailable'].includes(s.last_error)||s.pilot_waiting!==true)||s.pilot_phase!=='awaiting_acceptance'||s.received!==g.baseline_received||s.task||this.recoveryUnsafe(s)||s.acceptance_supplement?.id===g.id&&s.acceptance_supplement?.schema===g.schema||s.acceptance_supplement?.state==='consumed'&&g.schema!=='crowd-acceptance-batch-v1')return false;
      const owner=await this.r.owner?.(),node=await this.r.storage.get('node-monitor:'+owner),expected=await this.r.expectedPrincipal?.();alive();
      if(!owner||owner!==s.owner_id||node?.installation_id!==g.installation_id||!/^[a-f0-9]{64}$/.test(expected||''))return false;
      const health=await this.r.sourceHealth?.('xiaohongshu');alive();
      if(g.schema!=='crowd-acceptance-batch-v1'&&Date.parse(g.expires_at)<=this.r.now()||(await this.r.storage.get('node-monitor:'+owner))?.installation_id!==g.installation_id||owner!==await this.r.owner?.()||expected!==await this.r.expectedPrincipal?.()||health?.status!=='authenticated'||health.expected_ref!==expected||health.observed_ref!==expected||!Number.isSafeInteger(health.checked_at)||this.r.now()<health.checked_at||this.r.now()-health.checked_at>120000)return false;
      if(!this.r.retireSupplementPage)return false;
      await this.r.retireSupplementPage(async()=>{alive();return owner===await this.r.owner?.()&&!this.stopping&&!this.maintenance;});alive();
      s.acceptance_supplement={...g,state:'admitted',baseline_history:[...s.history],admitted_at:this.r.now()};
      s.enabled=true;s.delivery_enabled=true;s.pilot_waiting=false;delete s.pilot_check_pending;s.assignment_refresh=true;s.next_at=this.r.now();s.wait_kind=null;s.last_error=null;return true;
    }
    async checkAcceptanceSupplement(valid) {
      await this.initializeGeneration();if(this.active||this.stopping||this.maintenance)return false;
      const generation=this.generation,stop=this.stopIntent||0;
      const alive=()=>{if(generation!==this.generation||stop!==(this.stopIntent||0))throw Error('cancelled');};
      this.active=(async()=>{
        const s=await this.read();if(!await valid())return false;
        if(s.consent!==C.CONSENT||(!['test_completed','control_unavailable'].includes(s.last_error)||s.pilot_waiting!==true)||s.pilot_phase!=='awaiting_acceptance'||!Number.isSafeInteger(s.received)||s.received<0||s.task||this.recoveryUnsafe(s))return false;
        if(Number.isFinite(s.supplement_checked_at)&&this.r.now()>=s.supplement_checked_at&&this.r.now()-s.supplement_checked_at<60000)return false;
        s.supplement_checked_at=this.r.now();await this.save(s);alive();
        try{await this.control(s,'control',alive);alive();if(!await valid())return false;await this.save(s);if(s.acceptance_supplement?.state==='admitted')await this.schedule(s,this.r.now()+1000);return s.acceptance_supplement?.state==='admitted';}
        catch(error){alive();if(!await valid())return false;alive();await this.save(s);alive();return false;}
      })().finally(()=>{this.active=null;});return this.active;
    }
    async parkPilot(s, value, alive = ()=>{}) {
      if(value?.error!=='test_completed'||value.pilot_phase!=='awaiting_acceptance')return false;
      s.pilot_phase='awaiting_acceptance';s.pilot_waiting=true;delete s.pilot_check_pending;
      s.pilot_checked_at=this.r.now();s.last_error='test_completed';s.next_at=this.r.now()+60000;
      s.wait_kind='action';s.control=null;s.control_expires=0;
      await this.save(s);alive();if(s.enabled)await this.schedule(s,s.next_at);return true;
    }
    batchUnrelated(s,item,revision=null) {
      const batch=s.acceptance_supplement;
      return batch?.schema==='crowd-acceptance-batch-v1'&&batch.state==='admitted'&&item?.task===batch.task_id&&!item.kind&&item.reason==='unrelated_note'&&typeof item.request==='string'&&/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(item.request)&&typeof item.record?.standard?.note_id==='string'&&item.record.standard.note_id.length>0&&item.record.standard.note_id.length<=200&&Number.isSafeInteger(item.relevance_revision)&&item.relevance_revision>=0&&(revision===null||item.relevance_revision===revision);
    }
    rejectionNeedsReview(s) {return s.rejected.filter(item=>!this.batchUnrelated(s,item)).length>=20;}
    knownNotes(s,task) {
      const repairs=new Set((task.repair_notes||[]).filter(n=>!s.repaired?.includes(n.parent)).map(n=>n.record.standard.note_id)),known=new Set((task.known_note_ids||[]).filter(id=>!repairs.has(id)));
      for(const item of s.owner_pause_unresolved||[])if(item.task===task.id&&item.note_id)known.add(item.note_id);
      const revision=Math.max(task.relevance_revision||0,s.control_task===task.id?s.control?.relevance_revision||0:0);
      if(task.id===s.acceptance_supplement?.task_id)for(const item of s.rejected)if(this.batchUnrelated(s,item,revision)&&!repairs.has(item.record.standard.note_id))known.add(item.record.standard.note_id);
      return known;
    }
    recoveryUnsafe(s) {
      return !!(s.test_run||s.outbox?.length||s.work_slots?.length||s.pending_batch||s.pending_observation_batch||s.enrichment?.sdk_pending||s.sdk_pending||s.sdk_unknown||s.risk_report||s.pending_risk||['backend_login_required','backend_permission_denied'].includes(s.delivery_error));
    }
    async finishAcknowledgedTask(s, alive = ()=>{}, signal) {
      const ownerStopped=!!s.task&&!!s.owner_stop_reconcile&&s.owner_stop_reconcile.task_id===s.task.id&&s.owner_stop_reconcile.lease===s.task.lease_token;
      const t=s.task;
      if(!this.r.recoveryPages||!t||this.recoveryUnsafe(s)||!(ownerStopped||t.target>0&&t.received>=t.target)||t.comments_capture===true||t.structured_capture===true||t.repair_only||t.repair_notes?.length)return false;
      let mark=s.task_closure;
      if(mark&&mark.stage!=='acknowledged'&&(mark.task_id!==t.id||mark.lease!==t.lease_token))throw Error('task_reconciliation_required');
      if(mark?.stage==='pending'&&this.r.now()<mark.retry_at)return false;
      if(!mark||mark.stage==='acknowledged'){
        const snapshot={};for(const key of ['task','phase','enrichment','note_id','note_url','candidates','seen','search_round','api_capture_ledger'])snapshot[key]=s[key]??null;
        mark=s.task_closure={stage:'pending',task_id:t.id,lease:t.lease_token,snapshot,created_at:this.r.now()};
      }
      // finish is idempotent for this exact owner/task/lease. An unknown reply may
      // retry only this closure; it never creates a new assignment or source action.
      mark.retry_at=this.r.now()+60000;await this.save(s);alive();
      let result;try{result=await this.api.rpc('finish',{p_task:t.id,p_lease:t.lease_token},signal);alive();}
      catch(error){alive();if(error.status===401||error.status===403)throw error;mark.error='finish_unknown';await this.save(s);return false;}
      if(result?.status!==(ownerStopped?'closed':'complete')||!Number.isSafeInteger(result.received)||result.received<(ownerStopped?t.received:t.target)||result.error){mark.error=result?.error==='lease_lost'?'lease_lost':'task_reconciliation_required';await this.save(s);return false;}
      const archived={...mark.snapshot,closed_at:this.r.now(),receipt:{status:result.status,received:result.received,available_at:result.available_at??null},enrichment_result:mark.snapshot.enrichment?'partial_archived':'not_requested'};
      s.task_archives||=[];const previous=s.task_archives.find(a=>a.task?.id===t.id&&a.task?.lease_token===t.lease_token);
      if(previous){for(const key of Object.keys(mark.snapshot))if(JSON.stringify(previous[key])!==JSON.stringify(mark.snapshot[key]))throw Error('task_archive_conflict');}
      else s.task_archives.push(archived);
      s.task_closure={stage:'acknowledged',task_id:t.id,lease:t.lease_token,received:result.received,closed_at:this.r.now()};
      delete s.owner_stop_reconcile;
      if(result.status==='complete')await this.releaseKeywordLog(s);
      s.task=null;s.enrichment=null;s.note_id=null;s.note_url=null;s.phase='idle';s.candidates=[];s.seen=[];s.search_round=0;delete s.platform_resume_task;
      await this.save(s);alive();return true;
    }
    async reconcileLostLease(valid) {
      await this.initializeGeneration();if(this.active||this.stopping||this.maintenance)return false;
      const generation=this.generation,stop=this.stopIntent||0;
      const check=async()=>{if(generation!==this.generation||stop!==(this.stopIntent||0)||!await valid())throw Error('cancelled');};
      this.active=(async()=>{
        const s=await this.read();await check();const t=s.task;
        let mark=s.task_closure;
        const previous=mark?.purpose==='lost_lease'?mark.snapshot?.task_closure:mark,batch=s.acceptance_supplement,m=s.verification_page;
        // The historical19 extra-twenty lease is partial locally (20/22).
        // Its old complete-two ACK belongs to a different lease, never this one.
        const partial=t?.id===19&&Number.isSafeInteger(t.received)&&Number.isSafeInteger(t.target)&&t.received>=2&&t.received<t.target&&
          batch?.schema==='crowd-acceptance-batch-v1'&&batch.state==='admitted'&&batch.task_id===t.id&&batch.baseline_received===2&&batch.extra_limit===20&&t.target===22&&
          s.pilot_phase==='awaiting_acceptance'&&s.pilot_waiting===false&&!s.pilot_check_pending&&s.first_login_page?.stage==='opened'&&s.first_login_page.task_id===t.id&&
          previous?.stage==='acknowledged'&&previous.task_id===t.id&&typeof previous.lease==='string'&&previous.lease!==t.lease_token;
        if(!this.r.recoveryPages||!this.r.retireLoginPage||s.enabled||s.last_error!=='lease_lost'||s.consent!==C.CONSENT||!t||!Number.isFinite(Date.parse(t.lease_until))||Date.parse(t.lease_until)>this.r.now()||this.recoveryUnsafe(s)||s.enrichment||s.navigation_stage||s.light_processing||s.light_resume||s.owner_reply_checkpoint||s.acceptance_reconcile||s.owner_stop_reconcile||t.history_scope||!partial&&(s.note_id||s.note_url||s.acceptance_supplement))return false;
        const opening=m?.stage==='opening';
        if(m&&!['opened','confirmed'].includes(m.stage)&&!(partial&&opening&&m.manual===true))return false;
        const absent=async()=>{await check();if(!opening)return true;if(!this.r.retiredVerificationAbsent)return false;const result=await this.r.retiredVerificationAbsent(valid,JSON.parse(JSON.stringify(m)));await check();return result===true;};
        if(!await absent()){s.lease_handoff={task_id:t.id,lease:t.lease_token,state:'blocked',reason:'verification_absence_unproven',checked_at:this.r.now()};await this.save(s);return false;}
        if(mark&&mark.purpose!=='lost_lease'&&!(partial&&mark.stage==='acknowledged')||mark?.purpose==='lost_lease'&&(mark.task_id!==t.id||mark.lease!==t.lease_token))return false;
        if(mark?.retry_at>this.r.now())return false;
        if(!mark||partial&&mark.stage==='acknowledged'){
          let snapshot;
          if(partial){snapshot=JSON.parse(JSON.stringify(s));delete snapshot.task_archives;}
          else{snapshot={};for(const key of ['task','phase','enrichment','note_id','note_url','candidates','seen','search_round','api_capture_ledger','verification_page'])snapshot[key]=s[key]??null;}
          mark=s.task_closure={purpose:'lost_lease',stage:'pending',task_id:t.id,lease:t.lease_token,snapshot,partial_batch:partial,created_at:this.r.now()};
        }
        mark.retry_at=this.r.now()+60000;await this.save(s);await check();
        const status=await this.api.rpc('status');await check();if(status.participant?.status!=='approved')throw Error('approval_required');
        let result;
        try{result=await this.api.rpc('finish',{p_task:t.id,p_lease:t.lease_token});await check();}
        catch(error){await check();if(error.status===401||error.status===403)throw error;mark.error='finish_unknown';await this.save(s);return false;}
        // An expired local timestamp is not central proof. A completion/open or
        // unknown reply belongs to the existing completion/reconciliation path.
        if(result?.error!=='lease_lost'){mark.error='task_reconciliation_required';await this.save(s);return false;}
        if(!await absent()){mark.error='verification_absence_unproven';await this.save(s);return false;}
        await this.r.retireLoginPage(valid);await check();
        s.task_archives||=[];
        const retiredRejections=partial?s.rejected.filter(item=>this.batchUnrelated(s,item)):[];
        if(!s.task_archives.some(a=>a.task?.id===t.id&&a.task?.lease_token===t.lease_token))s.task_archives.push({...mark.snapshot,retired_at:this.r.now(),receipt:{status:'lease_lost',source_allowed:false},...(partial?{archive_reason:'partial_expired_supplement',retired_batch_rejection_requests:retiredRejections.map(item=>item.request),verification_absence_confirmed:opening}: {})});
        if(partial){const retired=new Set(retiredRejections);s.rejected=s.rejected.filter(item=>!retired.has(item));s.acceptance_supplement=null;s.first_login_page=null;}
        s.lease_handoff={task_id:t.id,lease:t.lease_token,state:'retired',...(partial?{target_task:32}: {})};
        // Preserve the old document/window; remove only its retired verifier
        // selection so normal passive health can observe the existing pages.
        s.verification_page=null;
        s.task=null;s.task_closure=null;s.platform_resume_task=null;s.enrichment=null;s.note_id=null;s.note_url=null;s.phase='idle';s.candidates=[];s.seen=[];s.search_round=0;s.assignment_refresh=false;this.invalidateTaskControl(s);
        s.last_error='identity_verification_required';await this.save(s);await check();return true;
      })().finally(()=>{this.active=null;});return this.active;
    }
    async claimRetiredOwnerTask(valid) {
      await this.initializeGeneration();if(this.active||this.stopping||this.maintenance)return false;
      const generation=this.generation,stop=this.stopIntent||0;
      const check=async()=>{if(generation!==this.generation||stop!==(this.stopIntent||0)||!await valid())throw Error('cancelled');};
      this.active=(async()=>{
        const s=await this.read();await check();const h=s.lease_handoff;
        if(!['retired','claimed'].includes(h?.state)||h.target_task!==32||s.enabled||s.last_error==='user_stopped'||this.recoveryUnsafe(s)||s.enrichment||s.note_id||s.note_url||s.navigation_stage)return false;
        const refresh=async()=>{
          const policy=await this.control(s,'control',()=>{if(generation!==this.generation||stop!==(this.stopIntent||0))throw Error('cancelled');});await check();
          if(policy.paused||policy.reason!==null||policy.pilot_phase!=='active'){s.enabled=false;s.last_error=policy.reason||'control_unavailable';await this.save(s);return false;}
          await this.save(s);await check();return true;
        };
        if(h.state==='claimed'){if(s.task?.id!==32||s.task.owner_base_task!==true)return false;return refresh();}
        if(s.task)return false;
        if(['sending','unknown','refused'].includes(h.claim_state))return false;
        const status=await this.api.rpc('status');await check();if(status.participant?.status!=='approved')throw Error('approval_required');
        h.claim_state='sending';await this.save(s);await check();let result;
        try{result=await this.api.rpc('claim',{p_task:32});await check();}
        catch(error){await check();h.claim_state='unknown';s.last_error='task_reconciliation_required';await this.save(s);return false;}
        const t=result?.task,node=await this.r.storage.get('node-monitor:'+s.owner_id);await check();h.claim_result=result;
        const disabled=value=>value==null||value===false||typeof value==='object'&&!Array.isArray(value)&&Object.values(value).every(disabled);
        if(result?.error||!t||t.id!==32||t.owner_base_task!==true||t.target!==3||t.received!==0||t.query!=='\u4e0a\u6d77\u5496\u5561'||!t.lease_token||!(Date.parse(t.lease_until)>this.r.now())||!node?.installation_id||t.node_run?.installation_id!==node.installation_id||t.comments_capture!==false||t.structured_capture===true||!disabled(t.light_text)||t.history_scope){
          h.claim_state='refused';s.last_error='task_reconciliation_required';await this.save(s);return false;
        }
        // This is the normal nodeMonitor-returned task/lease, never a fabricated
        // owner-base marker. Metadata assignment does not enable source work.
        s.task=t.light_text?{...t,light_text:null}:t;s.phase='idle';s.assignment_refresh=false;this.invalidateTaskControl(s);h.state='claimed';h.claim_state='known';s.last_error='identity_verification_required';await this.save(s);await check();return refresh();
      })().finally(()=>{this.active=null;});return this.active;
    }
    async reconcileCompletedTask(valid, {resumeStopped = false} = {}) {
      await this.initializeGeneration();if(this.active||this.stopping||this.maintenance)return false;
      const generation=this.generation,stop=this.stopIntent||0,alive=()=>{if(generation!==this.generation||stop!==(this.stopIntent||0))throw Error('cancelled');};
      const check=async()=>{alive();if(!await valid())throw Error('cancelled');};
      this.active=(async()=>{
        const s=await this.read();await check();
        const restarting=resumeStopped===true&&s.last_error==='user_stopped';
        if(s.consent!==C.CONSENT||['backend_login_required','backend_permission_denied','captcha','rate_limit'].includes(s.last_error)||s.last_error==='user_stopped'&&!restarting)return false;
        const ownerStopped=!!s.task&&!!s.owner_stop_reconcile&&s.owner_stop_reconcile.task_id===s.task.id&&s.owner_stop_reconcile.lease===s.task.lease_token;
        const full=(ownerStopped||s.task?.target>0&&s.task.received>=s.task.target)&&!s.task.comments_capture&&!s.task.structured_capture&&!s.task.repair_only&&!s.task.repair_notes?.length;
        if(!full&&!s.acceptance_reconcile)return false;
        if(this.recoveryUnsafe(s)){
          // Remember this explicit Start without enabling work; the queue must still be acknowledged.
          if(restarting&&full&&s.acceptance_reconcile&&s.outbox?.length&&!this.recoveryUnsafe({...s,outbox:[]})){
            s.enabled=false;s.last_error=null;await this.save(s);await check();
          }
          return false;
        }
        if(!restarting&&s.acceptance_reconcile_at&&this.r.now()<s.acceptance_reconcile_at+60000)return false;
        // Only an explicit Start releases the manual stop; finish keeps its own retry deadline.
        s.acceptance_reconcile=true;s.acceptance_reconcile_at=this.r.now();s.enabled=false;if(restarting)s.last_error=null;await this.save(s);await check();
        const status=await this.api.rpc('status');await check();if(status.participant?.status!=='approved')throw Error('approval_required');
        if(ownerStopped){
          // Recheck policy without the revoked task overriding a global pause.
          const policy=await this.api.rpc('guard',{p_action:'control',p_task:null,p_note:null});await check();
          if(policy?.error||policy?.allowed!==true||policy.paused!==false||policy.reason!==null)return false;
        }
        if(full){await this.finishAcknowledgedTask(s,alive);await check();if(s.task)return false;}
        const control=await this.control(s,'control',alive);await check();
        if(control.reason==='test_completed'&&control.pilot_phase==='awaiting_acceptance'){
          s.enabled=true;s.delivery_enabled=true;s.acceptance_reconcile=false;await this.save(s);await this.schedule(s,this.r.now()+60000);return true;
        }
        const regular=control.pilot_phase==null&&s.pilot_phase==null&&!s.pilot_waiting&&!s.pilot_check_pending;
        if((control.pilot_phase==='active'||regular)&&!control.paused&&control.reason===null){s.acceptance_reconcile=false;s.enabled=false;s.last_error='identity_verification_required';await this.save(s);return true;}
        await this.save(s);return false;
      })().finally(()=>{this.active=null;});return this.active;
    }
    async pendingAcceptanceVerification(s) {
      const a=s.acceptance_supplement;
      if(s.consent!==C.CONSENT||s.task!=null||s.phase!=='idle'||s.pilot_phase!=='awaiting_acceptance'||s.pilot_waiting!==false||s.pilot_check_pending||s.last_error!=='identity_verification_required'||s.delivery_error!=null||this.recoveryUnsafe(s)||s.enrichment!=null||s.navigation_stage!=null||s.task_closure&&s.task_closure.stage!=='acknowledged'||!Array.isArray(s.outbox)||s.outbox.length||s.work_slots!=null&&(!Array.isArray(s.work_slots)||s.work_slots.length)||a?.schema!=='crowd-acceptance-batch-v1'||a.state!=='admitted')return false;
      const wire=Object.fromEntries(['schema','id','task_id','installation_id','baseline_received','extra_limit','target','remaining'].map(k=>[k,a[k]])),g=this.supplementGrant({acceptance_supplement:wire});
      if(!g||!Number.isSafeInteger(s.received)||s.received<g.baseline_received||s.received>=g.target||g.remaining!==g.target-s.received)return false;
      const owner=await this.r.owner?.(),node=await this.r.storage.get('node-monitor:'+owner);
      return !!owner&&owner===s.owner_id&&owner===this.generationOwner&&node?.installation_id===g.installation_id&&owner===await this.r.owner?.();
    }
    async recoverLoginPage(valid,{manual=false,confirm=false,focus=manual,acceptance=false}={}) {
      await this.initializeGeneration();if(this.active||this.stopping||this.maintenance)throw Error('executor_busy');
      const generation=this.generation,stopIntent=this.stopIntent||0,owner=this.generationOwner;
      const check=async()=>{if(generation!==this.generation||stopIntent!==(this.stopIntent||0)||owner!==(await this.r.owner?.()||'standalone')||!await valid())throw Error('cancelled');};
      const alive=()=>{if(generation!==this.generation||stopIntent!==(this.stopIntent||0))throw Error('cancelled');};
      this.controller=new AbortController();const signal=this.controller.signal;
      this.active=(async()=>{
        const s=await this.read();await check();
        if(s.consent!==C.CONSENT)throw Error('consent_required');
        if(this.recoveryUnsafe(s))throw Error('task_reconciliation_required');
        const expected=await this.r.expectedPrincipal?.();if(!/^[a-f0-9]{64}$/.test(expected||''))throw Error('identity_verification_required');
        let m=s.verification_page,checkedControl=null;
        if(acceptance){
          if(manual!==true||focus!==false||confirm||!await this.pendingAcceptanceVerification(s)||!m||m.manual!==true||!['opened','confirmed'].includes(m.stage)||m.expected_ref!==expected)throw Error('identity_verification_required');
          checkedControl=await this.control(s,'control',alive,signal);await check();
          const fresh=this.supplementGrant(checkedControl),a=s.acceptance_supplement;
          if(!fresh||checkedControl.allowed!==true||checkedControl.paused!==false||checkedControl.reason!==null||checkedControl.pilot_phase!=='awaiting_acceptance'||['schema','id','task_id','installation_id','baseline_received','extra_limit','target','remaining'].some(k=>fresh[k]!==a[k])||!await this.pendingAcceptanceVerification(s))throw Error('identity_verification_required');
          if(!this.r.retireMissingVerification)throw Error('verification_page_unknown');
          await this.r.retireMissingVerification(m.slot,expected,valid);await check();
        }
        if(confirm){
          if(!m||m.stage!=='opened'||m.expected_ref!==expected)throw Error('verification_page_unknown');
          const page=await this.r.verifyPage(m.slot);await check();
          if(page?.status!=='authenticated'||page.principal_ref!==expected)throw Error(page?.status==='authenticated'?'platform_identity_changed':page?.reason||'identity_verification_required');
          if(!m.manual){
            if(!s.task||s.task.id!==m.task_id||s.task.lease_token!==m.lease||Date.parse(s.task.lease_until)<=this.r.now())throw Error('lease_lost');
            await this.r.adoptVerification(m.slot,valid);await check();s.phase='search';s.page_deadline=this.r.now()+180000;s.wait_kind='page';s.next_at=this.r.now()+1000;s.assignment_refresh=false;
          }
          m.stage='confirmed';m.confirmed_at=this.r.now();await this.save(s);return {confirmed:true,manual:m.manual};
        }
        // Only known opened/confirmed pages can advance generations; an unknown
        // creation still needs reconciliation and must never open a second page.
        if(m&&['opened','confirmed'].includes(m.stage)&&this.r.verificationCurrent&&!await this.r.verificationCurrent(m.slot)){
          await check();if(m.expected_ref!==expected)throw Error('platform_identity_changed');
          s.verification_history||=[];s.verification_history.push({...m,retired_at:this.r.now(),retired_reason:'browser_generation_changed'});m=null;
        }
        if(m?.stage==='confirmed'&&m.manual&&!manual){
          // A manually opened home page is not a task search. Preserve its proof
          // and allocate a separately admitted page only after the experiment starts.
          s.verification_history||=[];s.verification_history.push(m);m=null;
        }
        if(m){
          if(m.expected_ref!==expected)throw Error('platform_identity_changed');
          if(['opened','confirmed'].includes(m.stage)){if(manual&&focus===true)await this.r.focusVerification?.(m.slot);return {opened:true,confirmed:m.stage==='confirmed',manual:m.manual};}
          if(['claiming','admitting','opening'].includes(m.stage))throw Error('verification_page_unknown');
          if(m.stage==='blocked')throw Error(m.reason||'verification_page_unknown');
          if(m.retry_at>this.r.now())return {waiting:true,reason:m.reason,retry_at:m.retry_at};
        }
        if(!manual&&s.pilot_phase!=='active')return {waiting:true,reason:'test_completed'};
        if(!manual){s.enabled=false;s.last_error='identity_verification_required';await this.save(s);await check();}
        if(!m){m=s.verification_page={stage:'intent',slot:'verify-'+this.r.uuid(),manual,expected_ref:expected,created_at:this.r.now()};await this.save(s);await check();}
        const status=await this.api.rpc('status',{},signal);await check();if(status.participant?.status!=='approved')throw Error('approval_required');
        const control=checkedControl||await this.control(s,'control',alive,signal);await check();await this.save(s);
        const wait=async value=>{m.stage='waiting';m.reason=value.reason;m.retry_at=this.r.now()+Math.max(1000,value.wait_ms||60000);await this.save(s);return {waiting:true,reason:m.reason,retry_at:m.retry_at};};
        if(manual){
          if(control.reason&&!['test_completed','daily_quota','task_full','session_rest','action_gap','global_pause'].includes(control.reason))throw Error(control.reason);
        }else{
          if(control.pilot_phase!=='active')return await wait({reason:control.reason||'test_completed',wait_ms:60000});
          if(control.paused||control.reason)return await wait(control);
          if(s.task&&s.task.received>=s.task.target){await this.finishAcknowledgedTask(s,alive,signal);await check();}
          if(s.task&&(s.enrichment||s.note_id||s.note_url||!['idle','search'].includes(s.phase)||s.task.received>0||Date.parse(s.task.lease_until)<=this.r.now()))throw Error('task_reconciliation_required');
          if(!s.task){
            if(s.enrichment||s.note_id||s.note_url||!['idle','search'].includes(s.phase))throw Error('task_reconciliation_required');
            m.stage='claiming';await this.save(s);await check();
            const claimed=await this.api.rpc('claim',{p_task:null},signal);await check();
            if(await this.parkPilot(s,claimed,alive)){m.stage='waiting';m.reason='test_completed';m.retry_at=this.r.now()+60000;await this.save(s);return {waiting:true,reason:m.reason,retry_at:m.retry_at};}
            if(claimed?.error){m.stage='blocked';m.reason=claimed.error;await this.save(s);throw Error(claimed.error);}
            if(!claimed?.task){m.stage='waiting';m.reason='no_task';m.retry_at=this.r.now()+60000;await this.save(s);return {waiting:true,reason:m.reason,retry_at:m.retry_at};}
            const t=claimed.task;m.claimed_task=t;await this.save(s);await check();
            if(!Number.isSafeInteger(t.id)||!t.lease_token||!(Date.parse(t.lease_until)>this.r.now())||t.received!==0||!(t.target>0)||C.taskPlatform(t).id!=='xiaohongshu'||typeof t.query!=='string'||!t.query.trim())throw Error('task_reconciliation_required');
            s.task=t;s.assignment_refresh=false;await this.save(s);await check();
          }
          m.task_id=s.task.id;m.lease=s.task.lease_token;m.stage='admitting';await this.save(s);await check();
          const admission=await this.control(s,'search',alive,signal);await check();
          if(!admission.allowed||admission.paused){if(['session_rest','action_gap','global_pause','test_completed','daily_quota','task_full'].includes(admission.reason))return await wait(admission);m.stage='blocked';m.reason=admission.reason||'control_unavailable';await this.save(s);throw Error(m.reason);}
        }
        if(!manual)this.searchQuery(s,s.task,true);
        m.stage='opening';delete m.reason;delete m.retry_at;await this.save(s);await check();
        await this.r.openVerification(manual?C.HOST+'/':C.taskPlatform(s.task).searchURL(this.searchQuery(s)),m.slot,manual,valid,focus);await check();
        m.stage='opened';m.opened_at=this.r.now();await this.save(s);return {opened:true,manual};
      })().finally(()=>{this.active=null;});return this.active;
    }
    validateSupplementClaim(s,claimed) {
      if(s.acceptance_supplement?.state==='admitted'){
            const g=this.supplementGrant(claimed),a=s.acceptance_supplement,task=claimed?.task;
            if(task===null&&Object.hasOwn(claimed,'task')&&g&&['schema','id','task_id','installation_id','baseline_received','extra_limit',g.schema==='crowd-acceptance-batch-v1'?'target':'expires_at'].every(k=>g[k]===a[k])&&Number.isSafeInteger(s.received)&&Number.isSafeInteger(a.remaining)&&g.remaining===a.remaining&&g.remaining>0&&g.remaining===this.supplementTarget(g)-s.received)return;
            if(!g||['schema','id','task_id','installation_id','baseline_received','extra_limit',g.schema==='crowd-acceptance-batch-v1'?'target':'expires_at'].some(k=>g[k]!==a[k])||task?.id!==g.task_id||task.target!==this.supplementTarget(g)||!Number.isSafeInteger(task.received)||task.received!==task.target-g.remaining||task.received!==s.received||task.remaining_today!==g.remaining||!['xiaohongshu','xhs',undefined].includes(task.platform))throw Error('task_reconciliation_required');
          }
    }
    admittedBatchNote(s) { try{return this.acceptanceBatch(s)&&s.phase==='note'&&C.noteURL(s.note_url).id===s.note_id;}catch(_){return false;} }
    invalidateTaskControl(s) { s.control=null;s.control_task=null;s.control_checked=0;s.control_expires=0; }
    async control(s, action, alive, signal, note = null, detailIntent = null, lightKind = null) {
      const before = this.r.now(),requestTask=s.task?.id||null;
      const checkingSupplement=action==='control'&&s.pilot_waiting===true&&s.pilot_phase==='awaiting_acceptance'&&Number.isSafeInteger(s.received)&&s.received>=0&&!s.task&&['test_completed','control_unavailable'].includes(s.last_error);
      const recordDiagnostic=(kind,status=null,success=false,cause=null)=>{
        const now=this.r.now(),delta=now-before;
        const diagnostic={kind,http_status:Number.isInteger(status)&&status>=100&&status<=599?status:null,elapsed_ms:Number.isFinite(delta)?Math.min(300000,Math.max(0,Math.round(delta))):null,at_ms:Number.isSafeInteger(now)&&now>=0&&now<=4102444800000?now:null};
        if(kind==='local_gate_failure')diagnostic.cause=['cancelled','task_reconciliation_required','admission_rejected'].includes(cause)?cause:'local_unknown';
        s.control_diagnostic_seq=Math.min(Number.MAX_SAFE_INTEGER,(Number.isSafeInteger(s.control_diagnostic_seq)&&s.control_diagnostic_seq>=0?s.control_diagnostic_seq:0)+1);
        s.control_diagnostic=diagnostic;
        if(success)s.control_success_at=diagnostic.at_ms;else s.control_last_failure=diagnostic;
      };
      const rejectPolicy=kind=>{recordDiagnostic(kind);throw new Error('control_unavailable');};
      let value;const metrics=this.r.localTest===true&&s.test_run?.state==='active'?{}:null;
      try { value = lightKind
        ? await this.api.rpc('base_light_guard',{p_task:requestTask,p_lease:s.task.lease_token,p_installation:s.task.node_run?.installation_id,p_parent:s.detail_intent?.request,p_note:s.note_id,p_kind:lightKind},signal,metrics)
        : detailIntent
        ? await this.api.rpc('detail_admit', {p_request:detailIntent.request,p_task:requestTask,p_lease:detailIntent.lease,p_installation:detailIntent.installation,p_note:note},signal,metrics)
        : await this.api.rpc(s.task?.owner_pause_lease_v1===true&&(['search','detail','scroll'].includes(action)||action==='comment'&&s.task.root_comments?.enabled===true)?'base_guard':'guard', s.task?.owner_pause_lease_v1===true&&(['search','detail','scroll'].includes(action)||action==='comment'&&s.task.root_comments?.enabled===true)?{p_action:action,p_task:requestTask,p_lease:s.task.lease_token,p_installation:s.task.node_run?.installation_id,p_note:note}:{p_action: action, p_task: requestTask, p_note: note}, signal,metrics); }
      catch (error) {
        const known=['timeout','cancelled','network_unknown','http_4xx','http_5xx','invalid_json'];
        const d=error?.request_diagnostic;recordDiagnostic(known.includes(d?.kind)?d.kind:'network_unknown',error?.status??d?.http_status);
        if (error.status === 401 || error.status === 403) throw error; throw new Error('control_unavailable');
      }
      finally{
        if(metrics){
          metrics.control_total_ms=Math.max(0,this.r.now()-before);
          const bucket=action==='control'?'control':'source',all=s.test_run.api_timing ||= {version:1},summary=all[bucket] ||= {calls:0,stages:{}};
          if(summary.calls<10000){summary.calls++;
            for(const key of ['session_read_ms','session_ms','refresh_ms','fetch_ms','json_ms','request_ms','rpc_ms','trace_before_ms','trace_after_ms','wrapper_ms','control_total_ms']){
              const value=metrics[key];if(!Number.isSafeInteger(value)||value<0||value>1000000)continue;
              const stage=summary.stages[key] ||= {count:0,sum_ms:0,max_ms:0};stage.count++;stage.sum_ms+=value;stage.max_ms=Math.max(stage.max_ms,value);
            }
          }
        }
      }
      alive();
      if(lightKind){const scope=value?.light_scope;if(!scope||scope.task!==requestTask||scope.lease!==s.task.lease_token||scope.installation!==s.task.node_run?.installation_id||scope.parent!==s.detail_intent?.request||scope.note!==s.note_id||scope.kind!==lightKind)throw Error('light_authorization_denied');}
      if(detailIntent && value?.allowed===true && value.detail_request!==detailIntent.request)rejectPolicy('policy_schema_invalid');
      if(['awaiting_acceptance','active','closed'].includes(value?.pilot_phase))s.pilot_phase=value.pilot_phase;
      const terminal=value?.pilot_phase==='closed' && ['control','search','detail','comment','scroll'].includes(action)?'user_stopped':value?.error || (value?.allowed===false ? value.reason : null);
      if(['task_full','daily_quota','test_completed','user_stopped'].includes(terminal)) {
        recordDiagnostic('terminal_response',null,true);
        if(await this.parkPilot(s,{error:terminal,pilot_phase:value.pilot_phase},alive))return {...value,allowed:false,paused:value.paused,reason:terminal};
        s.last_error=terminal;
        if(terminal==='task_full') {s.assignment_refresh=true;s.next_at=this.r.now()+1000;}
        else if(terminal==='daily_quota') {s.assignment_refresh=true;s.next_at=C.quotaRetry(value,this.r.now());}
        else {s.delivery_enabled=s.delivery_enabled||s.enabled;s.enabled=false;await this.r.cancel();}
        s.wait_kind=terminal==='daily_quota'?'budget':'action';s.control=null;s.control_expires=0;
        await this.save(s);alive();if(!s.enabled)await this.repairDelivery();return {...value,allowed:false,paused:value.paused,reason:terminal};
      }
      if (value?.error) {recordDiagnostic('backend_error');throw new Error(value.error);}
      // A broken/older backend cannot silently disable limits. No offline page actions.
      const scoped=s.test_run?.task_ids?.includes(s.task?.id) && JSON.stringify(s.task.acceptance_task_ids)===JSON.stringify(s.test_run.task_ids);
      const configuredCap=s.task?.daily_comment_cap, configuredGap=s.task?.action_gap_milliseconds;
      const ids=s.task?.acceptance_task_ids;
      const controlRefresh=this.r.localTest===true&&action==='control'&&Array.isArray(ids)&&ids.length>=1&&ids.length<=4&&new Set(ids).size===ids.length&&ids.every(id=>Number.isSafeInteger(id)&&id>0)&&ids.includes(s.task.id);
      const extendedComments=(scoped||controlRefresh) && Number.isSafeInteger(configuredCap) && configuredCap>=1 && configuredCap<=1000;
      const minimumGap=(scoped||controlRefresh) && Number.isSafeInteger(configuredGap) && configuredGap>=250 && configuredGap<=30000?configuredGap:1000;
      const batch=this.acceptanceBatch(s);
      const scopedScroll=batch&&requestTask===s.task.id&&Number.isSafeInteger(s.task.daily_detail_cap)&&s.task.daily_detail_cap>=1&&s.task.daily_detail_cap<=200;
      const caps = {search:30, detail:batch?200:60, comment:extendedComments?Math.max(120,configuredCap):120, scroll:scopedScroll?Math.max(120,s.task.daily_detail_cap):120};
      if (!value || !Number.isSafeInteger(value.version) || value.version < 1 ||
        !Number.isSafeInteger(value.ttl_ms) || value.ttl_ms < 1 || value.ttl_ms > 600000 ||
        typeof value.paused !== 'boolean' || typeof value.allowed !== 'boolean' || (value.allowed && (value.paused || value.reason !== null)) ||
        !Number.isFinite(value.wait_ms) || value.wait_ms < 0 || value.wait_ms > 172800000 ||
        !Number.isFinite(value.gap_ms) || value.gap_ms < minimumGap || value.gap_ms > 3600000 ||
        (value.action_wait_ms != null && (!Number.isFinite(value.action_wait_ms) || value.action_wait_ms < 0 || value.action_wait_ms > 172800000)) ||
        Object.entries(caps).some(([key,max]) => !Number.isInteger(value.caps?.[key]) || value.caps[key] < 1 || value.caps[key] > max || !Number.isInteger(value.counts?.[key]) || value.counts[key] < 0))
        rejectPolicy('policy_schema_invalid');
      if(s.control && value.version < s.control.version)rejectPolicy('policy_version_regression');
      if(this.r.now()-before>30000)rejectPolicy('response_slow');
      if(this.r.now()<before)rejectPolicy('clock_regression');
      const idleRepair=this.r.localTest===true && scoped && s.enabled && s.task?.repair_only && ['waiting','active'].includes(s.test_run?.state) && s.phase==='idle' &&
        !s.outbox.length && !s.work_slots?.length && !s.enrichment && ['search','detail','comment'].every(key=>value.counts[key]<value.caps[key]);
      const clearedLocalBudget=action==='control'&&batch&&!this.recoveryUnsafe(s)&&s.wait_kind==='budget'&&s.last_error==null&&(['idle','search_done'].includes(s.phase)||this.admittedBatchNote(s))&&!s.pending_risk&&value.allowed===true&&value.reason===null&&!value.paused&&Number.isSafeInteger(s.task.daily_detail_cap)&&s.task.daily_detail_cap<=200&&value.caps.detail<=s.task.daily_detail_cap&&(value.caps.detail>s.visits||this.admittedBatchNote(s)&&value.caps.detail===s.visits)&&(value.counts.detail<value.caps.detail||this.admittedBatchNote(s)&&value.counts.detail===value.caps.detail);
      if(clearedLocalBudget){s.next_at=this.r.now();s.wait_kind=null;}
      const raisedScrollBudget=action==='control'&&scopedScroll&&s.phase==='search'&&(s.last_error==='action_budget'||(s.last_error==='pool_recovery_required'&&s.pool_failure==='entry_state'&&s.enabled===false&&Array.isArray(s.outbox)&&s.outbox.length===0&&!s.work_slots?.length&&s.enrichment==null&&s.navigation_stage==null))&&s.wait_kind==='action'&&!this.recoveryUnsafe(s)&&s.control_task===requestTask&&Number.isInteger(s.control?.caps?.scroll)&&Number.isInteger(s.control?.counts?.scroll)&&s.control.counts.scroll>=s.control.caps.scroll&&value.caps.scroll>s.control.caps.scroll&&value.caps.scroll<=s.task.daily_detail_cap&&value.counts.scroll<value.caps.scroll&&value.allowed===true&&!value.paused&&value.reason===null;
      const raisedDetailBudget=action==='control'&&batch&&s.phase==='search_done'&&s.last_error==='action_budget'&&s.wait_kind==='action'&&!this.recoveryUnsafe(s)&&s.control_task===s.task.id&&Number.isInteger(s.control?.caps?.detail)&&value.caps.detail>s.control.caps.detail&&value.counts.detail<value.caps.detail&&value.allowed===true;
      // A current server-clear retires a stale lab action wait; source risk waits remain.
      if((this.r.localTest === true || raisedDetailBudget || raisedScrollBudget || ['action_gap','session_rest','global_pause'].includes(s.last_error)) && (s.wait_kind === 'action' || idleRepair) && !s.pending_risk && !['captcha','rate_limit'].includes(s.last_error) && value.reason === null && !value.paused) {
        s.next_at=this.r.now();s.action_not_before=0;s.wait_kind=null;s.last_error=null;if(raisedDetailBudget)s.assignment_refresh=true;if(idleRepair)s.retry_at=0;
      }
      // The next attempt remains server-admitted; do not add its RPC latency to the server's interval again.
      if(value.action_wait_ms != null && value.allowed) s.action_not_before=Math.max(this.r.now(),before+value.action_wait_ms);
      // Action guards may return the legacy default; only control refreshes task rules.
      if(action!=='control') value.relevance_revision=Math.max(value.relevance_revision||0,s.task?.relevance_revision||0,s.control_task===s.task?.id?s.control?.relevance_revision||0:0);
      if(this.r.localTest===true&&value.recovery_enabled===true&&value.reason==='rate_limit'&&Number.isSafeInteger(value.recovery_wait_ms)&&value.recovery_wait_ms>=0&&value.recovery_wait_ms<=172800000){s.next_at=this.r.now()+value.recovery_wait_ms;}
      if((s.pilot_waiting===true||s.pilot_check_pending===true) && action==='control' && value.pilot_phase==='active' && value.reason===null && !value.paused && !s.pending_risk) {
        s.pilot_waiting=false;delete s.pilot_check_pending;s.assignment_refresh=true;s.next_at=this.r.now();s.wait_kind=null;s.last_error=null;
      }
      let admitted;
      if(action==='control'){
        try{admitted=await this.acceptSupplement(s,value,alive);}
        catch(error){recordDiagnostic('local_gate_failure',null,false,error?.message);throw error;}
      }
      if(checkingSupplement&&value.acceptance_supplement!=null&&admitted!==true)recordDiagnostic('local_gate_failure',null,false,'admission_rejected');
      else recordDiagnostic('ok',null,true);
      s.control = value; s.control_task=requestTask; s.control_checked = this.r.now(); s.control_expires = before + value.ttl_ms;
      s.control_error = false;
      if (['captcha','rate_limit'].includes(action)) s.pending_risk = null;
      return value;
    }
    assertTest(s) {
      if(s.test_run && ['waiting','active'].includes(s.test_run.state) && this.r.now()>=s.test_run.expires_at) throw Error('test_expired');
    }
    async pauseBodyBudget(s) {
      // Source authority ends independently of receipt delivery. Keep the
      // original task, queue and UUIDs available to the normal delivery actor.
      s.enabled=false;s.delivery_enabled=true;s.last_error='action_budget';
      await this.save(s);await this.r.cancel();await this.r.scheduleDelivery?.();
      return false;
    }
    bodyBudgetSpent(s) {
      return Object.values(s.body_capture_attempts||{}).some(b=>
        Number.isSafeInteger(b.limit)&&b.limit>0&&Array.isArray(b.requests)&&b.requests.length>=b.limit);
    }
    async admit(s, action, alive, signal, note = null) {
      if(action!=='detail'&&this.bodyBudgetSpent(s)&&!['note','reopen_note','enrich','parallel'].includes(s.phase))return this.pauseBodyBudget(s);
      this.assertTest(s);
      this.assertTest(s);await this.r.sourceHealth?.(s.task?.platform||'xiaohongshu');alive();
      let intent=null;
      if(action==='detail'&&s.task?.owner_base_task===true&&!s.task.repair_only){
        const installation=s.task.node_run?.installation_id;
        if(!installation)throw Error('node_binding_denied');
        const old=s.detail_intent;
        if(!old||old.task!==s.task.id||old.lease!==s.task.lease_token||old.installation!==installation||old.note!==note||s.phase==='reopen_note'&&old.admitted===true){
          s.detail_intent={request:this.r.uuid(),task:s.task.id,lease:s.task.lease_token,installation,note,admitted:false};
          await this.save(s);alive();
        }
        intent=s.detail_intent;
        // This bounded single-node candidate reserves at most three detail
        // attempts, including failures/reopens. A rejected body ACK cannot
        // replenish them. Persist before the central guard or browser action.
        if(!Number.isSafeInteger(s.task.target)||s.task.target<1)throw Error('task_reconciliation_required');
        s.body_capture_attempts||={};
        const budget=s.body_capture_attempts[s.task.id]||={limit:Math.min(3,s.task.target),requests:[]};
        if(!Number.isSafeInteger(budget.limit)||budget.limit<1||budget.limit>3||!Array.isArray(budget.requests)||new Set(budget.requests).size!==budget.requests.length)throw Error('task_reconciliation_required');
        if(!budget.requests.includes(intent.request)){
          if(budget.requests.length>=budget.limit)return this.pauseBodyBudget(s);
          budget.requests.push(intent.request);await this.save(s);alive();
        }
      }
      if(action==='search'&&s.phase==='idle'&&s.task?.owner_base_task===true){
        if(this.r.owner&&(!s.owner_id||!s.task.lease_token||!s.task.node_run?.installation_id))throw Error('owner_search_reconciliation_required');
        const query=this.searchQuery(s,s.task,true);
        s.owner_search_admission={state:'pending',task:s.task.id,lease:s.task.lease_token,owner:s.owner_id||null,installation:s.task.node_run?.installation_id||null,query,attempt:this.r.uuid()};
        await this.save(s);alive();
      }
      const value = await this.control(s, action, alive, signal, note, intent);
      this.assertTest(s);
      if(action==='search'&&s.owner_search_admission?.state==='pending'&&(!value.allowed||value.paused)){delete s.owner_search_admission;await this.save(s);alive();}
      if(['task_full','daily_quota','test_completed','user_stopped'].includes(value.reason)) {if(s.enabled)await this.schedule(s,s.next_at);return false;}
      if (!value.allowed || value.paused) {
        s.last_error = value.reason || 'control_unavailable';
        s.next_at = this.r.now() + Math.max(1000, value.wait_ms);
        s.wait_kind = 'action'; s.action_not_before = s.next_at;
        await this.save(s); await this.schedule(s,s.next_at); return false;
      }
      // The server has already charged this attempt, even if open/probe later fails.
      if(intent)intent.admitted=true;
      if(action==='search'&&s.owner_search_admission?.state==='pending')s.owner_search_admission.state='admitted';
      s.last_error = null; await this.save(s); alive(); return true;
    }
    async ownerPauseBeforeOpen(s, kind, alive, signal) {
      if(s.task?.owner_base_task!==true)return false;
      const current=await this.control(s,'control',alive,signal);alive();
      // A control read normally has allowed=false; action_gap reflects the
      // already-admitted action. Every other reason is a new refusal.
      const ownerPaused=current.owner_pause_requested===true&&current.paused===true;
      const refused=s.enabled!==true||current.paused===true||current.reason!==null&&current.reason!=='action_gap';
      if(!refused)return false;
      if(kind==='detail'){
        const intent=s.detail_intent,url=s.note_url,note=s.note_id;
        if(intent?.admitted!==true||intent.task!==s.task.id||intent.lease!==s.task.lease_token||intent.note!==note||!url)throw Error('task_reconciliation_required');
        s.interrupted||=[];
        if(!s.interrupted.some(x=>x.request===intent.request&&x.task===s.task.id))s.interrupted.push({task:s.task.id,request:intent.request,note_id:note,url,lease:intent.lease,installation:intent.installation,outcome:'confirmed_not_opened',action_consumed:true});
        if(!s.candidates.includes(url))s.candidates.unshift(url);
        s.seen=s.seen.filter(id=>id!==note);s.phase='search_done';s.note_id=null;s.note_url=null;s.loaded_at=null;
      }else s.phase='idle';
      if(ownerPaused){s.last_error='global_pause';s.wait_kind='action';s.next_at=this.r.now()+30000;}
      else if(!['user_stopped','task_full','daily_quota','test_completed'].includes(current.reason)){
        s.last_error=current.reason||'control_unavailable';s.delivery_enabled=s.delivery_enabled||s.enabled;s.enabled=false;
        await this.r.cancel();alive();
      }
      await this.save(s);alive();if(s.enabled)await this.schedule(s,s.next_at);return true;
    }
    async preserveOwnerPauseUnresolved(s,alive,now) {
      const intent=s.detail_intent;
      if(intent?.admitted!==true||intent.task!==s.task.id||intent.lease!==s.task.lease_token||intent.installation!==s.task.node_run?.installation_id||intent.note!==s.note_id||!s.note_url)throw Error('task_reconciliation_required');
      s.owner_pause_unresolved||=[];
      if(!s.owner_pause_unresolved.some(x=>x.request===intent.request))s.owner_pause_unresolved.push({task:s.task.id,request:intent.request,note_id:s.note_id,url:s.note_url,lease:intent.lease,installation:intent.installation,state:'unresolved'});
      if(!s.seen.includes(s.note_id))s.seen.push(s.note_id);
      s.candidates=s.candidates.filter(url=>{try{return C.noteURL(url).id!==s.note_id;}catch(_){return true;}});
      s.phase='search_done';s.note_id=null;s.note_url=null;s.loaded_at=null;s.last_error='owner_pause_unresolved';s.next_at=now;
      await this.save(s);alive();
    }
    detailRequest(s) {
      const i=s.detail_intent;
      return i?.admitted===true&&i.task===s.task?.id&&i.lease===s.task?.lease_token&&i.note===s.note_id
        ?i.request:this.r.uuid();
    }
    async preferences() {
      const owner = await this.r.owner?.() || 'standalone';
      const value = await this.r.storage.get('agent-settings:' + owner);
      return value?.owner === owner && [1,2].includes(value.parallelism) ? value : null;
    }
    async requestParallelism(value) {
      await this.initializeGeneration();const owner=this.generationOwner,generation=this.generation;
      if (![1,2].includes(value) || value === 2 && !await this.r.poolAllowed?.()) throw Error('parallel_unavailable');
      if(generation!==this.generation || owner!==(await this.r.owner?.() || 'standalone'))throw Error('cancelled');
      await this.r.storage.set('agent-settings:' + owner, {owner,parallelism:value});
      // Preference IO never rewrites the actor's live state or its evidence queue.
      if (!this.active && !this.stopping && !this.maintenance) {
        this.active = (async()=>{const s=await this.read();await this.applyPreferences(s);})().finally(()=>{this.active=null;});
        await this.active;
      }
    }
    async applyPreferences(s) {
      if (s.outbox.length || s.work_slots?.length || s.enrichment || s.enabled && !['idle','search_done'].includes(s.phase)) return;
      const value=await this.preferences();
      if (value && value.parallelism !== (s.parallelism || 1)) {
        if (value.parallelism === 2 && !await this.r.poolAllowed?.()) return;
        s.parallelism=value.parallelism;await this.save(s);
      }
    }
    async schedule(s, at, replace = false) {
      if(s.test_run && ['waiting','active'].includes(s.test_run.state)) at=Math.min(at,s.test_run.expires_at);
      if(s.wait_kind==='action') {
        const now=this.r.now(),recheck=(s.control_checked||now)+30000;
        at=Math.min(at,recheck>now?recheck:now+30000);
      }
      return this.r.schedule(at,replace);
    }
    testGoal(s) {return s.test_run?.goal ?? 2;}
    claimTask(s) {return (s.acceptance_supplement?.state==='admitted'?s.acceptance_supplement.task_id:null) || s.task?.id || s.test_run?.task_ids?.find(id=>!s.test_run.finished_tasks?.includes(id)) || null;}
    bindBatch(s,task,expected=null) {
      if(!s.test_run)return true;
      const ids=task?.acceptance_task_ids;
      if(ids!=null) {
        if(!Array.isArray(ids) || ids.length<1 || ids.length>4 || new Set(ids).size!==ids.length || ids.some(id=>!Number.isSafeInteger(id)||id<1) || !ids.includes(task.id))return false;
        s.test_run.task_ids ||= ids.slice();
      }
      const valid=!s.test_run.task_ids || !!task && JSON.stringify(ids)===JSON.stringify(s.test_run.task_ids) && s.test_run.task_ids.includes(task.id) && !s.test_run.finished_tasks?.includes(task.id) && (expected===null || task.id===expected);
      if(valid&&s.test_run.state==='active'&&s.test_run.goal===0&&!task?.repair_only&&!s.test_run.finished_tasks?.length)return false;
      if(valid&&s.test_run.state==='active'&&s.test_run.goal===0&&s.test_run.finished_tasks?.length&&!task?.repair_only&&Number.isInteger(task?.acceptance_goal)&&task.acceptance_goal>=1&&task.acceptance_goal<=4){
        if(s.outbox.length||s.work_slots?.length||s.enrichment)return false;
        if(s.test_run.attempts+task.acceptance_goal*2>8||s.test_run.accepted.length+task.acceptance_goal>4)return false;
        s.test_run.goal=s.test_run.accepted.length+task.acceptance_goal;s.test_run.limit=s.test_run.attempts+task.acceptance_goal*2;
      }
      return valid;
    }
    batchContinues(s) {return s.test_run?.state==='active' && s.test_run.task_ids?.length>1 && (s.test_run.goal===0 ? s.test_run.task_ids.some(id=>id!==s.task?.id && !s.test_run.finished_tasks?.includes(id)) : s.test_run.accepted.length<this.testGoal(s));}
    testResult(s) {
      const completeAPI=this.r.experimentalAPIEarlyFinish===true && this.r.localTest===true &&
        s.owner_id==='7033ff0c-65d7-4963-b65c-a4ac9e31f03a' && s.enabled===true && s.test_run?.state==='active' && !!s.test_run.id && !s.outbox?.length &&
        s.task?.structured_capture===true && Date.parse(s.task.lease_until)>this.r.now() && !s.pending_risk && !s.control?.paused &&
        !['sending','unknown'].includes(s.risk_report?.state) &&
        !['captcha','rate_limit','login_required','backend_login_required'].includes(s.last_error) &&
        !s.comment_validation_failed && !!s.comment_coverage?.length && s.comment_coverage.every(c=>c.complete ||
          c.capture_reason==='api_graph_closed_dom_subset' && s.api_capture_ledger?.some(l=>
            l.parent===c.parent && l.owner===s.owner_id && l.test===s.test_run.id && l.task===s.task?.id &&
            l.note===c.note_id && l.lease===s.task?.lease_token && this.experimentalLedgerComplete(l)));
      return s.comment_failures || s.comment_partial&&!completeAPI || s.structured_partial ||
        (s.task?.repair_notes||[]).some(n=>!s.repaired?.includes(n.parent))?'test_comments_partial':'test_completed';
    }
    experimentalLedgerComplete(l) {
      const uuid=v=>typeof v==='string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v);
      if(!l || !uuid(l.run) || !uuid(l.parent) || !uuid(l.body_request) || !uuid(l.body_run) ||
        l.confirmed_parent!==l.parent || !l.body_ack || !Array.isArray(l.pages) || l.pages.length<1 || l.pages.length>200)return false;
      const b=l.body_ack;
      if(b.request!==l.body_request || b.run!==l.body_run || b.page!==0 || b.source!=='page_hydration' ||
        b.note!==l.note || b.parent!==l.parent || b.task!==l.task || b.lease!==l.lease || b.reward_eligible!==false)return false;
      return new Set(l.pages.map(p=>p.request)).size===l.pages.length && new Set(l.pages.map(p=>p.page)).size===l.pages.length &&
        l.pages.every(p=>uuid(p.request) && p.total===l.pages.length && Number.isInteger(p.page) && p.page>=0 && p.page<l.pages.length &&
          p.acked_request===p.request && p.acked_run===l.run && p.acked_page===p.page && p.acked_source==='page_response' &&
          p.acked_parent===l.parent && p.acked_note===l.note && p.acked_task===l.task && p.acked_lease===l.lease && p.acked_reward_eligible===false);
    }
    acknowledgeExperimentalAPI(s,item,receipt) {
      if(this.r.experimentalAPIEarlyFinish!==true || item.kind!=='structured' || receipt?.gate!=='observed')return;
      const l=s.api_capture_ledger?.find(l=>l.parent===item.parent && l.owner===s.owner_id && l.test===s.test_run?.id &&
        l.task===item.task && l.lease===item.lease && l.note===item.record.note_id);
      if(!l)return;
      if(item.record.kind==='body' && l.body_request===item.request && l.body_run===receipt.run) {
        l.body_ack={request:receipt.request,run:receipt.run,page:receipt.page,source:receipt.source,reward_eligible:receipt.reward_eligible,
          parent:item.parent,note:item.record.note_id,task:item.task,lease:item.lease};
      }
      if(item.record.kind==='comments' && item.record.run===l.run) {
        const p=l.pages.find(p=>p.request===item.request && p.page===item.record.page && p.total===item.record.total);
        if(p){Object.assign(p,{acked_request:receipt.request,acked_run:receipt.run,acked_page:receipt.page,acked_source:receipt.source,
          acked_reward_eligible:receipt.reward_eligible,acked_parent:item.parent,acked_note:item.record.note_id,acked_task:item.task,acked_lease:item.lease});
          // The existing receiver checks the accepted original parent proof before returning observed.
          l.confirmed_parent=item.parent;}
      }
      l.complete=this.experimentalLedgerComplete(l);
    }
    testRemaining(s) {
      if (!s.test_run || !['waiting','active'].includes(s.test_run.state)) return s.test_run ? 0 : Infinity;
      const inflight = (s.work_slots || []).filter(slot => slot.phase !== 'done' && !slot.base_received).length;
      return s.test_run.state === 'waiting' ? 0 : Math.max(0, Math.min(s.test_run.limit-s.test_run.attempts, this.testGoal(s)-s.test_run.accepted.length-inflight));
    }
    async endTest(s, reason, {drain = true} = {}) {
      s.test_run.state=reason==='test_completed'?'complete':'stopped';
      s.test_run.reason=reason;s.test_run.ended_at=this.r.now();
      s.enabled=false;s.delivery_enabled=drain;s.last_error=reason;
      if(!drain)s.delivery_error=reason;
      await this.save(s);
      // Stop waits for the writer. Defer cleanup until tick releases that writer.
      this.testStop={generation:this.generation,reason,drain,keepPage:!drain};
    }
    async start(test = false, {valid = async()=>true, resumePlatform = false, resumeInitial = false} = {}) {
      const stopIntent=this.stopIntent || 0,requested=valid;
      valid=async()=>stopIntent===(this.stopIntent || 0) && await requested();
      test = test || this.r.localTest === true;
      await this.initializeGeneration();
      if(!await valid())throw Error('cancelled');
      const owner=this.generationOwner,generation=this.generation;
      if (test && !await this.r.poolAllowed?.()) throw Error('parallel_unavailable');
      if(generation!==this.generation || owner!==(await this.r.owner?.() || 'standalone'))throw Error('cancelled');
      if(this.stopping)throw Error('executor_busy');
      if (this.maintenance) throw new Error('update_in_progress');
      await this.active?.catch(() => {});
      if (this.maintenance) throw new Error('update_in_progress');
      if (generation !== this.generation || owner!==(await this.r.owner?.() || 'standalone')) throw new Error('cancelled');
      // Hold the same single-writer lock while status IO is pending.
      if (this.active) return this.start(test,{valid,resumePlatform,resumeInitial});
      const prior = await this.read();
      // A free lock cannot prove that an unacknowledged native process will not
      // start later. Preserve the uncertainty rather than replaying the work.
      if(prior.light_stop_unsettled===true)throw Error('native_stop_unknown');
      if(prior.light_source_unsettled===true||['audio_probe_running','image_probe_running'].includes(prior.light_processing?.stage))throw Error('light_source_unknown');
      if(['opening','unknown'].includes(prior.light_resume?.state))throw Error('light_source_unknown');
      if(prior.owner_reply_checkpoint&&!(['admitted','opened'].includes(prior.owner_reply_checkpoint.state)&&prior.task?.lease_token===prior.owner_reply_checkpoint.new_lease&&prior.phase==='reply_reopen'))throw Error(['unknown','opening'].includes(prior.owner_reply_checkpoint.state)?'reply_action_unknown':'reply_resume_unavailable');
      if(['sending','unknown'].includes(prior.sdk_pending?.status))throw Error('sdk_unknown');
      if(prior.sdk_unknown===true)throw Error('sdk_unknown');
      if(['sending','unknown'].includes(prior.risk_report?.state))throw Error('risk_report_unknown');
      if (generation !== this.generation || !await valid()) throw Error('cancelled');
      if (this.maintenance) throw Error('update_in_progress');
      if (this.stopping) throw Error('executor_busy');
      if (this.active) return this.start(test,{valid,resumePlatform,resumeInitial});
      if (test && prior.test_run && ['waiting','active'].includes(prior.test_run.state) && this.r.now() >= prior.test_run.expires_at) {
        // An explicit new test retires expired work before opening its new boundary.
        // Stop preserves original delivery UUIDs; no old page is reopened here.
        await this.stop('test_expired',{drain:true,restart:true});
        if(!await valid())throw Error('cancelled');
        return this.start(test,{valid,resumePlatform,resumeInitial});
      }
      this.active = this.activate(generation,test,valid,resumePlatform,resumeInitial).finally(() => { this.active = null;const stop=this.testStop;this.testStop=null;if(stop?.generation===this.generation)this.stop(stop.reason,{drain:stop.drain!==false,keepPage:stop.keepPage===true}).catch(()=>{}); });
      return this.active;
    }
    async activate(generation, test = false, valid = async()=>true, resumePlatform = false, resumeInitial = false) {
      const s = await this.read();
      // A page that could not be saved must be retried in place; reopening a
      // search could replace its still-unrecorded observed candidates.
      if(['owner_keyword_storage_full','owner_keyword_storage_unavailable'].includes(s.last_error)&&s.phase==='search'&&s.task)resumePlatform=true;
      if (s.consent !== C.CONSENT) throw new Error('consent_required');
      if(s.test_run && ['waiting','active'].includes(s.test_run.state) && this.r.now()>=s.test_run.expires_at){await this.endTest(s,'test_expired');return;}
      await this.r.sourceHealth?.(s.task?.platform||'xiaohongshu');if(generation!==this.generation || !await valid())throw new Error('cancelled');
      const status = await this.api.rpc('status');
      if (generation !== this.generation || !await valid()) throw new Error('cancelled');
      if (status.participant?.status !== 'approved') throw new Error('approval_required');
      // Refresh risk policy before allocating an automatic or explicit new batch.
      const validOwner=()=>{if(generation!==this.generation)throw Error('cancelled');};
      const admission=await this.control(s,'control',validOwner);
      if(generation!==this.generation || this.generationOwner!==(await this.r.owner?.() || 'standalone') || !await valid())throw Error('cancelled');
      if(admission.allowed===false&&admission.paused===false&&admission.reason==='user_stopped'&&s.task&&!s.test_run&&!s.pilot_phase&&!s.task.comments_capture&&!s.task.structured_capture&&!s.task.repair_only&&!s.task.repair_notes?.length){
        // Refusal is only a reconciliation hint. Only finish(closed) can retire this lease.
        s.owner_stop_reconcile={task_id:s.task.id,lease:s.task.lease_token};
        s.acceptance_reconcile=true;s.enabled=false;s.delivery_enabled=true;s.last_error='owner_task_stopped';
        await this.save(s);await this.repairDelivery();return;
      }
      if(admission.paused || admission.reason!==null&&!(['admitted','opened'].includes(s.owner_reply_checkpoint?.state)&&admission.reason==='action_gap')){
        const parking=['task_full','daily_quota'].includes(admission.reason) || admission.reason==='test_completed'&&admission.pilot_phase==='awaiting_acceptance';
        s.enabled=parking;s.last_error=admission.reason||'control_unavailable';
        if(parking){s.delivery_enabled=true;await this.save(s);await this.schedule(s,s.next_at);}
        else{s.next_at=Math.max(s.next_at||0,this.r.now()+admission.wait_ms);if(['session_rest','action_gap','global_pause'].includes(s.last_error)){s.wait_kind='action';s.action_not_before=s.next_at;}await this.save(s);}
        return;
      }

      // Every explicit resume reconciles the assignment after durable deliveries.
      s.assignment_refresh = true;
      if(resumePlatform&&s.task){
        const empty=resumeInitial&&!s.received&&!s.note_id&&!s.note_url&&!s.enrichment&&!s.sdk_pending&&!s.sdk_unknown&&!s.risk_report&&['idle','search'].includes(s.phase)&&![s.outbox,s.rejected,s.history,s.seen,s.candidates,s.work_slots].some(a=>a?.length);
        s.platform_resume_task={id:s.task.id,lease:s.task.lease_token,allow_renewal:empty===true};
      }else delete s.platform_resume_task;
      if (test) {
        if (!s.test_run || !['waiting','active'].includes(s.test_run.state)) {
          s.comment_failures=0;s.comment_partial=false;s.structured_partial=false;s.comment_coverage=[];s.repaired=[];s.api_capture_ledger=[];s.comment_validation_failed=false;s.test_run={id:this.r.uuid(),limit:4,attempts:0,accepted:[],state:'waiting',created_at:this.r.now(),expires_at:Math.min(this.r.now()+900000,Math.floor((this.r.now()+8*3600000)/86400000)*86400000+86400000-8*3600000),day:new Date(this.r.now()+8*3600000).toISOString().slice(0,10)};
        }
        // Adding a test boundary must not restart a running page or change its UUID.
        if (s.enabled) {await this.save(s);await this.schedule(s,this.r.now()+1000);return;}
      } else if (s.test_run && !['waiting','active'].includes(s.test_run.state)) {
        // A completed/stopped bounded run never silently becomes unlimited.
        throw Error('test_new_run_required');
      }
      if(['admitted','opened'].includes(s.light_resume?.state)){
        const p=s.light_resume;if(!s.task||p.owner!==this.outboxOwner(s)||p.task!==s.task.id||p.lease!==s.task.lease_token||p.installation!==s.task.node_run?.installation_id)throw Error('light_checkpoint_mismatch');
        s.platform_resume_task={id:p.task,lease:p.lease,allow_renewal:false};
      } else if(s.light_resume?.state==='acked'){
        const p=s.light_resume;
        if(!s.task||p.owner!==this.outboxOwner(s)||p.task!==s.task.id||p.lease!==s.task.lease_token||p.installation!==s.task.node_run?.installation_id||s.outbox.length||s.enrichment)throw Error('light_checkpoint_mismatch');
        s.platform_resume_task={id:p.task,lease:p.lease,allow_renewal:false};s.phase='light_resume';
      } else if (!resumePlatform) {
        // Continue retains the original enrichment checkpoint; enrich validates
        // its lease and page before performing the next action.
        if (s.phase === 'note'&&!s.light_processing) s.phase = 'reopen_note';
        if (s.phase === 'search' && !['sending','sent','confirmed'].includes(s.owner_search_admission?.state)) { s.phase = 'idle'; s.search_round = 0; }
      } else {
        // The same verified page resumes its checkpoint, never a second search/detail admission.
        if(['search','note','reopen_note'].includes(s.phase))s.page_deadline=this.r.now()+180000;
        if(s.phase==='note'){s.loaded_at=this.r.now();s.scrolls=0;}
      }
      s.enabled = true; s.delivery_enabled = true; s.delivery_error = null; s.last_error = null; s.page_failures = 0; s.control_checked = 0; s.last_tick = this.r.now();
      if(s.lease_handoff?.state==='claimed'&&s.task?.id===32)s.lease_handoff.state='assigned';
      // Continuing never clears a durable deadline or a pending risk report.
      await this.save(s); await this.schedule(s,this.r.now() + 1000);
    }
    async bootstrapLoginPage(valid, resumeKnownWait = false, resumeStoppedWait = false) {
      await this.initializeGeneration();
      if(this.active||this.stopping||this.maintenance)throw Error('executor_busy');
      const generation=this.generation,stopIntent=this.stopIntent||0;
      const alive=()=>{if(generation!==this.generation||stopIntent!==(this.stopIntent||0))throw Error('cancelled');};
      const check=async()=>{alive();if(!await valid())throw Error('cancelled');};
      this.controller=new AbortController();const signal=this.controller.signal;
      this.active=(async()=>{
        const s=await this.read();await check();
        const waits=new Set(['session_rest','action_gap','global_pause']),mark=s.first_login_page;
        const stoppedWait=resumeStoppedWait&&s.last_error==='user_stopped'&&mark?.stage==='waiting'&&waits.has(mark.reason);
        const retry=resumeKnownWait&&mark?.task_id===s.task?.id&&['admitting','waiting'].includes(mark?.stage)&&(waits.has(s.last_error)||stoppedWait);
        if(s.consent!==C.CONSENT||s.enabled||!s.task||(!retry&&(!['login_required','identity_verification_required'].includes(s.last_error)||mark))||s.received||s.note_id||s.note_url||s.enrichment||s.test_run||s.sdk_unknown||s.sdk_pending||s.risk_report||s.pending_risk||!['idle','search'].includes(s.phase)||[s.outbox,s.rejected,s.history,s.seen,s.candidates,s.work_slots].some(a=>a?.length))throw Error('pool_recovery_required');
        const wait=async admission=>{
          if(!waits.has(admission.reason)||!Number.isFinite(admission.wait_ms)||admission.wait_ms<0)throw Error(admission.reason||'control_unavailable');
          const retry_at=this.r.now()+Math.max(1000,admission.wait_ms);
          s.first_login_page={stage:'waiting',task_id:s.task.id,reason:admission.reason,retry_at};
          s.enabled=false;s.last_error=admission.reason;s.next_at=Math.max(s.next_at||0,retry_at);s.wait_kind='action';s.action_not_before=s.next_at;
          await this.save(s);await check();return {waiting:true,reason:admission.reason,retry_at};
        };
        if(retry){
          // Only the explicit Continue restores intent after a user stop. The known deadline still applies.
          if(stoppedWait){s.last_error=mark.reason;await this.save(s);await check();}
          if(mark.stage==='waiting'&&Number.isFinite(mark.retry_at)&&mark.retry_at>this.r.now())return {waiting:true,reason:s.last_error,retry_at:mark.retry_at};
          // A 63 definite refusal did not persist its guard reply. Read control
          // again; never treat the old control snapshot as a source receipt.
          s.first_login_page={stage:'checking_wait',task_id:s.task.id};await this.save(s);await check();
          const current=await this.control(s,'control',alive,signal);await check();
          if(current.reason||current.paused)return wait(current);
          // control's allowed=false is expected: only search can grant a visit.
        }
        // Durable intent precedes any RPC/navigation; a crashed or unknown attempt never repeats.
        s.first_login_page={stage:'claiming',task_id:s.task.id};await this.save(s);await check();
        const status=await this.api.rpc('status',{},signal);await check();
        if(status.participant?.status!=='approved')throw Error('approval_required');
        const claimed=await this.api.rpc('claim',{p_task:s.task.id},signal);await check();
        if(claimed.error==='test_completed'&&claimed.pilot_phase==='awaiting_acceptance'){s.enabled=true;await this.parkPilot(s,claimed,alive);return {pilot_waiting:true};}
        if(claimed.error)throw Error(claimed.error);
        const task=claimed.task;
        if(task?.id!==s.task.id||task.query!==s.task.query||task.platform!==s.task.platform||task.received!==0)throw Error('lease_lost');
        s.task=task;s.first_login_page.stage='admitting';await this.save(s);await check();
        const admission=await this.control(s,'search',alive,signal);await check();
        if(!admission.allowed||admission.paused||admission.reason)return wait(admission);
        this.searchQuery(s,task,true);s.first_login_page.stage='opening';await this.save(s);await check();
        // Retire metadata only. An old tab ID from another browser session is never touched.
        await this.r.retireLoginPage(valid);await check();
        await this.r.open(C.taskPlatform(task).searchURL(this.searchQuery(s,task)));await check();
        s.phase='search';s.search_round=0;s.page_deadline=this.r.now()+180000;s.next_at=this.r.now()+1000;s.wait_kind='page';
        s.enabled=false;s.last_error='identity_verification_required';s.first_login_page.stage='opened';
        await this.save(s);return;
      })().finally(()=>{this.active=null;});
      return this.active;
    }
    async stop(reason = 'user_stopped', options = {}) {
      if(!options.restart && !options.stoppedCheckpoint)this.stopIntent=(this.stopIntent || 0)+1;
      if(this.stopActive)return this.stopActive;
      this.stopActive=this.performStop(reason,options).finally(()=>{this.stopping=false;this.stopActive=null;});return this.stopActive;
    }
    async performStop(reason, {keepPage = false, drain = false, expectedOwner = null, stoppedCheckpoint = false} = {}) {
      const stopOwner=expectedOwner || await this.r.owner?.() || (await this.r.storage.get('session'))?.user?.id;
      const sameOwner=async()=>!stopOwner || stopOwner===(await this.r.owner?.() || (await this.r.storage.get('session'))?.user?.id);
      if(!await sameOwner())return;
      if(stoppedCheckpoint) {
        const checkpoint=await this.read();
        if(!await sameOwner())return;
        if(checkpoint.enabled || checkpoint.outbox?.length || checkpoint.work_slots?.some(slot=>slot.request && slot.base_received!==true) || this.active || this.poolJobs?.size)return;
      }
      this.stopping=true;await this.initializeGeneration();
      this.generation++; this.controller?.abort();this.readyPending=null;this.poolWake=false;this.poolResults?.clear();
      await this.writeTail?.catch(()=>{});
      if(!await sameOwner())return;
      const s = expectedOwner?{...C.initial(),...await this.r.storage.get('agent:'+expectedOwner)}:await this.read(); s.enabled = false; s.delivery_enabled = drain; s.last_error = reason;
      if(s.test_run && ['waiting','active'].includes(s.test_run.state)) {s.test_run.state='stopped';s.test_run.reason=reason;s.test_run.ended_at=this.r.now();}
      s.run_generation=this.generation;
      if(['captcha','rate_limit'].includes(reason)){s.pending_risk=reason;s.next_at=Math.max(s.next_at,this.r.now()+(reason==='rate_limit'?86400000:1800000));}
      // Optional supplements must never prevent the durable stop.
      if(expectedOwner)await this.r.storage.set('agent:'+expectedOwner,s);else await this.save(s,true);
      if(s.enrichment?.root_only)this.queueRootComments(s,s.enrichment,s.enrichment.action_pending?'unknown':'interrupted');
      for(const slot of [...(s.work_slots||[]),...(this.r.localTest===true && s.enrichment?[{enrichment:s.enrichment}]:[])]) {
        const e=slot.enrichment;
        if(e?.record?.extra?.comments && !e.note_queued)this.queueCommentPages(s,e,'interrupted');
        if(e&&!e.structured_queued)this.queueStructuredPages(s,e,'interrupted');
        if(e?.record?.extra?.comments && !e.note_queued && !e.repair) {
          const item={kind:'note',request:this.r.uuid(),parent:e.parent,record:JSON.parse(JSON.stringify(e.record))};
          try {
            item.record=this.legacyCommentNote(item.record);
            C.validate(item.record);this.pushOutbox(s,item);
          } catch(error) {s.rejected.push({...item,reason:error.message||'invalid_record'});}
          e.note_queued=true;
        }
      }
      if(expectedOwner)await this.r.storage.set('agent:'+expectedOwner,s);else await this.save(s,true);
      if((s.light_processing?.stage==='audio_probe_running'||s.light_processing?.audio_source_kind==='remote_video')&&this.r.cancelLightSource){try{await this.r.cancelLightSource();}catch(_){this.lightSourceUnknown=true;}}
      // A worker lost during cancellation must restart into the durable stop.
      await this.active?.catch(() => {});
      await Promise.allSettled([...(this.poolJobs?.values()||[])]);
      if(!await sameOwner())return;
      if(this.lightCancelled){const state=await this.read(),p=state.light_processing;
        if(p?.stage_id===this.lightCancelled.id&&p.stage===this.lightCancelled.stage&&p.owner===this.outboxOwner(state)){(p.cancelled_ids||=[]).push(p.stage_id);delete p.stage_id;p.stage='observed';await this.save(state,true);}
        this.lightCancelled=null;
      }
      {const state=await this.read(),p=state.light_processing;if(p?.stage==='observed'&&p.audio_source_kind==='remote_audio'&&(p.audio_started||p.audio_admitted)){delete p.audio_admitted;delete p.audio_request;delete p.audio_started;if(!(p.asr_next>0))delete p.audio_ref;await this.save(state,true);}}
      if(this.lightStopUnknown){const state=await this.read();state.light_stop_unsettled=true;state.last_error='native_stop_unknown';await this.save(state,true);}
      if(this.lightSourceUnknown){const state=await this.read();state.light_source_unsettled=true;state.last_error='light_source_unknown';await this.save(state,true);}
      try {
        await this.r.cancel();
        if(!await sameOwner())return;
        if (!keepPage) {
          try {await this.r.close(stopOwner||expectedOwner);}catch(error){
            // A lost page must not retain live work or block its already durable outbox.
            if(await sameOwner()) {
              const failed=await this.read();failed.pool_cleanup_error=error.poolCause||'unknown';await this.save(failed,true);
            }
          }
          if(!await sameOwner())return;
          const settled=await this.read();
          if(!await sameOwner())return;
          if(this.r.localTest===true && settled.enrichment?.note_queued) {
            settled.enrichment=null;
            if(settled.phase==='enrich')settled.phase='search_done';
            await this.save(settled,true);
          }
          if(settled.work_slots?.length) {
            settled.interrupted ||= [];
            for(const slot of settled.work_slots)settled.interrupted.push({task:slot.task,note_id:slot.note_id||slot.enrichment?.record?.standard?.note_id,attempt:slot.id,request:slot.request||null,reason,action_consumed:true,outcome:slot.base_received?'base_received_supplement_stopped':slot.request?'delivery_unknown':'confirmed_abandoned'});
            settled.work_slots=[];if(settled.phase==='parallel')settled.phase='search_done';
            await this.save(settled,true);
          }
          if(settled.test_run && ['note','reopen_note','search'].includes(settled.phase)) {
            if(settled.note_id){settled.interrupted ||= [];settled.interrupted.push({task:settled.task?.id,note_id:settled.note_id,test_run_id:settled.note_test_run || null,reason,action_consumed:true,outcome:'confirmed_abandoned'});}
            // Closed, unsubmitted test pages are retired, never reopened outside the next batch's cap.
            settled.phase=settled.task && settled.candidates.length?'search_done':'idle';
            settled.note_id=null;settled.note_url=null;settled.note_test_run=null;settled.wait_kind=null;
            await this.save(settled,true);
          }
        }
      }
      finally {try {
        if(await sameOwner())await this.repairDelivery();
      }finally{this.stopping=false;}}
      if(this.lightStopUnknown)throw Error('native_stop_unknown');
      if(this.lightSourceUnknown)throw Error('light_source_unknown');
    }
    async tick(recover = false, deliveryOnly = false) {
      if (this.maintenance || this.stopping) return;
      await this.initializeGeneration();
      if(this.stopping)return;
      this.recover ||= recover;
      if (this.active) return this.active;
      this.controller = new AbortController();
      const gen = this.generation;
      const alive = () => { if (gen !== this.generation || this.controller.signal.aborted) throw new Error('cancelled'); };
      this.active = (async () => {
        // Drain ready local transitions under the same writer; never recurse into tick().
        for (let turns = 0; turns < 4; turns++) {
          this.poolWake=false;
          if (!await this.step(alive, this.controller.signal, deliveryOnly)) break;
        }
      })().finally(() => {
        this.active = null;
        const stop=this.testStop;this.testStop=null;
        if(stop?.generation===this.generation){this.stop(stop.reason,{drain:stop.drain!==false,keepPage:stop.keepPage===true}).catch(()=>{});return;}
        if(this.poolWake && !this.stopping){this.poolWake=false;this.tick().catch(()=>{});}
        if (this.readyPending?.generation === this.generation) {
          const pending = this.readyPending; this.readyPending = null;
          this.pageReady(pending.target,pending.keyword).catch(() => {});
        }
      });
      return this.active;
    }
    async step(alive, signal, deliveryOnly = false) {
      let s = await this.read(); const recover = this.recover; this.recover = false;
      const ready = this.readyPending; this.readyPending = null;
      if(!deliveryOnly&&(s.sdk_unknown===true||['sending','unknown'].includes(s.sdk_pending?.status))){s.sdk_unknown=true;if(s.test_run)await this.endTest(s,'sdk_unknown');else{s.enabled=false;s.last_error='sdk_unknown';await this.save(s);await this.r.cancel();}return;}
      if(!deliveryOnly&&['sending','unknown'].includes(s.risk_report?.state)){if(s.enabled){s.enabled=false;await this.save(s);}return;}
      if (!s.enabled && !(deliveryOnly && s.delivery_enabled && s.outbox.length)) return;
      if(!deliveryOnly&&this.bodyBudgetSpent(s)&&!s.work_slots?.length&&['idle','search_done'].includes(s.phase))return this.pauseBodyBudget(s);
      if(!deliveryOnly && s.phase==='search' && ['pending','admitted'].includes(s.owner_search_admission?.state))s.phase='idle';
      if (s.consent !== C.CONSENT) { s.enabled = false; s.delivery_enabled = false; s.last_error = 'consent_required'; await this.save(s); await this.r.cancel(); await this.r.cancelDelivery?.(); return; }
      // Receipt delivery is independent from source authority. Inspect the
      // history binding before any outbox early return, but never alter a
      // checkpoint just to decide whether an existing receipt can be sent.
      if(s.task?.history_scope&&s.outbox.length){
        try{
          await this.verifyHistoryCheckpoint(s,alive,signal,{readOnly:true});
          if(s.history_binding_unknown){delete s.history_binding_unknown;delete s.history_outbox_retry_at;if(s.last_error==='history_recovery_required')s.last_error=null;await this.save(s);}
        }catch(error){
          if(error.message==='cancelled'||signal.aborted)throw error;
          alive();s.history_binding_unknown=true;s.last_error='history_recovery_required';await this.save(s);
        }
        if(s.history_binding_unknown&&(s.history_outbox_retry_at||0)>this.r.now()){
          await this.scheduleReceipt(s,s.history_outbox_retry_at);return;
        }
      }
      if(s.task?.history_scope&&s.history_binding_unknown&&!s.outbox.length){
        try{await this.verifyHistoryCheckpoint(s,alive,signal,{readOnly:true});delete s.history_binding_unknown;delete s.history_outbox_retry_at;if(s.last_error==='history_recovery_required')s.last_error=null;await this.save(s);}
        catch(error){if(error.message==='cancelled'||signal.aborted)throw error;alive();s.enabled=false;s.last_error='history_recovery_required';await this.save(s);await this.r.cancel();return;}
      }
      if (deliveryOnly) {
        const stoppedReason = !s.enabled ? s.last_error : null;
        let continueDelivery=false;
        try {
          alive();
          if (s.outbox.length) { continueDelivery=await this.flushOutbox(s, alive, signal); if(!['outbox_scope_unknown','outbox_lease_unknown','base_lease_unknown','unselected_comments_in_body'].includes(s.last_error))s.delivery_error = null; await this.save(s); }
        } catch (error) {
          alive();
          const auth = error.status === 401, permission = error.status === 403;
          s.delivery_error = auth ? 'backend_login_required' : permission ? 'backend_permission_denied' : error.message === 'review_local_rejections' ? error.message : s.task?.owner_base_task===true && ['lease_expired','base_lease_unknown'].includes(error.message) ? 'base_lease_unknown' : 'backend_unavailable';
          if (auth || permission || error.message === 'review_local_rejections') { s.delivery_enabled = false; s.enabled = false; await this.r.cancel(); }
          if(s.history_binding_unknown){s.last_error='history_recovery_required';s.history_outbox_retry_at=this.r.now()+60000;await this.save(s);}
          else if (s.outbox.length) {
            const item = s.outbox[0]; item.retries = (item.retries || 0) + 1;
            item.retry_at = this.r.now() + Math.min(900000, 60000 * 2 ** Math.min(item.retries - 1, 4));
          }
          await this.save(s);
        }
        if (stoppedReason) { s.last_error = stoppedReason; await this.save(s); }
        await this.repairDelivery(); return continueDelivery;
      }
      await this.repairDelivery();
      const now = this.r.now();
      const day = new Date(now + 8 * 3600000).toISOString().slice(0, 10);
      if (s.day !== day) { s.day = day; s.visits = 0; }
      try {
        alive();
        if(s.test_run && ['waiting','active'].includes(s.test_run.state) && (now>=s.test_run.expires_at || day!==s.test_run.day)) {await this.endTest(s,'test_expired');return;}
        if(this.r.recoveryPages&&s.pilot_waiting&&s.pilot_phase==='awaiting_acceptance'&&s.last_error==='test_completed')await this.finishAcknowledgedTask(s,alive,signal);
        // A known pilot acceptance boundary needs cloud status, never a live platform page or a new claim.
        if(s.pilot_waiting||s.pilot_check_pending||s.pilot_phase==='awaiting_acceptance'&&s.last_error==='daily_quota'){
          if(!s.pilot_waiting)s.pilot_check_pending=true;
          if(!Number.isFinite(s.pilot_checked_at)||now<s.pilot_checked_at||now>=s.pilot_checked_at+60000){
            s.pilot_checked_at=now;await this.save(s);alive();
            try{await this.control(s,'control',alive,signal);}catch(error){
              alive();if(error.status===401||error.status===403)throw error;
              s.control_error=true;s.last_error='control_unavailable';
            }
            await this.save(s);alive();
          }
          if(!s.enabled)return;
          if(s.pilot_waiting||s.pilot_check_pending){
            if(s.outbox.length)await this.flushOutbox(s,alive,signal);
            await this.save(s);await this.schedule(s,this.r.now()+60000);return;
          }
          // Let the outer session check verify the original account before any armed source work.
          await this.schedule(s,this.r.now()+1000);return;
        }
        if(s.assignment_refresh && s.outbox.length)return await this.flushOutbox(s,alive,signal);
        if(s.assignment_refresh && s.last_error==='daily_quota' && s.next_at>now){await this.schedule(s,s.next_at);return;}
        if(s.assignment_refresh) {
          if(s.test_run?.task_ids && !this.claimTask(s)){await this.endTest(s,'test_partial');return;}
          const requested=this.claimTask(s),bound=!!s.test_run?.task_ids;
          const claimed=await this.api.rpc('claim',{p_task:requested},signal);alive();
          if(await this.parkPilot(s,claimed,alive))return;
          if(claimed.error==='daily_quota') {if(s.test_run){await this.endTest(s,'test_quota');return;}s.next_at=C.quotaRetry(claimed,now);s.last_error='daily_quota';await this.save(s);await this.schedule(s,s.next_at);return;}
          if(claimed.error)throw Error(claimed.error);
          let task=claimed.task;
          if(s.lease_handoff?.state==='retired'&&task&&(task.id===s.lease_handoff.task_id||task.owner_base_task!==true)){
            s.lease_handoff.claim=task;s.lease_handoff.state='blocked';s.enabled=false;s.last_error='task_reconciliation_required';await this.save(s);throw Error('task_reconciliation_required');
          }
          this.validateSupplementClaim(s,claimed);
          const resumed=s.platform_resume_task;
          if(resumed){
            if(task?.id!==resumed.id||task?.query!==s.task?.query||task?.platform!==s.task?.platform)throw Error('lease_lost');
            if(task.lease_token!==resumed.lease&&!resumed.allow_renewal)throw Error('pool_recovery_required');
          }
          if(task===null&&s.acceptance_supplement?.state==='admitted'){
            if(this.recoveryUnsafe(s)||s.work_slots?.length||s.enrichment||['note','reopen_note'].includes(s.phase))throw Error('pool_recovery_required');
            s.task=null;s.phase='idle';s.next_at=now+300000;this.invalidateTaskControl(s);s.assignment_refresh=false;delete s.platform_resume_task;
            if(s.last_error==='task_reconciliation_required')s.last_error=null;
            await this.save(s);await this.schedule(s,s.next_at);return;
          }
          if(!task && s.task && !s.test_run?.task_ids) {
            if(s.work_slots?.length || s.enrichment || ['note','reopen_note'].includes(s.phase))throw Error('pool_recovery_required');
            const fresh=await this.api.rpc('claim',{p_task:null},signal);alive();
            if(await this.parkPilot(s,fresh,alive))return;
            if(fresh.error==='daily_quota') {if(s.test_run){await this.endTest(s,'test_quota');return;}s.next_at=C.quotaRetry(fresh,now);s.last_error='daily_quota';await this.save(s);await this.schedule(s,s.next_at);return;}
            if(fresh.error)throw Error(fresh.error);task=fresh.task;
          }
          if(!this.bindBatch(s,task,bound?requested:null)){await this.endTest(s,'test_no_task');return;}
          if(s.task?.id!==task?.id || s.task?.lease_token!==task?.lease_token || s.task?.query!==task?.query || s.task?.platform!==task?.platform) {
            if(s.work_slots?.length || s.enrichment || ['note','reopen_note'].includes(s.phase))throw Error('pool_recovery_required');
            if(!resumed&&s.acceptance_supplement?.state!=='admitted'&&!(s.task?.history_scope&&s.task.id===task?.id)){s.phase='idle';s.seen=[];s.candidates=[];s.search_round=0;s.note_url=null;s.note_id=null;}
          } else if(task) {
            if(task.received<s.task.received)throw Error('backend_unavailable');

          }
          if(task&&!(s.task?.history_scope&&s.task.id===task.id&&(s.task.lease_token!==task.lease_token||s.task.node_run?.installation_id!==task.node_run?.installation_id))){
            const before=s.candidates.length,known=this.knownNotes(s,task);
            s.candidates=s.candidates.filter(url=>!known.has(C.taskPlatform(task).noteURL(url).id));
            if(before>0&&!s.candidates.length&&s.phase==='search_done'&&s.acceptance_supplement?.schema==='crowd-acceptance-batch-v1'&&s.acceptance_supplement.state==='admitted'&&s.acceptance_supplement.task_id===task.id&&s.acceptance_supplement.remaining>0&&!this.recoveryUnsafe(s)&&!s.enrichment&&!['action','retry','budget','page'].includes(s.wait_kind)){s.phase='idle';s.search_round=0;s.next_at=this.r.now();}
          }
          const resumeNoTaskBatch=!s.task&&s.phase==='idle'&&task&&s.acceptance_supplement?.schema==='crowd-acceptance-batch-v1'&&s.acceptance_supplement.state==='admitted'&&s.acceptance_supplement.task_id===task.id&&s.acceptance_supplement.remaining>0&&!this.recoveryUnsafe(s)&&!['action','retry','budget','page'].includes(s.wait_kind);
          s.task=task || null;if(!task)s.next_at=now+30000;this.invalidateTaskControl(s);s.assignment_refresh=false;delete s.platform_resume_task;
          if(task&&s.lease_handoff?.state==='retired')s.lease_handoff.state='assigned';
          if(resumeNoTaskBatch)s.next_at=this.r.now();
          if(s.test_run?.state==='waiting' && task?.repair_only){
            if(s.outbox.length || s.work_slots?.length || s.enrichment)throw Error('pool_recovery_required');
            s.test_run.goal=0;s.test_run.limit=0;s.phase='idle';s.seen=[];s.candidates=[];s.search_round=0;s.note_url=null;s.note_id=null;
          }
          else if(s.test_run?.state==='waiting' && Number.isInteger(task?.acceptance_goal) && task.acceptance_goal>=1 && task.acceptance_goal<=4){s.test_run.goal=task.acceptance_goal;s.test_run.limit=task.acceptance_goal*2;}await this.save(s);
          // Re-enter the normal terminal/quota checks with the refreshed snapshot.
          return true;
        }
        // Local upgrades must also retire an older unlimited run, before optional visits.
        if(this.r.localTest === true && !s.assignment_refresh && s.task && !s.task.repair_only && (!s.test_run || !s.outbox.length && !s.work_slots?.length && !s.enrichment) &&
          (s.task.received>=s.task.target && !this.batchContinues(s) || s.task.remaining_today===0 || s.test_run?.accepted.length===this.testGoal(s))) {
          s.test_run ||= {id:this.r.uuid(),limit:4,attempts:0,accepted:[],state:'waiting',created_at:now,expires_at:now,day};
          await this.endTest(s,s.test_run.accepted.length===this.testGoal(s)?this.testResult(s):'test_quota');
          if(!s.outbox.some(item=>!item.kind) && s.task.received>=s.task.target && Date.parse(s.task.lease_until)>=now+60000) {
            try {
              const finished=await this.api.rpc('finish',{p_task:s.task.id,p_lease:s.task.lease_token},signal);alive();
              if(!finished || finished.error || !['open','complete','exhausted','closed'].includes(finished.status) || !Number.isSafeInteger(finished.received) || finished.received<0)throw Error('backend_unavailable');
              s.task=null;
            } catch(error) {alive();s.test_run.finish_error=error.message || 'backend_unavailable';}
            await this.save(s);
          }
          return;
        }
        // Restore active work, never a stopped/blocked participant. A long
        // suspension must restart dwell; wake detection is an alarm-gap heuristic.
        if (recover || (s.last_tick != null && now - s.last_tick > 120000)) {
          if(this.r.localTest === true && s.wait_kind === 'action')s.control_checked=0;
          if(s.task?.owner_base_task===true&&['note','reopen_note'].includes(s.phase))this.invalidateTaskControl(s);
          // Keep comment/profile checkpoints; enrich rechecks page, lease and action gates.
          // Elapsed sleep is not evidence that comments ended.
          if (s.phase === 'note' && !s.light_processing && !this.admittedBatchNote(s)) { s.phase = 'reopen_note'; s.loaded_at = null; s.scrolls = 0; }
          // An admitted search survives suspension. Probe its existing page and
          // original deadline; resetting to idle would charge and navigate again.
          // Keep persisted cooldowns, quota waits and evidence retry deadlines.
        }
        s.last_tick = now; await this.save(s); alive();
        // Repair a cleared alarm before network IO can suspend this worker.
        await this.schedule(s,Math.max(s.next_at, now + 30000)); alive();
        // Independent of task caching and collection waits. Explicit user stop still cancels work.
        const controlInterval=s.wait_kind==='action' || s.task?.repair_only && s.phase==='idle'?30000:300000;
        if (s.pending_risk || !s.control || s.control_task!==(s.task?.id||null) || now >= (s.control_checked || 0) + controlInterval || now < s.control_checked) {
          try { await this.control(s, s.pending_risk || 'control', alive, signal); }
          catch (error) { alive(); s.control_error = true; if (error.status === 401 || error.status === 403) throw error; }
          await this.save(s);
          if(!s.enabled)return;
          if(s.assignment_refresh)return true;
          if(s.pilot_waiting===true){if(s.outbox.length)await this.flushOutbox(s,alive,signal);s.last_error='test_completed';await this.save(s);await this.schedule(s,s.next_at);return;}
        }
        // New batches keep old rejects exportable; retries need complete evidence, never a hidden recrawl.
        const revision=s.control_task===s.task?.id?s.control?.relevance_revision||0:s.task?.relevance_revision||0;
        const retry=s.rejected.findIndex(item=>item.reason==='unrelated_note' && !item.kind && item.task===s.task?.id &&
          (!s.test_run || item.test_run_id===s.test_run.id) &&
          !s.task.comments_capture &&
          (item.relevance_revision || 0)<revision && now-Date.parse(item.record?.standard?.captured_at)<86400000);
        if(!s.outbox.length && retry>=0){
          const item=s.rejected.splice(retry,1)[0];item.relevance_revision=revision;item.lease=s.task.lease_token;
          s.outbox.push(item);await this.save(s);alive();
        }
        // Delivery runs even during collection cooldown. One stable UUID per record.
        if (s.outbox.length) return await this.flushOutbox(s, alive, signal);
        if(s.test_run?.state==='active' && s.note_test_run===s.test_run.id && s.phase==='reopen_note') {await this.endTest(s,'test_partial');return;}
        await this.applyPreferences(s);alive();
        if(s.test_run?.state==='waiting' && !s.work_slots?.length && !s.enrichment && ['idle','search_done'].includes(s.phase)) {
          s.test_run.state='active';s.test_run.started_at=now;await this.save(s);
        }
        if(s.test_run?.state==='active' && !this.batchContinues(s) && this.testRemaining(s)===0 && (!s.task?.repair_only || s.phase==='search_done' && !s.candidates.length) && !s.work_slots?.length && !s.enrichment && ['idle','search_done','parallel'].includes(s.phase)) {
          await this.endTest(s,s.test_run.accepted.length===this.testGoal(s)?this.testResult(s):'test_partial');
          // Only a filled task is finished; a two-note test must not exhaust a larger task.
          if(s.task?.received>=s.task?.target && Date.parse(s.task.lease_until)>=now+60000) {
            try {
              const finished=await this.api.rpc('finish',{p_task:s.task.id,p_lease:s.task.lease_token},signal);alive();
              if(!finished || finished.error || !['open','complete','exhausted','closed'].includes(finished.status) || !Number.isSafeInteger(finished.received) || finished.received<0)throw Error('backend_unavailable');
              s.task=null;s.phase='idle';
            } catch(error) {alive();s.test_run.finish_error=error.message || 'backend_unavailable';}
            await this.save(s);
          }
          return;
        }
        if (s.pending_risk || !s.control || s.control_task!==(s.task?.id||null) || this.r.now() >= s.control_expires || this.r.now() < s.control_checked) {
          s.last_error = 'control_unavailable'; await this.save(s); return;
        }
        // Verify before *any* page probe or source navigation, including pause
        // settlement and enrichment paths. Outbox delivery remains independent.
        if(s.task?.history_scope){
          if(s.history_recovery_blocked)throw Error('history_recovery_required');
          if(await this.verifyHistoryCheckpoint(s,alive,signal))return true;
        }
        if (s.control.owner_pause_requested===true && s.control.paused && s.task?.owner_base_task===true && ['note','reopen_note'].includes(s.phase) && !s.task.comments_capture && !s.task.structured_capture && !s.profiles) {
          let page;
          try{page=await this.r.probe('note_ready');}
          catch(error){
            if(error.message!=='pool_recovery_required')throw error;
            await this.preserveOwnerPauseUnresolved(s,alive,now);return;
          }
          if(!page?.gate&&(page?.reopen===true||!page?.ready&&(page?.reason==='content_unavailable'||Number.isFinite(s.page_deadline)&&now>=s.page_deadline))){await this.preserveOwnerPauseUnresolved(s,alive,now);return;}
          alive();this.checkPage(page,s,now);
          if(!page.ready){await this.save(s);await this.schedule(s,now+30000);return;}
          if(page.record.standard.note_id!==s.note_id)throw Error('wrong_note');
          const intent=s.detail_intent;
          if(intent?.admitted!==true||intent.task!==s.task.id||intent.lease!==s.task.lease_token||intent.installation!==s.task.node_run?.installation_id||intent.note!==s.note_id)throw Error('task_reconciliation_required');
          page.record=this.ownerBodyRecord(s,page.record);C.validate(page.record);
          if(this.keywordState(s)?.terms.length>1)page.record.extra.discovery={method:'task_search',candidate:s.card_meta?.[s.note_id]||null,matched_keywords:this.keywordHits(s,s.note_id)};
          const request=this.detailRequest(s),body={request,task:s.task.id,lease:s.task.lease_token,record:page.record,test_run_id:null};
          if(s.task.root_comments?.enabled===true&&s.task.root_comments.include_replies===true){
            const owner=this.outboxOwner(s),url=s.note_url,note=s.note_id;
            if(s.owner_reply_checkpoint||!owner||!url||C.noteURL(url).id!==note||request!==intent.request)throw Error('reply_checkpoint_invalid');
            const saved={root_only:true,parent:request,record:JSON.parse(JSON.stringify(page.record)),roots:[],rounds:0,action_pending:false};
            s.owner_reply_checkpoint={schema:'crowd-owner-reply-checkpoint-v1',owner,task:s.task.id,lease:s.task.lease_token,origin_lease:s.task.lease_token,installation:intent.installation,note,url,parent:request,state:'waiting',enrichment:saved,receipts:[{request,kind:'body',record:JSON.parse(JSON.stringify(page.record))}]};
          }
          s.outbox.push(body);
          if(s.task.light_text){
            const p=s.light_processing;if(p&&(p.task!==s.task.id||p.lease!==s.task.lease_token||p.note!==s.note_id))throw Error('light_checkpoint_mismatch');
            if(s.light_resume)throw Error('light_checkpoint_mismatch');
            const item=this.queueLight(s,request,s.note_id,p?{...p,note_id:s.note_id,reason:p.reason||'interrupted',asr_gap:p.asr_gap||(!p.asr_done?'asr_interrupted':null),ocr_gap:p.ocr_gap||(!p.ocr_done?'ocr_interrupted':null)}:{note_id:s.note_id,subtitle:null,reason:'interrupted',asr_gap:'asr_interrupted',ocr_gap:'ocr_interrupted'});
            s.light_resume={schema:'crowd-light-resume-v1',owner:this.outboxOwner(s),task:s.task.id,lease:s.task.lease_token,installation:intent.installation,parent:request,note:s.note_id,url:C.noteURL(s.note_url).url,body:JSON.parse(JSON.stringify(page.record)),intent:JSON.parse(JSON.stringify(intent)),progress:p?JSON.parse(JSON.stringify(p)):null,sequence:0,last_request:item.request,state:'waiting_ack'};
            delete s.light_processing;
          }
          s.phase='search_done';s.note_url=null;s.note_id=null;s.loaded_at=null;s.next_at=now;await this.save(s);alive();
          await this.flushOutbox(s,alive,signal);return;
        }
        if(s.control.owner_pause_requested===true && s.control.paused && s.enrichment?.root_only){
          const e=s.enrichment;
          if(s.task?.root_comments?.include_replies===true){
            const prior=s.owner_reply_checkpoint;
            if(prior&&!(e.resumed_parent===true&&['admitted','opened','active'].includes(prior.state)&&prior.new_lease===s.task.lease_token&&prior.parent===e.parent))throw Error('reply_checkpoint_unresolved');
            const note=s.note_id,url=s.note_url,task=s.task,owner=this.outboxOwner(s);
            if(!owner||!note||!url||!task.node_run?.installation_id||e.record?.standard?.note_id!==note||!e.parent)throw Error('reply_checkpoint_invalid');
            const saved=JSON.parse(JSON.stringify(e)),previous=s.outbox.length;
            this.queueRootComments(s,e,e.action_pending?'unknown':'interrupted');
            s.owner_reply_checkpoint={schema:'crowd-owner-reply-checkpoint-v1',owner,task:task.id,lease:task.lease_token,origin_lease:prior?.origin_lease||prior?.lease||task.lease_token,installation:task.node_run.installation_id,note,url,parent:saved.parent,state:saved.action_pending?'unknown':'waiting',enrichment:saved,receipts:s.outbox.slice(previous).map(item=>({request:item.request,kind:item.kind||'body',record:item.record}))};
          }else this.queueRootComments(s,e,e.action_pending?'unknown':'interrupted');
          await this.save(s);alive();
          if(s.outbox.length)await this.flushOutbox(s,alive,signal);
          return;
        }
        if ((s.control.paused && !(s.control.owner_pause_requested===true && s.task?.owner_base_task===true && s.phase==='search')) || ['captcha','rate_limit','session_rest'].includes(s.control.reason) && now < s.control_checked + s.control.wait_ms) {
          s.last_error = s.control.reason || 'global_pause'; await this.save(s); return;
        }
        const pageWake = s.wait_kind === 'page' && ready?.generation === this.generation &&
          now >= (s.retry_at || 0) &&
          (s.phase === 'search' ? ready.keyword === this.searchQuery(s) : ready.target === s.note_id);
        if (s.next_at > now && !pageWake && !s.work_slots?.length) { await this.schedule(s,s.next_at); return; }
        if (s.enrichment) {
          if(s.phase==='reply_reopen'){await this.resumeReplyPage(s,alive);await this.save(s);alive();await this.schedule(s,s.next_at);return;}
          if(s.enrichment.root_only)await this.rootEnrich(s,alive,signal);
          else await this.enrich(s, alive, signal); await this.save(s); alive();
          if (s.outbox.length) await this.flushOutbox(s, alive, signal);
          await this.schedule(s,s.next_at);
          return !s.outbox.length && s.next_at <= this.r.now();
        }
        if (!s.task || Date.parse(s.task.lease_until) < now + 180000) {
          if(s.test_run?.task_ids && !this.claimTask(s)){await this.endTest(s,'test_partial');return;}
          const requested=this.claimTask(s),bound=!!s.test_run?.task_ids;
          const claimed = await this.api.rpc('claim', {p_task: requested}, signal); alive();
          if(await this.parkPilot(s,claimed,alive))return;
          if (claimed.error === 'daily_quota') { if(s.test_run){await this.endTest(s,'test_quota');return;} s.next_at = C.quotaRetry(claimed, now); s.last_error = 'daily_quota'; await this.save(s); await this.schedule(s,s.next_at); return; }
          if (claimed.error) throw new Error(claimed.error);
          if(s.light_resume&&(!claimed.task||claimed.task.id!==s.light_resume.task||claimed.task.lease_token!==s.light_resume.lease||claimed.task.node_run?.installation_id!==s.light_resume.installation))throw Error('light_checkpoint_mismatch');
          if(claimed.task!==null)this.validateSupplementClaim(s,claimed);
          if(!this.bindBatch(s,claimed.task,bound?requested:null)){await this.endTest(s,'test_no_task');return;}
          // A started participant must check for a later Owner task on the next alarm.
          if (!claimed.task) { s.task = null; s.phase = 'idle'; s.next_at = now + 30000; }
          else {
            if (s.task?.id !== claimed.task.id || s.task?.lease_token !== claimed.task.lease_token) {
              if(s.work_slots?.length)throw Error('pool_recovery_required');
              if(s.task?.id!==claimed.task.id){delete s.history_search_end;delete s.history_bottom_pending;delete s.history_bottom_stalls;delete s.history_last_candidates;delete s.history_progress;delete s.history_recovered_no_search;delete s.history_recovery_blocked;}
              if(s.acceptance_supplement?.state!=='admitted'&&!(s.task?.history_scope&&s.task.id===claimed.task.id)){s.phase = 'idle'; s.seen = []; s.candidates = []; s.search_round = 0;
              s.note_url = null; s.note_id = null;}
            }
            s.task = claimed.task;
          }
          this.invalidateTaskControl(s);await this.save(s);return true;
        }
        if (!s.task) { if(s.test_run){await this.endTest(s,'test_no_task');return;} await this.save(s); await this.schedule(s,s.next_at); return; }
        const budgetNow=this.r.now();
        const taskDetailCap=s.task?.daily_detail_cap==null?200:s.task.daily_detail_cap;
        const visitCap=this.acceptanceBatch(s)&&!this.recoveryUnsafe(s)&&s.control_task===s.task.id&&Number.isSafeInteger(taskDetailCap)&&taskDetailCap>=1&&taskDetailCap<=200&&Number.isInteger(s.control.caps?.detail)&&s.control.caps.detail>=1&&s.control.caps.detail<=taskDetailCap&&s.control.caps.detail<=200&&Number.isSafeInteger(s.control_checked)&&s.control_checked<=budgetNow&&Number.isSafeInteger(s.control_expires)&&s.control_expires>budgetNow?s.control.caps.detail:60;
        if(s.phase==='light_reopen')return await this.reopenOwnerLight(s,alive,signal);
        if(s.light_resume?.state==='acked'&&s.phase==='search_done'&&s.control?.paused===false&&s.control?.owner_pause_requested!==true){s.phase='light_resume';await this.save(s);alive();}
        if(s.phase==='light_resume')return await this.resumeOwnerLight(s,alive,signal);
        if (s.visits >= visitCap && !this.admittedBatchNote(s)) { s.next_at = budgetNow + 3600000; s.wait_kind = 'budget'; await this.save(s); await this.schedule(s,s.next_at); return; }
        const platform = C.taskPlatform(s.task);
        const stored=this.keywordState(s);
        if(stored?.terms.length===1 && (s.phase==='search_done'||s.phase==='parallel'||s.work_slots?.length) && s.candidates.length && !stored.legacy_window_saved){
          const cards=s.candidates.flatMap(url=>{const meta=s.card_meta?.[platform.noteURL(url).id];return meta?[{url,...meta}]:[];});
          await this.saveKeywordPage(s,s.candidates,cards);
          stored.legacy_window_saved=true;await this.save(s);alive();
        }
        if(s.phase==='search_done' && !s.candidates.length && this.keywordState(s) && s.task.received<s.task.target){
          await this.fillKeywordCandidates(s,this.knownNotes(s,s.task));await this.save(s);alive();
        }
        if(s.work_slots?.length || !s.task.light_text && s.parallelism===2 && ['search_done','parallel'].includes(s.phase) &&
          (s.task.repair_only || s.task.received<s.task.target && s.task.remaining_today!==0) && s.candidates.length) {
          if(!this.parallelStep)throw Error('parallel_unavailable');
          if(!s.work_slots?.length && s.phase==='search_done'){await this.r.closeLegacy?.();alive();}
          return await this.parallelStep(s,alive,signal);
        }
        if(s.task.history_scope&&s.history_recovered_no_search&&s.phase==='search_done'&&!s.candidates.length){s.enabled=false;s.last_error='history_recovery_partial';await this.save(s);await this.r.cancel();return;}
        if (!s.task.repair_only && s.task.received >= s.task.target || (s.phase === 'search_done' && !s.candidates.length)) {
          const continueBatch=this.batchContinues(s),finishedTask=s.task.id;
          const finished = await this.api.rpc('finish', {p_task: s.task.id, p_lease: s.task.lease_token}, signal); alive();
          if (!finished || (finished.error && finished.error !== 'lease_lost') ||
            (!finished.error && (!['open','complete','exhausted','closed'].includes(finished.status) || !Number.isSafeInteger(finished.received) || finished.received < 0))) throw new Error('backend_unavailable');
          s.last_error = finished.error || null;
          if(continueBatch) {
            if(finished.error || finished.status!=='complete'){await this.endTest(s,'test_partial');return;}
            s.test_run.finished_tasks ||= [];if(!s.test_run.finished_tasks.includes(finishedTask))s.test_run.finished_tasks.push(finishedTask);
          }
          const resumeBatch=s.acceptance_supplement?.schema==='crowd-acceptance-batch-v1'&&s.acceptance_supplement.state==='admitted'&&s.acceptance_supplement.task_id===finishedTask&&s.acceptance_supplement.remaining>0&&!finished.error&&finished.status==='open'&&finished.received===s.task.received&&finished.received<s.task.target&&Number.isSafeInteger(s.task.lease_start_received)&&s.task.received>s.task.lease_start_received;
          if(resumeBatch)s.assignment_refresh=true;
          if(!finished.error&&finished.status==='complete')await this.releaseKeywordLog(s);
          s.task = null; s.phase = 'idle'; s.next_at = now + (continueBatch||resumeBatch?1000:60000); if(this.r.closeSlot)await this.r.closeSlot('search');else await this.r.close();
        } else if (s.task.remaining_today === 0 && !s.task.repair_only) {
          if(s.test_run){await this.endTest(s,'test_quota');return;}
          s.next_at = now + 3600000;
        } else if (s.phase === 'idle') {
          const admitted=s.owner_search_admission;
          if(admitted){
            this.assertTest(s);await this.r.sourceHealth?.(s.task?.platform||'xiaohongshu');alive();
            if(admitted.state!=='admitted'||s.task?.owner_base_task!==true||admitted.task!==s.task.id||admitted.lease!==s.task.lease_token||admitted.owner!==(s.owner_id||null)||admitted.installation!==(s.task.node_run?.installation_id||null)||admitted.query!==this.searchQuery(s))throw Error('owner_search_reconciliation_required');
            if(s.task.owner_pause_lease_v1===true){
              const claimed=await this.api.rpc('claim',{p_task:s.task.id},signal);alive();
              if(claimed?.error||claimed?.task?.id!==s.task.id||claimed.task.lease_token!==s.task.lease_token||claimed.task.node_run?.installation_id!==admitted.installation||claimed.task.owner_base_task!==true||claimed.task.query!==s.task.query||JSON.stringify(claimed.task.owner_base_keywords)!==JSON.stringify(s.task.owner_base_keywords)||Date.parse(claimed.task.lease_until)<=this.r.now()||!Number.isFinite(Date.parse(claimed.task.lease_until))||!Number.isSafeInteger(claimed.task.received)||!Number.isSafeInteger(claimed.task.target)||claimed.task.received<0||claimed.task.received>=claimed.task.target||claimed.task.remaining_today===0)throw Error('owner_search_reconciliation_required');
            }
          }else if (!await this.admit(s, 'search', alive, signal)) return;
          // One alarm interval for initial search loading; never auto-reopen it.
          this.searchQuery(s,s.task,true);s.phase = 'search'; s.page_deadline = this.r.now() + (this.acceptanceBatch(s)?90000:30000); s.next_at = this.r.now()+1000; s.wait_kind = 'page';
          // Persist before navigation: a worker restart after tabs.update must
          // resume probing instead of opening/charging the same search again.
          await this.save(s); alive();
          // The pre-admission heartbeat can precede this new deadline. Re-arm
          // once so a slow guard does not cost another full alarm interval.
          await this.schedule(s,s.next_at, true); alive();
          if(s.test_run?.state==='active' && !s.test_run.first_source_at_ms){s.test_run.first_source_at_ms=this.r.now();await this.save(s);alive();}
          try { if(await this.ownerPauseBeforeOpen(s,'search',alive,signal))return; }
          catch(error) { alive(); s.phase='idle'; throw error; }
          const attempt=s.owner_search_admission;
          if(attempt){
            // A pre-contract admission can be safely named before any navigation.
            if(!attempt.attempt){attempt.attempt=this.r.uuid();await this.save(s);alive();}
            attempt.state='sending';await this.save(s);alive();
            const contract={owner:attempt.owner,task:attempt.task,lease:attempt.lease,installation:attempt.installation,query:attempt.query,attempt:attempt.attempt};
            const valid=async()=>{
              alive();if(this.pendingStop||this.stopping||this.stopActive||this.maintenance)return false;
              const current=await this.r.storage.get('agent');alive();
              const a=current?.owner_search_admission,t=current?.task;
              return current?.enabled===true&&current.phase==='search'&&(current.owner_id||null)===contract.owner&&current.run_generation===s.run_generation&&current.control?.paused!==true&&current.control?.owner_pause_requested!==true&&t?.id===contract.task&&t.lease_token===contract.lease&&(t.node_run?.installation_id||null)===contract.installation&&(!t.lease_until||Date.parse(t.lease_until)>this.r.now())&&this.searchQuery(current)===contract.query&&a?.state==='sending'&&Object.keys(contract).every(k=>a[k]===contract[k])&&!this.pendingStop&&!this.stopping&&!this.stopActive&&!this.maintenance;
            };
            try{this.assertTest(s);await this.r.open(platform.searchURL(this.searchQuery(s)),false,null,{contract,valid});alive();}
            catch(error){if(error.message==='cancelled'||signal.aborted)throw error;throw Error('owner_search_navigation_unknown');}
            attempt.state='sent';await this.save(s);alive();
          }else {this.assertTest(s);await this.r.open(platform.searchURL(this.searchQuery(s)));alive();}
        } else if (s.phase === 'search') {
          this.assertTest(s);let page;
          const attempt=s.owner_search_admission;
          if(attempt){
            if(!['sending','sent','confirmed'].includes(attempt.state)||!attempt.attempt||attempt.task!==s.task?.id||attempt.lease!==s.task.lease_token||attempt.owner!==(s.owner_id||null)||attempt.installation!==(s.task.node_run?.installation_id||null)||attempt.query!==this.searchQuery(s))throw Error('owner_search_reconciliation_required');
            const contract={owner:attempt.owner,task:attempt.task,lease:attempt.lease,installation:attempt.installation,query:attempt.query,attempt:attempt.attempt};
            let result;try{result=await this.r.confirmSearchNavigation?.(contract,attempt.state==='sent');}catch(_){result=null;}alive();
            if(result?.state==='pending'&&attempt.state==='sent'&&now<s.page_deadline){s.next_at=now+1000;await this.save(s);await this.schedule(s,s.next_at);return;}
            if(result?.state!=='confirmed'||!result.page)throw Error('owner_search_navigation_unknown');
            page=result.page;attempt.state='confirmed';await this.save(s);alive();
          }else page=await this.r.probe('search');
          alive();
          const normalize = value => String(value || '').normalize('NFC').replace(/\s+/g, ' ').trim().toLowerCase();
          if ('keyword' in page && normalize(page.keyword) !== normalize(this.searchQuery(s))) throw new Error('page_mismatch');
          this.checkPage(page, s, now);
          if (page.ready) {
            if(s.owner_search_admission?.state==='confirmed')delete s.owner_search_admission;
            s.data_ready_at = this.r.now();
            const multi=this.keywordState(s);
            if(multi)page.links=await this.saveKeywordPage(s,page.links,page.cards||[]);
            this.recordKeywordHits(s,page.links);
            const repairs=new Set((s.task.repair_notes||[]).filter(n=>!s.repaired?.includes(n.parent)).map(n=>n.record.standard.note_id));
            const known=this.knownNotes(s,s.task);
            const found = new Map(s.candidates.map(url => [platform.noteURL(url).id, url]).filter(([id]) => !known.has(id)));
            for (const url of page.links) { try { const note = platform.noteURL(url); if (!known.has(note.id) && !s.seen.includes(note.id) && (!s.history.includes(note.id) || repairs.has(note.id))) found.set(note.id, note.navigation); } catch (_) {} }
            s.card_meta ||= {};
            for (const card of page.cards || []) { try { s.card_meta[platform.noteURL(card.url).id] = {title:card.title,author_display:card.author_display}; } catch (_) {} }
            const normalizeTerm = value => String(value || '').normalize('NFKC').toLowerCase().replace(/[\s\p{P}]/gu,'');
            const score = url => (s.task.anchor_terms || []).filter(term => normalizeTerm(s.card_meta[platform.noteURL(url).id]?.title).includes(normalizeTerm(term))).length;
            if(!multi)s.candidates = [...found.values()].filter(url=>!s.task.repair_only || repairs.has(platform.noteURL(url).id)).sort((a,b) => (repairs.has(platform.noteURL(b).id)?10000:score(b))-(repairs.has(platform.noteURL(a).id)?10000:score(a))).slice(0, 80);
            s.card_meta = Object.fromEntries(s.candidates.map(url => {const id=platform.noteURL(url).id;return [id,s.card_meta[id] || {}];}));
            s.search_round = (s.search_round || 0) + 1;
            // A title match improves discovery order, never replaces body relevance.
            const needed = s.task.repair_only?repairs.size:Math.max(1, Math.min(s.task.target - s.task.received,this.testRemaining(s)));
            const g=s.acceptance_supplement,terms=s.task.anchor_terms;
            const brandBatch=!s.task.repair_only&&g?.schema==='crowd-acceptance-batch-v1'&&g.state==='admitted'&&g.task_id===19&&g.task_id===s.task.id&&Number.isSafeInteger(g.baseline_received)&&g.baseline_received>=0&&Number.isSafeInteger(g.extra_limit)&&g.extra_limit>=1&&g.extra_limit<=100&&g.target===g.baseline_received+g.extra_limit&&g.target===s.task.target&&g.remaining===s.task.target-s.task.received&&g.remaining>0&&Array.isArray(terms)&&terms.length===1&&typeof terms[0]==='string'&&this.searchQuery(s)===terms[0].normalize('NFC').trim();
            const history=!!s.task.history_scope;
            const available=history?await this.availableKeywordCandidates(s,known,Number.MAX_SAFE_INTEGER):0;
            if(history&&s.history_bottom_pending){s.history_bottom_stalls=available<=(s.history_last_candidates??0)?(s.history_bottom_stalls||0)+1:0;if(s.history_bottom_stalls>=2)s.history_search_end=true;}
            if(history)s.history_last_candidates=available;
            const expand=history?!s.history_search_end&&available<needed:multi?s.search_round<3&&await this.availableKeywordCandidates(s,known,needed)<needed:brandBatch?s.candidates.filter(url=>score(url)>0).length<needed&&s.search_round<31&&s.candidates.length<80&&Number.isFinite(s.page_deadline)&&now<s.page_deadline:s.search_round<3&&s.candidates.length<needed;
            if(history)await this.recordHistoryProgress(s,expand?'paging':s.history_search_end?'bottom_stalled':'candidate_limit',alive,signal);
            if (expand && s.control.owner_pause_requested!==true) {
              if (!await this.admit(s, 'scroll', alive, signal)) { s.search_round--; await this.save(s); return; }
              this.assertTest(s);const scrolled=await this.r.probe('scroll');alive();
              const motionFailed=scrolled?.scroll?.moved===false&&scrolled.scroll.at_end===false;
              if(history)s.history_bottom_pending=scrolled?.scroll?.at_end===true;
              if(scrolled?.ready!==true||scrolled.gate||motionFailed)s.search_round--;
              this.checkPage(scrolled||{ready:false,reason:'content_unavailable'},s,now);
              if(motionFailed)throw Error('content_unavailable');
              if(scrolled?.ready!==true){
                if(!scrolled||typeof scrolled.ready!=='boolean'||scrolled.reason==='content_unavailable'||!Number.isFinite(s.page_deadline))throw Error('content_unavailable');
                await this.save(s);await this.schedule(s,s.next_at);return;
              }
              s.next_at = now + (this.r.fastCapture===true?1000:C.between(30000, 45000, this.r.random));
            }
            else { s.search_round = 0; const next=this.nextKeyword(s);if(history&&next){s.history_search_end=false;s.history_bottom_pending=false;s.history_bottom_stalls=0;s.history_last_candidates=0;}s.phase = next?'idle':'search_done'; s.next_at = now; s.wait_kind = null; }
          }
        } else if (s.phase === 'search_done') {
          const url = s.candidates[0]; const id = platform.noteURL(url).id;
          if (!await this.admit(s, 'detail', alive, signal, id)) {
            if (['known_note','note_busy'].includes(s.last_error)) { s.candidates.shift(); s.seen.push(id); await this.save(s); }
            return;
          }
          s.candidates.shift();
          // Mark before navigation: crashes cannot create infinite note loops.
          s.seen.push(id); s.visits++; s.note_id = id; s.note_url = url; s.phase = 'note'; s.loaded_at = null; s.scrolls = 0; s.comment_rounds = 0; s.comment_snapshot = null; s.comment_stalls = 0;
          s.note_repair=s.task.repair_notes?.find(n=>n.record.standard.note_id===id && !s.repaired?.includes(n.parent)) || null;
          s.note_test_run=null;
          if(s.test_run?.state==='active' && !s.note_repair){s.test_run.attempts++;s.note_test_run=s.test_run.id;}
          s.dwell_ms = C.between(45000, 90000, this.r.random); s.page_deadline = now + 180000;
          s.next_at = now + (this.r.fastCapture===true?1000:30000); s.wait_kind = 'page'; s.fast_note = this.r.fastCapture === true; await this.save(s);
          if(await this.ownerPauseBeforeOpen(s,'detail',alive,signal))return;
          this.assertTest(s);await this.r.open(url); alive();
        } else if (s.phase === 'reopen_note') {
          if (!s.note_url) { s.phase = 'idle'; s.next_at = now + 30000; }
          else {
            if (!await this.admit(s, 'detail', alive, signal, s.note_id)) {
              if (['known_note','note_busy'].includes(s.last_error)) { s.phase = 'search_done'; s.note_url = null; s.note_id = null; await this.save(s); }
              return;
            }
            this.assertTest(s);await this.r.open(s.note_url); alive(); s.phase = 'note'; s.loaded_at = null; s.scrolls = 0; s.comment_rounds = 0; s.comment_snapshot = null; s.comment_stalls = 0;
            s.page_deadline = now + 180000; s.next_at = now + (this.r.fastCapture===true?1000:30000); s.wait_kind = 'page'; s.fast_note = this.r.fastCapture === true;
          }
        } else if (s.phase === 'note') {
          this.assertTest(s);let page;
          try{const withComments=s.task?.comments_capture===true||s.task?.structured_capture===true;page=await this.r.probe(s.fast_note?(withComments?'note_ready_with_comments':'note_ready'):(withComments?'note_with_comments':'note'));}
          catch(error){
            alive();
            if(error.message==='pool_recovery_required'&&error.poolCause==='entry_state'&&this.admittedBatchNote(s)&&!s.task.repair_only&&!s.task.repair_notes?.length&&s.task.comments_capture===false&&s.task.structured_capture===false&&s.profiles!==true&&!this.recoveryUnsafe(s)&&!s.outbox.length&&!s.work_slots?.length&&!s.enrichment&&!s.note_repair&&!s.pending_risk&&this.r.historicalNote){
              await this.r.sourceHealth?.(s.task.platform||'xiaohongshu');alive();
              if(await this.r.historicalNote(s.note_id,alive)){
                alive();s.interrupted||=[];s.interrupted.push({task:s.task.id,note_id:s.note_id,action_consumed:true,outcome:'confirmed_abandoned',reason:'update_interrupted_before_capture'});
                s.phase='search_done';s.note_id=null;s.note_url=null;s.note_test_run=null;s.loaded_at=null;s.wait_kind=null;s.next_at=this.r.now();await this.save(s);return true;
              }
            }
            throw error;
          }
          alive(); this.checkPage(page, s, now);this.assertTest(s);await this.r.sourceHealth?.(s.task?.platform||'xiaohongshu');alive();
          if (page.ready) {
            if (page.record.standard.note_id !== s.note_id) throw new Error('wrong_note');
            s.data_ready_at = this.r.now();
            if (s.loaded_at === null) s.loaded_at = now;
            if (!s.fast_note && (now - s.loaded_at < s.dwell_ms || s.scrolls < 2)) {
              if (!await this.admit(s, 'scroll', alive, signal)) return;
              this.assertTest(s);await this.r.probe('scroll'); alive(); s.scrolls++; s.next_at = now + C.between(30000, 45000, this.r.random);
            } else if(s.task?.root_comments?.enabled===true && s.task.owner_base_task===true) {
              page.record=this.ownerBodyRecord(s,page.record);C.validate(page.record);
              page.record.extra.discovery={method:'task_search',candidate:s.card_meta?.[s.note_id]||null};
              if(this.keywordState(s)?.terms.length>1)page.record.extra.discovery.matched_keywords=this.keywordHits(s,s.note_id);
              page.record=this.ownerBodyRecord(s,page.record);
              const light=s.task.light_text?await this.readOwnerLight(s,alive,signal,page.record):null;
              if(light?.body){page.record=light.body;delete light.body;}
              s.enrichment={root_only:true,parent:this.detailRequest(s),record:JSON.parse(JSON.stringify(page.record)),roots:[],rounds:0,action_pending:false,...(light?{light_observation:light}:{})};
              if(light)delete s.light_processing;
              s.phase='enrich';s.next_at=now;s.wait_kind=null;
            } else if(s.task?.owner_base_task===true && s.task.comments_capture===false && s.task.structured_capture!==true && !s.profiles) {
              page.record=this.ownerBodyRecord(s,page.record);C.validate(page.record);
              if(this.keywordState(s)?.terms.length>1)page.record.extra.discovery={method:'task_search',candidate:s.card_meta?.[s.note_id]||null,matched_keywords:this.keywordHits(s,s.note_id)};
              const light=s.task.light_text?await this.readOwnerLight(s,alive,signal,page.record):null,request=this.detailRequest(s);
              if(light?.body){page.record=light.body;delete light.body;}
              s.outbox.push({request,task:s.task.id,lease:s.task.lease_token,record:page.record,test_run_id:null});
              if(light){this.queueLight(s,request,s.note_id,light);delete s.light_processing;}
              s.phase='search_done';s.notes_in_session++;s.note_url=null;s.note_id=null;s.loaded_at=null;s.next_at=now;
            } else if (this.r.splitCapture && s.control.observations === 1) {
              C.validate(page.record);
              page.record.extra.discovery = {method:'task_search',candidate:s.card_meta?.[s.note_id] || null};
              if(this.keywordState(s)?.terms.length>1)page.record.extra.discovery.matched_keywords=this.keywordHits(s,s.note_id);
              const repair=s.note_repair,request = repair?repair.parent:this.detailRequest(s);
              if(!repair)this.pushOutbox(s,{request,task:s.task.id,lease:s.task.lease_token,record:this.ownerBodyRecord(s,page.record),test_run_id:s.note_test_run || null});
              else {const current=page.record;page.record=JSON.parse(JSON.stringify(repair.record));page.record.extra.comments=current.extra.comments;page.record.standard.comment_count=current.standard.comment_count;}
              s.enrichment = {structured:page.structured||null,repair:!!repair,parent:request,author_navigation:page.author_navigation || null,record:JSON.parse(JSON.stringify(page.record)),stage:'comments',rounds:0,stalls:0,last:null};
              s.phase = 'enrich'; s.next_at = now; s.wait_kind = null;
            } else {
              const comments = page.record.extra.comments;
              // Compare actual loaded content, not just item count: virtual lists
              // and reply updates can change text without increasing the count.
              const snapshot = comments ? JSON.stringify(comments.items.map(item => [item.comment_id || item.key, item.parent_key, item.text])) : null;
              if (s.comment_snapshot != null) {
                s.comment_stalls = snapshot === s.comment_snapshot ? (s.comment_stalls || 0) + 1 : 0;
                s.comment_snapshot = null; // Consume each attempted expansion once, even if admission is denied.
              }
              const empty = comments && page.record.standard.comment_count === 0 && !comments.items.length && !comments.more_available;
              const stalled = (s.comment_stalls || 0) >= (comments?.more_available ? 2 : 1);
              if (comments && !comments.truncated && !empty && !stalled && (s.comment_rounds || 0) < 4) {
                if (!await this.admit(s, 'comment', alive, signal)) return;
                s.comment_snapshot = snapshot;
                // Persist before the DOM action so worker restart cannot repeat an uncounted expansion.
                s.comment_rounds = (s.comment_rounds || 0) + 1;
                s.next_at = this.r.now() + 30000; await this.save(s); alive();
                this.assertTest(s);const progress=await this.r.probe('comments'); alive(); this.checkPage(progress, s, now);
              } else {
                C.validate(page.record);
                if(this.keywordState(s)?.terms.length>1)page.record.extra.discovery={method:'task_search',candidate:s.card_meta?.[s.note_id]||null,matched_keywords:this.keywordHits(s,s.note_id)};
                this.pushOutbox(s,{request: this.detailRequest(s), task: s.task.id, lease: s.task.lease_token, record: this.ownerBodyRecord(s,page.record),test_run_id:s.note_test_run || null});
                s.page_failures = 0;
                s.phase = 'search_done'; s.notes_in_session++; s.note_url = null; s.note_id = null; s.loaded_at = null;
                s.next_at = now + (s.notes_in_session % 8 === 0 ? C.between(300000, 600000, this.r.random) : C.between(30000, 60000, this.r.random));
              }
            }
          }
        }
        await this.save(s); alive();
        // The durable outbox is the crash boundary, not a reason to delay its first send.
        if (s.outbox.length) await this.flushOutbox(s, alive, signal);
        const fastResume=this.r.fastCapture===true&&(s.phase==='search'||s.phase==='idle'&&s.assignment_refresh===true&&s.acceptance_supplement?.state==='admitted');
        await this.schedule(s,fastResume?s.next_at:Math.max(s.next_at,now+30000));
        return !s.outbox.length && ['enrich','search_done'].includes(s.phase) && s.next_at <= this.r.now();
      } catch (err) {
        if(err.message==='native_stop_unknown'&&!signal.aborted){s.enabled=false;s.light_stop_unsettled=true;s.last_error='native_stop_unknown';await this.save(s);await this.r.cancel();return;}
        if(err.message==='light_source_unknown'&&!signal.aborted){s.enabled=false;s.light_source_unsettled=true;s.last_error='light_source_unknown';await this.save(s);await this.r.cancel();return;}
        if (err.message === 'cancelled' || signal.aborted) return;
        alive(); s.last_error = err.message;
        if(s.history_binding_unknown){s.last_error='history_recovery_required';s.history_outbox_retry_at=this.r.now()+60000;await this.save(s);await this.scheduleReceipt(s,s.history_outbox_retry_at);return;}
        if(err.message==='pool_recovery_required')s.pool_failure=err.poolCause||'unknown';
        if (['captcha','rate_limit'].includes(err.message)) {
          // Persist before IO. If reporting fails, the next start must report before any action.
          s.pending_risk = err.message;
          s.next_at = Math.max(s.next_at, now + (err.message === 'rate_limit' ? 86400000 : 1800000));
          await this.save(s);
          if(!['sending','unknown'].includes(s.risk_report?.state)){
            s.risk_report={kind:err.message,source:'source_gate',state:'sending',at:this.r.now()};await this.save(s);
            try{const reported=await this.control(s,err.message,alive,signal);s.risk_report.state=reported.reason===err.message?'acknowledged':'unknown';}
            catch(_){alive();s.risk_report.state='unknown';}
            if(s.risk_report.state==='unknown')s.pending_risk=err.message;await this.save(s);
          }
        }
        s.failure_kind = ['captcha','rate_limit'].includes(err.message) ? 'platform_gate' :
          ['login_required','identity_verification_required','platform_identity_changed'].includes(err.message) ? 'platform_login' :
          ['sdk_unknown','navigation_failed','navigation_uncommitted','page_loading','probe_timeout'].includes(err.message) ? 'page_transport' :
          ['page_timeout','content_unavailable','wrong_note','invalid_content','invalid_comments','invalid_count','page_mismatch'].includes(err.message) ? 'page_contract' : 'backend';
        const pageFailure = ['page_timeout', 'page_loading', 'content_unavailable', 'probe_timeout', 'wrong_note', 'invalid_content', 'invalid_comments', 'invalid_count'].includes(err.message);
        if (pageFailure) {
          s.page_failures = (s.page_failures || 0) + 1;
          if (s.page_failures >= 3) {
            if(s.test_run){await this.endTest(s,err.message);return;}
            s.enabled = false; await this.save(s); await this.r.cancel(); return;
          }
        }
        if (err.message==='navigation_uncommitted') await this.r.trace?.('navigation_timeout');
        if (s.platform_resume_task&&err.message==='lease_lost') {s.enabled=false;await this.save(s);await this.r.cancel();return;}
        if (['light_authorization_denied','light_checkpoint_mismatch','light_identity_mismatch','light_resume_page_unavailable','history_recovery_required','invalid_owner_keywords','owner_keyword_storage_full','owner_keyword_storage_unavailable','owner_keyword_log_mismatch','owner_keyword_relation_pending','sdk_unknown','test_expired','parallel_unavailable','pool_recovery_required','identity_verification_required','platform_identity_changed','owner_search_reconciliation_required','owner_search_navigation_unknown','navigation_failed', 'navigation_uncommitted', 'page_loading', 'page_timeout', 'content_unavailable', 'probe_timeout', 'captcha', 'rate_limit', 'login_required', 'backend_login_required', 'page_mismatch', 'approval_required', 'consent_required', 'review_local_rejections', 'unsupported_platform'].includes(err.message) || err.status === 401 || err.status === 403) {
          const backendError=err.status===401?'backend_login_required':err.status===403?'backend_permission_denied':null;
          if(s.test_run){await this.endTest(s,backendError||err.message,{drain:!backendError});return;}
          if(backendError)s.last_error=backendError;
          if(err.status===401 || err.status===403){s.delivery_enabled=false;s.delivery_error=err.status===403?'backend_permission_denied':'backend_login_required';await this.r.cancelDelivery?.();}
          s.enabled = false; await this.save(s); await this.r.cancel(); return;
        }
        if (pageFailure || err.message === 'wrong_note') {
          const multi=this.keywordState(s);if(multi){
            multi.page_cursor=0;multi.link_cursor=0;multi.priority_pass=0;
            if(s.note_id && !s.outbox.some(item=>item.task===s.task.id && item.record?.standard?.note_id===s.note_id))s.seen=s.seen.filter(id=>id!==s.note_id);
          }
          s.phase = 'idle'; s.search_round = 0; s.candidates = []; s.note_url = null; s.note_id = null;
        }
        s.next_at = Math.max(s.next_at, now + (pageFailure ? 60000 * 2 ** (s.page_failures - 1) : 60000));
        s.retry_at = s.next_at; s.wait_kind = 'retry';
        if (s.outbox.length) { const item = s.outbox[0]; item.retries = (item.retries || 0) + 1; item.retry_at = now + Math.min(900000, 60000 * 2 ** Math.min(item.retries - 1, 4)); s.next_at = item.retry_at; }
        await this.save(s); await this.schedule(s,s.next_at);
      }
    }
    async scheduleReceipt(s, at) {
      if (s.enabled) await this.schedule(s,at);
      else await this.r.scheduleDelivery?.(at);
    }
    async queueRating(proof, score, reason) {
      await this.initializeGeneration();
      if (this.maintenance) throw new Error('update_in_progress');
      if (!Number.isSafeInteger(proof) || proof < 1 || !Number.isInteger(score) || score < 1 || score > 5 ||
        typeof reason !== 'string' || reason.length > 200 || reason.replace(/[\s\p{P}\p{S}]/gu,'').length < 8) throw new Error('invalid_rating');
      const generation = this.generation;
      await this.active?.catch(()=>{});
      if (generation !== this.generation) throw new Error('cancelled');
      if (this.maintenance) throw new Error('update_in_progress');
      if (this.active) return this.queueRating(proof, score, reason);
      this.active = (async()=>{
        const s=await this.read(); if(s.consent!==C.CONSENT)throw new Error('consent_required');
        if(s.rating_receipts?.some(i=>i.proof===proof))throw new Error('already_rated');
        if(s.outbox.some(i=>i.kind==='rating'&&i.proof===proof))throw new Error('rating_queued');
        if(s.outbox.length>=100)throw new Error('queue_full');
        s.outbox.push({kind:'rating',request:this.r.uuid(),proof,score,rating_reason:reason});
        s.delivery_enabled=true;await this.save(s);await this.repairDelivery();
      })().finally(()=>{this.active=null;});
      return this.active;
    }
    async restoreBackendSession(restore, valid = async()=>true) {
      await this.initializeGeneration();
      if (this.active || this.stopping || this.maintenance) throw new Error('executor_busy');
      const generation=this.generation, stop=this.stopIntent || 0;
      const check=async()=>{
        if (!await valid() || generation!==this.generation || stop!==(this.stopIntent || 0) || this.stopping || this.maintenance) throw new Error('cancelled');
        return true;
      };
      this.active=(async()=>{
        const s=await this.read();await check();
        if (s.enabled) throw new Error('executor_busy');
        if (s.consent!==C.CONSENT) throw new Error('consent_required');
        await restore(check);await check();
        // Keep the stopped source state and all original requests; only reopen delivery.
        s.delivery_enabled=true;
        if (['backend_login_required','backend_permission_denied'].includes(s.delivery_error)) s.delivery_error=null;
        if (['backend_login_required','backend_permission_denied'].includes(s.last_error)) s.last_error='user_stopped';
        await this.save(s);await check();await this.repairDelivery();await check();
        return {restored:true};
      })().finally(()=>{this.active=null;});
      return this.active;
    }
    async repairDelivery() {
      const s = await this.read();
      if (s.consent === C.CONSENT && (s.enabled || s.delivery_enabled) && s.outbox.length) await this.r.scheduleDelivery?.(Math.max(this.r.now()+1000,s.outbox[0].retry_at||0,s.history_binding_unknown?s.history_outbox_retry_at||0:0));
      else await this.r.cancelDelivery?.();
    }
    readyDeliveryContinuation(s) {
      const next=s.outbox[0];
      return this.r.fastDelivery===true && !this.maintenance && !this.stopping &&
        (s.enabled===true || s.delivery_enabled===true) && !!next && ['comments','structured','root_comment'].includes(next.kind) &&
        (next.retry_at||0)<=this.r.now() && !['backend_login_required','backend_permission_denied','review_local_rejections'].includes(s.delivery_error);
    }
    commentBearing(item) {
      return ((!item.kind||item.kind==='note')&&item.record?.extra?.comments!==undefined)||item.kind==='comments'||item.kind==='root_comment'||item.kind==='structured'&&item.record?.kind==='comments';
    }
    outboxOwner(s) {return s.owner_id||(!this.r.owner?'standalone':null);}
    parentMatchesTask(s,item,task) {
      const owner=this.outboxOwner(s);
      return typeof item.parent==='string'&&!!owner&&(
        (s.accepted_parents||[]).some(p=>p.parent===item.parent&&p.owner===owner&&p.task===task.id&&p.lease===task.lease_token)||
        (s.outbox||[]).some(p=>!p.kind&&p.request===item.parent&&p.task===task.id&&p.lease===task.lease_token)||
        (task.repair_notes||[]).some(p=>p.parent===item.parent));
    }
    taskScope(s,item) {
      const t=s.task,owner=this.outboxOwner(s);
      if(!t||!owner||!Number.isSafeInteger(t.id)||typeof t.lease_token!=='string'||!t.lease_token)return null;
      if(item.task!==undefined&&item.task!==t.id||item.lease!==undefined&&item.lease!==t.lease_token)return null;
      const installation=t.node_run?.installation_id||null;
      if(item.installation!==undefined&&item.installation!==installation)return null;
      if(item.task===undefined||item.lease===undefined){if(item.kind!=='note'||!this.parentMatchesTask(s,item,t))return null;}
      const mode=t.comments_capture===true||t.owner_base_task!==true&&t.structured_capture===true?'comments_and_replies':t.owner_base_task===true&&t.root_comments?.enabled===true?(t.root_comments.include_replies===true?(t.root_comments.include_roots===false?'owner_replies':'owner_roots_and_replies'):'roots'):'none';
      return {schema:'crowd-outbox-scope-v1',owner,task:t.id,lease:t.lease_token,installation,request:item.request,kind:item.kind||'body',parent:item.parent||null,mode};
    }
    outboxScope(s,item) {
      if(item.kind==='light_text'){
        const a=item.authorization;
        return a?.schema==='crowd-light-outbox-scope-v1'&&a.owner===this.outboxOwner(s)&&a.task===item.task&&a.lease===item.lease&&a.installation===item.installation&&a.request===item.request&&a.parent===item.parent&&a.selected===true?'allow':'unknown';
      }
      if(!this.commentBearing(item))return 'allow';
      let scope=item.authorization;
      if(scope!==undefined){
        if(!scope||scope.schema!=='crowd-outbox-scope-v1'||scope.owner!==this.outboxOwner(s)||scope.request!==item.request||scope.kind!==(item.kind||'body')||scope.parent!==(item.parent||null)||!Number.isSafeInteger(scope.task)||typeof scope.lease!=='string'||!scope.lease||item.task!==undefined&&item.task!==scope.task||item.lease!==undefined&&item.lease!==scope.lease||item.installation!==undefined&&item.installation!==scope.installation||!['none','roots','owner_replies','owner_roots_and_replies','comments_and_replies'].includes(scope.mode))return 'unknown';
      }else scope=this.taskScope(s,item);
      if(!scope)return 'unknown';
      if(scope.mode==='comments_and_replies')return 'allow';
      if(item.kind==='root_comment'){
        if(item.record?.kind==='coverage')return ['roots','owner_replies','owner_roots_and_replies'].includes(scope.mode)?'allow':'denied';
        const reply=typeof item.record?.parent_comment_id==='string';
        if(reply&&['owner_replies','owner_roots_and_replies'].includes(scope.mode))return 'allow';
        if(!reply&&['roots','owner_roots_and_replies'].includes(scope.mode))return 'allow';
      }
      return 'denied';
    }
    pushOutbox(s,item) {
      if(this.commentBearing(item)){
        const scope=this.taskScope(s,item);
        if(scope)item={...item,authorization:scope};
      }
      s.outbox.push(item);
    }
    async holdOutboxScope(s,decision) {
      s.enabled=false;s.delivery_enabled=false;s.last_error=decision==='denied'?'unselected_comments_in_body':'outbox_scope_unknown';s.delivery_error=s.last_error;
      await this.save(s);await this.r.cancel?.();await this.r.cancelDelivery?.();
    }
    captureScope(s) {
      if(this.r.localTest===true && s.owner_id==='7033ff0c-65d7-4963-b65c-a4ac9e31f03a' && s.test_run?.state==='active')return s.test_run.id;
      const run=s.task?.node_run;
      return this.r.siteSDK===true && s.task?.capabilities?.site_sdk_v1===true && run?.task_id===s.task.id &&
        /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(run?.run_id||'') ? run.run_id : null;
    }
    captureMetrics(s) {return s.test_run || (s.sdk_metrics ||= {});}
    batchAllowed(s) {
      return this.r.batchObservations===true && (this.r.localTest===true && s.owner_id==='7033ff0c-65d7-4963-b65c-a4ac9e31f03a' ||
        s.task?.capabilities?.batch_observe_v1===true && Date.parse(s.task.lease_until)>this.r.now()) && s.batch_endpoint_unavailable!==true;
    }
    observationBatch(s) {
      if(!this.batchAllowed(s))return null;
      const first=s.outbox[0];
      if(!first || !['comments','structured'].includes(first.kind) || first.kind==='structured' &&
        (first.record?.kind!=='comments' || first.record?.source!=='page_response'))return null;
      if(this.r.localTest!==true && (s.task?.id!==first.task || s.task?.lease_token!==first.lease))return null;
      const pending=s.pending_observation_batch;
      if(pending) {
        if(pending.owner!==s.owner_id || pending.kind!==first.kind || pending.parent!==first.parent || pending.task!==first.task || pending.lease!==first.lease ||
          !Array.isArray(pending.rows) || pending.rows.length<2 || pending.rows.length>4 || pending.rows.some((p,i)=>
            s.outbox[i]?.request!==p.request || s.outbox[i]?.kind!==first.kind || s.outbox[i]?.parent!==first.parent ||
            s.outbox[i]?.task!==first.task || s.outbox[i]?.lease!==first.lease || (s.outbox[i]?.retry_at||0)>this.r.now() || JSON.stringify(s.outbox[i]?.record)!==p.snapshot))throw Error('invalid_receipt');
        return s.outbox.slice(0,pending.rows.length);
      }
      const rows=[];let bytes=0;
      for(const item of s.outbox.slice(0,4)) {
        if(item.kind!==first.kind || item.parent!==first.parent || item.task!==first.task || item.lease!==first.lease ||
          item.record?.run!==first.record.run || item.record?.total!==first.record.total || item.record?.page!==first.record.page+rows.length ||
          item.kind==='structured' && (item.record.kind!=='comments' || item.record.source!=='page_response') || (item.retry_at||0)>this.r.now())break;
        const size=new TextEncoder().encode(JSON.stringify({request:item.request,data:item.record})).length;
        if(bytes+size>400000)break;
        bytes+=size;rows.push(item);
      }
      return rows.length>=2?rows:null;
    }
    async flushObservationBatch(s,alive,signal,rows) {
      const first=rows[0];
      s.pending_observation_batch ||= {owner:s.owner_id,kind:first.kind,parent:first.parent,task:first.task,lease:first.lease,
        rows:rows.map(i=>({request:i.request,snapshot:JSON.stringify(i.record)}))};
      await this.save(s);alive();
      const result=await this.api.rpc('batch_observe',{p_parent:first.parent,p_task:first.task,p_lease:first.lease,p_kind:first.kind,
        p_pages:rows.map(i=>({request:i.request,data:i.record}))},signal);alive();
      if(!result || typeof result.halted!=='boolean' || !Array.isArray(result.receipts) || result.receipts.length<1 || result.receipts.length>rows.length ||
        Object.keys(result).some(k=>!['receipts','halted'].includes(k)) || !result.halted && result.receipts.length!==rows.length)throw Error('invalid_receipt');
      // Validate the whole returned prefix before changing any queue or ACK ledger.
      for(const [index,receipt] of result.receipts.entries()) {
        const item=rows[index],last=index===result.receipts.length-1;
        if(!receipt || receipt.request!==item.request || receipt.gate!==(result.halted && last?'rejected':'observed') ||
          receipt.gate==='observed' && (receipt.run!==item.record.run || receipt.page!==item.record.page || item.kind==='structured' &&
            (receipt.source!==item.record.source || receipt.reward_eligible!==false)))throw Error('invalid_receipt');
      }
      for(const [index,receipt] of result.receipts.entries()) {
        const item=rows[index];
        if(receipt.gate==='rejected') {
          s.rejected.push({...item,reason:receipt.error||'invalid_record'});
          if(item.kind==='structured')s.structured_partial=true;else s.comment_failures=(s.comment_failures||0)+1;
        } else if(item.kind==='structured')this.acknowledgeExperimentalAPI(s,item,receipt);
        else if(item.record.page===item.record.total-1 && s.task?.repair_notes?.some(n=>n.parent===item.parent)) {
          s.repaired ||= [];if(!s.repaired.includes(item.parent))s.repaired.push(item.parent);
        }
      }
      s.outbox.splice(0,result.receipts.length);delete s.pending_observation_batch;
      await this.save(s);alive();
      if(result.receipts.some(receipt=>receipt.gate==='rejected')&&this.rejectionNeedsReview(s))throw Error('review_local_rejections');
      await this.scheduleReceipt(s,this.r.now()+(result.halted?1000:250));
      return !result.halted && this.readyDeliveryContinuation(s);
    }
    async flushOutbox(s, alive, signal) {
      const now = this.r.now();
      const item = s.outbox[0];
      if((this.commentBearing(item)||item.kind==='light_text')&&this.r.owner&&s.owner_id!==await this.r.owner())throw Error('cancelled');
      alive();
      const decision=this.outboxScope(s,item);
      if(decision!=='allow'){await this.holdOutboxScope(s,decision);return;}
      if ((item.retry_at || 0) > now) { await this.scheduleReceipt(s, item.retry_at); return; }
      if(s.history_binding_unknown&&s.pending_observation_batch){s.history_outbox_retry_at=now+60000;await this.save(s);await this.scheduleReceipt(s,s.history_outbox_retry_at);return;}
      // Rollback preserves each original UUID and public record.
      if(s.pending_observation_batch && !this.batchAllowed(s)) {
        delete s.pending_observation_batch;await this.save(s);alive();
      }
      const batch=s.history_binding_unknown?null:this.observationBatch(s);
      if(batch) {
        const denied=batch.map(row=>this.outboxScope(s,row)).find(value=>value!=='allow');
        if(denied){await this.holdOutboxScope(s,denied);return;}
        try{return await this.flushObservationBatch(s,alive,signal,batch);}
        catch(error) {
          // PGRST202 is a definite missing RPC, before execution. Unknown network or
          // malformed ACK outcomes retain the original batch and are never retried here.
          if(error.code!=='PGRST202')throw error;
          s.batch_endpoint_unavailable=true;delete s.pending_observation_batch;await this.save(s);alive();
        }
      }
      if(item.kind==='root_comment') {
        const receipt=await this.api.rpc('base_root_receipt',{p_request:item.request,p_task:item.task,p_lease:item.lease,p_installation:item.installation,p_parent:item.parent,p_data:item.record},signal);alive();
        if(!receipt||receipt.gate!=='observed'||receipt.request!==item.request||receipt.task!==item.task||receipt.parent!==item.parent||typeof receipt.inserted!=='boolean'||typeof receipt.duplicate!=='boolean'||receipt.duplicate===receipt.inserted)throw Error('invalid_receipt');
        s.outbox.shift();await this.save(s);await this.scheduleReceipt(s,now+1000);return this.readyDeliveryContinuation(s);
      }
      if(item.kind==='light_text') {
        const receipt=await this.api.rpc('base_light_receipt',{p_request:item.request,p_task:item.task,p_lease:item.lease,p_installation:item.installation,p_parent:item.parent,p_data:item.record},signal);alive();
        if(!receipt||receipt.gate!=='observed'||receipt.request!==item.request||receipt.task!==item.task||receipt.parent!==item.parent||receipt.inserted!==true||receipt.duplicate!==false)throw Error('invalid_receipt');
        if(s.light_resume?.state==='waiting_ack'&&s.light_resume.last_request===item.request&&s.light_resume.parent===item.parent){if(s.light_resume.sequence===0||s.light_resume.pause_pending===true){s.light_resume.state='acked';delete s.light_resume.pause_pending;}else delete s.light_resume;}
        s.outbox.shift();await this.save(s);await this.scheduleReceipt(s,now+1000);return this.readyDeliveryContinuation(s);
      }
      if(item.kind==='keyword_hit') {
        const receipt=await this.api.rpc('keyword_hit',{p_request:item.request,p_task:item.task,p_lease:item.lease,p_note:item.note_id,p_keyword:item.keyword},signal);alive();
        if(s.history_binding_unknown&&receipt?.error)throw Error('history_receipt_unconfirmed');
        if(receipt?.error){s.enabled=false;s.delivery_enabled=false;s.last_error='owner_keyword_relation_pending';s.delivery_error=receipt.error;await this.save(s);await this.r.cancel();return;}
        if(!receipt||receipt.gate!=='observed'||receipt.request!==item.request||receipt.task!==item.task||receipt.note_id!==item.note_id||receipt.keyword!==item.keyword)throw Error('invalid_receipt');
        const state=s.history_binding_unknown?null:this.keywordState(s);if(state && s.task.id===item.task){state.delivered ||= {};const words=state.delivered[item.note_id] ||= [];if(!words.includes(item.keyword))words.push(item.keyword);}
        s.outbox.shift();await this.save(s);await this.scheduleReceipt(s,now+1000);return;
      }
      if(item.kind==='structured') {
        const receipt=await this.api.rpc('structured_observe',{p_request:item.request,p_parent:item.parent,p_task:item.task,p_lease:item.lease,p_data:item.record},signal);alive();
        if(s.history_binding_unknown&&receipt?.gate==='rejected')throw Error('history_receipt_unconfirmed');
        if(!receipt || receipt.request!==item.request || !['observed','rejected'].includes(receipt.gate) || receipt.gate==='observed'&&(receipt.run!==item.record.run||receipt.page!==item.record.page||receipt.source!==item.record.source||receipt.reward_eligible!==false))throw Error('invalid_receipt');
        if(receipt.gate==='rejected'){s.rejected.push({...item,reason:receipt.error||'invalid_record'});if(this.r.experimentalAPIEarlyFinish===true)s.structured_partial=true;}
        else this.acknowledgeExperimentalAPI(s,item,receipt);
        s.outbox.shift();await this.save(s);if(receipt.gate==='rejected'&&this.rejectionNeedsReview(s))throw Error('review_local_rejections');await this.scheduleReceipt(s,this.r.fastCapture===true&&receipt.gate==='observed'?this.r.now()+250:now+1000);return receipt.gate==='observed' && this.readyDeliveryContinuation(s);
      }
      if (item.kind === 'rating') {
        const receipt=await this.api.rpc('rating',{p_request:item.request,p_proof:item.proof,p_score:item.score,p_reason:item.rating_reason},signal);alive();
        if(s.history_binding_unknown&&receipt?.gate==='rejected')throw Error('history_receipt_unconfirmed');
        if(receipt?.request!==item.request || !['rated','rejected'].includes(receipt.gate) ||
          (receipt.gate==='rated' && typeof receipt.inserted!=='boolean') ||
          (receipt.gate==='rejected' && !['invalid_rating','invalid_anchor','already_rated','request_reused'].includes(receipt.error)))throw new Error('invalid_receipt');
        if(receipt.gate==='rejected')s.rejected.push({...item,reason:receipt.error});
        else (s.rating_receipts ||= []).push({kind:'rating',request:item.request,proof:item.proof,score:item.score,rating_reason:item.rating_reason,gate:'rated',inserted:receipt.inserted});
        s.outbox.shift();if(receipt.gate==='rejected' && this.rejectionNeedsReview(s))throw new Error('review_local_rejections');await this.save(s);await this.scheduleReceipt(s,now+30000);return;
      }
      if (item.kind) {
        const receipt = await this.api.rpc(item.kind==='comments'?'comments_observe':'observe', item.kind==='comments'?{p_request:item.request,p_parent:item.parent,p_task:item.task,p_lease:item.lease,p_data:item.record}:{p_request:item.request,p_parent:item.parent,p_kind:item.kind,p_data:item.record}, signal); alive();
        if(s.history_binding_unknown&&receipt?.gate==='rejected')throw Error('history_receipt_unconfirmed');
        if (!receipt || receipt.request !== item.request || !['observed','rejected'].includes(receipt.gate)) throw new Error('invalid_receipt');
        if (receipt.gate === 'rejected') {s.rejected.push({...item,reason:receipt.error || 'invalid_record'});if(item.kind==='comments')s.comment_failures=(s.comment_failures||0)+1;}
        if(item.kind==='comments' && receipt.gate==='observed' && item.record.page===item.record.total-1 && s.task?.repair_notes?.some(n=>n.parent===item.parent)){s.repaired ||= [];if(!s.repaired.includes(item.parent))s.repaired.push(item.parent);}
        s.outbox.shift(); if(receipt.gate==='rejected' && this.rejectionNeedsReview(s))throw new Error('review_local_rejections'); await this.save(s); await this.scheduleReceipt(s,this.r.fastCapture===true&&item.kind==='comments'&&receipt.gate==='observed'?this.r.now()+250:now+(item.kind==='comments'&&receipt.gate==='observed'?1000:30000)); return item.kind==='comments' && receipt.gate==='observed' && this.readyDeliveryContinuation(s);
      }
      let bodyOnlyFinished=false;
      const receipt = C.receipt(await this.api.rpc('submit', {p_request: item.request, p_task: item.task,
        p_lease: item.lease, p_record: item.record}, signal), item.request);
      alive();
      if(s.history_binding_unknown&&receipt.error)throw Error('history_receipt_unconfirmed');
      if(s.acceptance_supplement?.state==='admitted'&&!receipt.error&&receipt.inserted===true&&(item.task!==s.acceptance_supplement.task_id||receipt.duplicate===true||receipt.task_received!==(s.task?.received??s.acceptance_supplement.baseline_received)+1||receipt.task_received>this.supplementTarget(s.acceptance_supplement)||s.history.includes(item.record.standard.note_id)))throw Error('invalid_receipt');
      if (receipt.error === 'daily_quota') {
        item.retry_at = C.quotaRetry(receipt, now); s.last_error = 'daily_quota'; await this.save(s); await this.scheduleReceipt(s, item.retry_at); return;
      } else if (receipt.error === 'lease_expired') {
        const reason=!s.enabled&&s.task?.owner_base_task===true?'base_lease_unknown':'outbox_lease_unknown';
        s.enabled=false;s.delivery_enabled=false;s.last_error=reason;s.delivery_error=reason;
        await this.save(s);await this.r.cancel?.();await this.r.cancelDelivery?.();return;
      } else if (receipt.error === 'lease_lost') {
        // No server ACK exists for this UUID. Keep its body for reconciliation.
        s.enabled=false;s.delivery_enabled=false;s.last_error=receipt.terminal_reason?'base_stop_terminal:'+receipt.terminal_reason:'lease_lost';s.delivery_error=s.last_error;
        await this.save(s);await this.r.cancel();await this.r.cancelDelivery?.();
        try {await this.r.close(s.owner_id);}catch(error){s.pool_cleanup_error=error.poolCause||'unknown';await this.save(s);}
        return;
      } else {
        s.outbox.shift();
        const slot=s.work_slots?.find(slot=>slot.request===item.request);
        if(slot){if(receipt.error){slot.phase='done';slot.enrichment=null;}else slot.base_received=true;}
        if (receipt.error) {
          s.rejected.push({...item, reason: receipt.error,relevance_revision:Math.max(item.relevance_revision||0,s.task?.id===item.task?s.task.relevance_revision||0:0,s.control_task===item.task?s.control?.relevance_revision||0:0)});
          for(let i=s.outbox.length-1;i>=0;i--)if(s.outbox[i].kind==='light_text'&&s.outbox[i].parent===item.request&&s.outbox[i].task===item.task){s.rejected.push({...s.outbox[i],reason:'parent_rejected'});s.outbox.splice(i,1);}
          if(s.owner_reply_checkpoint?.parent===item.request&&s.owner_reply_checkpoint.task===item.task){s.owner_reply_checkpoint.state='body_rejected';s.owner_reply_checkpoint.body_error=receipt.error;s.enabled=false;s.last_error='reply_body_rejected';}
          if (s.enrichment?.parent === item.request) { s.enrichment = null; s.phase = 'search_done'; }
        }
        else {
          if(!s.history_binding_unknown)s.last_error = null;
          if(!s.history_binding_unknown&&receipt.inserted===true && s.task?.id===item.task && this.keywordState(s)?.terms.length>1){
            const state=this.keywordState(s);state.delivered ||= {};
            state.delivered[item.record.standard.note_id]=[...(item.record.extra?.discovery?.matched_keywords||[])];
          }
          s.accepted_parents=[...(s.accepted_parents||[]).filter(p=>p.parent!==item.request),
            {parent:item.request,owner:s.owner_id,task:item.task,lease:item.lease,note:item.record.standard.note_id}].slice(-200);
          s.received += receipt.inserted ? 1 : 0;
          if(s.test_run && item.test_run_id===s.test_run.id && receipt.inserted && !receipt.duplicate && !s.test_run.accepted.some(a=>a.request===item.request || a.note_id===item.record.standard.note_id)) {
            s.test_run.accepted.push({request:item.request,note_id:item.record.standard.note_id});
          }
          s.history = [...new Set([...s.history, item.record.standard.note_id])].slice(-2000);
          if (s.task?.id === item.task) {
            const newlyReceived=Math.max(0,receipt.task_received-s.task.received);
            s.task.received=Math.max(s.task.received,receipt.task_received);
            if(s.task.remaining_today!=null)s.task.remaining_today=Math.max(0,s.task.remaining_today-newlyReceived);
          }
          if(this.r.fastCapture===true&&s.task?.id===item.task&&s.task.comments_capture===false&&s.task.structured_capture===false&&s.profiles!==true&&s.enrichment?.parent===item.request&&s.enrichment.stage==='comments'&&!s.sdk_unknown&&!s.sdk_pending&&!s.enrichment.sdk_pending&&!s.pending_risk){
            s.enrichment=null;s.phase='search_done';s.note_url=null;s.note_id=null;s.loaded_at=null;s.notes_in_session++;s.next_at=this.r.now();bodyOnlyFinished=true;
          }
        }
      }
      const supplement=s.acceptance_supplement;
      if(supplement?.state==='admitted'&&!receipt.error&&receipt.inserted===true&&receipt.duplicate!==true&&item.task===supplement.task_id&&!supplement.baseline_history.includes(item.record.standard.note_id)){
        supplement.remaining=Math.max(0,this.supplementTarget(supplement)-receipt.task_received);
        if(supplement.remaining===0){
          supplement.state='consumed';supplement.request=item.request;supplement.consumed_at=this.r.now();
          await this.parkPilot(s,{error:'test_completed',pilot_phase:'awaiting_acceptance'},alive);
        }
      }
      // Failed records remain exportable; bounded by stopping, never by deleting evidence.
      if (receipt.error && this.rejectionNeedsReview(s)) throw new Error('review_local_rejections');
      await this.save(s); await this.scheduleReceipt(s,bodyOnlyFinished?this.r.now()+250:now+30000); return;
    }
    saveStructuredDiagnostic(s,e,value) {
      const diag=value.observer_diagnostics;
      const counts=['fetch_calls','xhr_calls','matched_requests','responses','parse_failures','wrong_note','invalid_picture','invalid_page','page_budget','response_failed'];
      const flags=['fetch_hook_current','xhr_hook_current','marker_retained'];
      const errorKinds=['unknown_parent','cursor_out_of_order','cursor_stalled','page_conflict','root_metadata_conflict','item_conflict','page_budget','invalid_page','response_failed','late_binding','csp_or_install_blocked','body_unavailable'];
      if(!diag || typeof diag!=='object' || Array.isArray(diag) || Object.keys(diag).length!==counts.length+flags.length ||
        Object.keys(diag).some(key=>!counts.includes(key)&&!flags.includes(key)) ||
        counts.some(key=>!Number.isInteger(diag[key]) || diag[key]<0 || diag[key]>10000) || flags.some(key=>typeof diag[key]!=='boolean') ||
        !/^[a-f0-9]{24}$/.test(value.note_id) || !Number.isSafeInteger(s.task.id) || s.task.id<=0 || !['installed','waiting','csp_or_not_installed'].includes(value.observer_status) ||
        !Array.isArray(value.errors) || value.errors.length>12 || value.errors.some(error=>!errorKinds.includes(error)))return;
      const at=this.r.now();if(!Number.isSafeInteger(at)||at<0||at>8640000000000000)return;
      const owner=s.owner_id||this.generationOwner||'standalone';
      const oldRows=Array.isArray(s.structured_diagnostics)?s.structured_diagnostics:[];
      const allowedRow=['owner_id','task_id','note_id','observer_status','captured_at','errors','counts'];
      const safeRows=oldRows.filter(row=>row&&typeof row==='object'&&Object.keys(row).length===allowedRow.length&&Object.keys(row).every(key=>allowedRow.includes(key))&&
        row.owner_id===owner&&Number.isSafeInteger(row.task_id)&&row.task_id>0&&/^[a-f0-9]{24}$/.test(row.note_id)&&['installed','waiting','csp_or_not_installed'].includes(row.observer_status)&&
        typeof row.captured_at==='string'&&/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(row.captured_at)&&
        Array.isArray(row.errors)&&row.errors.length<=12&&row.errors.every(error=>errorKinds.includes(error))&&row.counts&&typeof row.counts==='object'&&Object.keys(row.counts).length===counts.length+flags.length&&
        counts.every(key=>Number.isInteger(row.counts[key])&&row.counts[key]>=0&&row.counts[key]<=10000)&&flags.every(key=>typeof row.counts[key]==='boolean'));
      s.structured_diagnostics=[...safeRows.slice(-1),
        {owner_id:owner,task_id:s.task.id,note_id:value.note_id,observer_status:value.observer_status,captured_at:new Date(at).toISOString(),
          errors:[...value.errors],counts:Object.fromEntries([...counts,...flags].map(key=>[key,diag[key]]))}];
    }
    queueStructuredPages(s,e,reason=null) {
      if(!s.task?.structured_capture || e.structured_queued)return;
      const value=e.structured;
      if(!value || value.note_id!==e.record.standard.note_id){s.structured_partial=true;return;}
      if(reason || value.complete!==true || value.mode!=='passive_hybrid' || value.observer_status!=='installed' || !value.pages?.length ||
         value.dom_witness.reported_count!==null && value.dom_witness.reported_count!==value.items.length)s.structured_partial=true;
      this.saveStructuredDiagnostic(s,e,value);
      if(value.body?.source==='page_hydration')s.outbox.push({kind:'structured',request:this.r.uuid(),parent:e.parent,task:s.task.id,lease:s.task.lease_token,
        record:{kind:'body',source:'page_hydration',run:this.r.uuid(),page:0,total:1,note_id:value.note_id,body:value.body,summary:{reward_eligible:false,body_dom_match:value.body_dom_match===true,observer_status:value.observer_status}}});
      if(value.mode==='passive_hybrid' && (value.pages.length || value.observer_status==='installed')){
        const hasPages=value.pages.length>0,items=hasPages?value.items:[];
        const summary={reward_eligible:false,source:'page_response',mode:value.mode,observer_status:value.observer_status,
          captured_count:items.length,root_count:items.filter(i=>i.parent===null).length,reply_count:items.filter(i=>i.parent!==null).length,
          image_count:items.reduce((n,i)=>n+i.pictures.length,0),groups:hasPages?value.groups:[],main_ended:hasPages&&value.main_ended===true,
          api_complete:hasPages&&!reason&&value.complete===true,complete:hasPages&&!reason&&value.complete===true&&(value.dom_witness.reported_count===null||value.dom_witness.reported_count===items.length),
          reported_count:value.dom_witness.reported_count,count_gap:value.dom_witness.reported_count===null?null:value.dom_witness.reported_count-items.length,
          dom_matched:value.dom_witness.matched===true,errors:value.errors,capture_reason:reason||'hybrid_finished'};
        const chunks=[];let chunk=[],bytes=0;for(const item of items){const size=new TextEncoder().encode(JSON.stringify(item)).length;if(chunk.length&&(chunk.length>=50||bytes+size>120000)){chunks.push(chunk);chunk=[];bytes=0;}chunk.push(item);bytes+=size;}
        if(chunk.length||!chunks.length)chunks.push(chunk);const run=this.r.uuid();
        chunks.forEach((items,page)=>this.pushOutbox(s,{kind:'structured',request:this.r.uuid(),parent:e.parent,task:s.task.id,lease:s.task.lease_token,
          record:{kind:'comments',source:'page_response',run,page,total:chunks.length,note_id:value.note_id,items,summary}}));
      }
      if(e.api_early_finish===true && this.r.experimentalAPIEarlyFinish===true) {
        const rows=s.outbox.filter(i=>i.kind==='structured' && i.parent===e.parent),bodyRow=rows.find(i=>i.record.kind==='body'),pages=rows.filter(i=>i.record.kind==='comments');
        if(bodyRow && pages.length>0 && pages.every(i=>i.record.summary.complete===true)) {
          s.api_capture_ledger ||= [];
          s.api_capture_ledger=[...s.api_capture_ledger.filter(l=>l.parent!==e.parent).slice(-3),
            {owner:s.owner_id,test:s.test_run?.id||null,task:s.task.id,lease:s.task.lease_token,parent:e.parent,note:value.note_id,run:pages[0].record.run,
              body_request:bodyRow.request,body_run:bodyRow.record.run,body_ack:null,confirmed_parent:null,complete:false,
              pages:pages.map(i=>({request:i.request,page:i.record.page,total:i.record.total}))}];
        }
      }
      e.structured_queued=true;
    }
    queueCommentPages(s,e,reason=null) {
      const comments=e.record?.extra?.comments;
      if(!s.task?.comments_capture || !comments || e.capture_queued)return;
      const summary={captured_count:comments.items.length,reported_count:e.record.standard.comment_count,
        timing:e.timings?{...e.timings,elapsed_ms:Math.max(0,this.r.now()-e.timings.started_at_ms)}:null,
        capture_reason:reason || comments.capture_reason || 'interrupted',progress:comments.progress || null,loading:comments.loading===true,media_pending:comments.media_pending===true,image_count:comments.items.reduce((n,i)=>n+(i.media||[]).filter(m=>m.kind==='image').length,0),
        complete:!reason && ['loaded_end','visible_empty'].includes(comments.capture_reason) && !comments.truncated && !comments.media_pending && !comments.identity_uncertain &&
          (e.record.standard.comment_count===null ? comments.progress?.end_marker===true || comments.progress?.empty===true : e.record.standard.comment_count===comments.items.length)};
      const census=comments.dom_census;
      summary.dom_item_count=Number.isSafeInteger(census?.visible_count)?census.visible_count:null;
      summary.dom_skipped_count=Number.isSafeInteger(census?.skipped_count)?census.skipped_count:null;
      summary.terminal_stable=comments.terminal_stable===true;
      summary.root_count=comments.reply_coverage?.root_count ?? null;
      summary.declared_reply_count=comments.reply_coverage?.declared_count ?? null;
      summary.observed_reply_count=comments.reply_coverage?.loaded_count ?? null;
      summary.visible_complete=!reason && summary.terminal_stable && typeof census?.document==='string' &&
        census.visible_count===comments.items.length && census.skipped_count===0 && census.duplicate_count===0 && census.unresolved_parent_count===0 &&
        !comments.truncated && !comments.media_pending && !comments.identity_uncertain && !comments.loading && !comments.more_available &&
        comments.reply_coverage?.pending_groups===0 && summary.declared_reply_count!==null && summary.observed_reply_count===summary.declared_reply_count && summary.root_count+summary.observed_reply_count===summary.captured_count &&
        comments.progress?.expand_count===0 && (comments.progress?.end_marker===true && comments.progress?.at_end===true || comments.progress?.empty===true);
      summary.count_gap=Number.isSafeInteger(summary.reported_count)?summary.reported_count-summary.captured_count:null;
      summary.count_mismatch=summary.count_gap!==null && summary.count_gap!==0;
      s.comment_coverage ||= [];
      s.comment_coverage=[...s.comment_coverage.filter(item=>item.parent!==e.parent),{parent:e.parent,note_id:e.record.standard.note_id,reported:summary.reported_count,captured:summary.captured_count,visible_complete:summary.visible_complete,complete:summary.complete,count_gap:summary.count_gap,capture_reason:summary.capture_reason}].slice(-4);
      if(!summary.complete)s.comment_partial=true;
      const chunks=[];let chunk=[],bytes=0;
      for(const item of comments.items){
        const size=new TextEncoder().encode(JSON.stringify(item)).length;
        if(chunk.length && (chunk.length>=50 || bytes+size>120000)){chunks.push(chunk);chunk=[];bytes=0;}
        chunk.push(item);bytes+=size;
      }
      if(chunk.length || !chunks.length)chunks.push(chunk);
      const run=e.capture_run ||= this.r.uuid();
      chunks.forEach((items,page)=>this.pushOutbox(s,{request:this.r.uuid(),parent:e.parent,kind:'comments',task:s.task.id,lease:s.task.lease_token,
        record:{run,page,total:chunks.length,items,summary}}));
      e.capture_queued=true;
    }
    legacyCommentNote(original) {
      const record=JSON.parse(JSON.stringify(original)), projected=record.extra.comments;
      if(!projected)return record;
      const omitted=projected.items.filter(item=>!item.text).length;
      projected.items=projected.items.filter(item=>item.text);
      projected.omitted_count=(projected.omitted_count||0)+omitted;
      projected.truncated ||= omitted>0;
      while(projected.items.length>50 || JSON.stringify(record).length>55000 && projected.items.length){projected.items.pop();projected.truncated=true;projected.omitted_count++;}
      projected.captured_count=projected.items.length;
      const oldKeys=new Map(projected.items.map(item=>[item.key,item.comment_id]));
      projected.items.sort((a,b)=>Number(a.is_reply)-Number(b.is_reply));
      const keys=new Map(projected.items.map((item,i)=>[item.comment_id,'comment-'+(i+1)]));
      for(const [i,item] of projected.items.entries()){item.parent_key=keys.get(item.parent_comment_id||oldKeys.get(item.parent_key))||null;item.key='comment-'+(i+1);}
      return record;
    }
    mergeComments(previous, current, full = false) {
      if (!current) return previous;
      if (!previous) return JSON.parse(JSON.stringify(current));
      const result = JSON.parse(JSON.stringify(previous));
      const identity = item => item.comment_id ? 'id:'+item.comment_id : JSON.stringify([item.author_display,item.text,item.published_label,item.is_reply]);
      const seen = new Map(result.items.map(item => [identity(item),item]));
      const remap = new Map();
      let nextKey=Math.max(0,...result.items.map(item=>Number(item.key.replace('comment-',''))));
      for (const item of current.items) {
        let known = seen.get(identity(item));
        if (!known) {
          if (!full && (result.items.length >= 50 || JSON.stringify(result).length + JSON.stringify(item).length > 20000)) {result.truncated=true;break;}
          known = {...item,key:'comment-'+(++nextKey),parent_key:remap.get(item.parent_key) || null};
          result.items.push(known); seen.set(identity(item),known);
        } else { const key=known.key,parent=known.parent_key; Object.assign(known,item,{key,parent_key:remap.get(item.parent_key) || parent}); }
        remap.set(item.key,known.key);
      }
      result.captured_count=result.items.length; result.complete=false;
      result.identity_method='platform_id_or_content_fingerprint';result.identity_uncertain=result.items.some(item=>!item.comment_id);
      result.loaded_count=Math.max(previous.loaded_count || 0,current.loaded_count || 0,result.items.length);
      result.omitted_count=Math.max(previous.omitted_count || 0,current.omitted_count || 0);
      result.loading=current.loading===true;result.media_pending=current.media_pending===true;
      result.dom_census=current.dom_census;
      result.reply_coverage=current.reply_coverage;
      result.more_available=current.more_available;result.progress=current.progress; result.truncated ||= current.truncated;
      return result;
    }
    experimentalAPIComplete(s,e,page) {
      // Offline-only experiment: preserve partial DOM receipts and the existing final ACK barrier.
      if(this.r.experimentalAPIEarlyFinish!==true || this.r.localTest!==true ||
        s.owner_id!=='7033ff0c-65d7-4963-b65c-a4ac9e31f03a' || s.enabled!==true || s.test_run?.state!=='active' ||
        !s.test_run.id || !s.task?.structured_capture || !s.task?.comments_capture ||
        !Number.isFinite(Date.parse(s.task.lease_until)) || Date.parse(s.task.lease_until)<this.r.now()+60000 || s.pending_risk || s.control?.paused ||
        ['sending','unknown'].includes(s.risk_report?.state) ||
        ['captcha','rate_limit','login_required','backend_login_required'].includes(s.last_error))return false;
      const v=page.structured,comments=page.record?.extra?.comments,note=e.record.standard.note_id;
      const parentBound=e.repair?s.task.repair_notes?.some(p=>p.parent===e.parent && p.record?.standard?.note_id===note):s.test_run.accepted?.some(p=>p.request===e.parent && p.note_id===note);
      if(!parentBound)return false;
      if(['captcha','rate_limit'].includes(v?.gate))throw new Error(v.gate);
      if(!v || v.note_id!==note || page.record.standard.note_id!==note || v.source!=='page_response' ||
        v.mode!=='passive_hybrid' || v.observer_status!=='installed' || v.gate || v.complete!==true ||
        v.main_ended!==true || v.body_dom_match!==true || !v.body || !Array.isArray(v.errors) || v.errors.length ||
        !Array.isArray(v.pages) || !v.pages.length || !Array.isArray(v.items) || !v.items.length || !Array.isArray(v.groups) ||
        typeof v.document!=='string' || !v.document || v.document!==comments?.dom_census?.document ||
        v.dom_witness?.note_id!==note || v.dom_witness.matched!==true || !v.dom_witness.comment_ids?.length ||
        !Number.isSafeInteger(v.dom_witness.reported_count) || v.dom_witness.reported_count!==v.items.length ||
        page.record.standard.comment_count!==v.items.length)return false;
      const ids=new Map();for(const item of v.items){
        if(!item || !/^[a-f0-9]{24}$/.test(item.id||'') || ids.has(item.id) || !Array.isArray(item.pictures))return false;
        ids.set(item.id,item);
      }
      const roots=v.items.filter(i=>i.parent===null),groups=new Map();
      for(const g of v.groups){
        if(!g || groups.has(g.id) || ids.get(g.id)?.parent!==null || g.ended!==true ||
          !Number.isSafeInteger(g.declared) || g.declared<0 || g.captured!==g.declared ||
          v.items.filter(i=>i.parent===g.id).length!==g.declared)return false;
        groups.set(g.id,g);
      }
      return groups.size===roots.length && roots.every(i=>groups.has(i.id)) &&
        v.items.every(i=>i.parent===null || groups.has(i.parent)) &&
        v.dom_witness.comment_ids.every(id=>ids.has(id)) &&
        comments.items.length>0 && comments.items.every(i=>ids.has(i.comment_id));
    }
    ownerBodyRecord(s,record) {
      if(s.task?.owner_base_task!==true||s.task?.comments_capture===true||record?.extra?.comments===undefined)return record;
      const copy=JSON.parse(JSON.stringify(record));delete copy.extra.comments;return copy;
    }
    lightProcessingAuthorized(s,owner,kind) {
      const p=s?.light_processing,t=s?.task,i=s?.detail_intent;
      try {C.validate(p?.body);return !!(s.enabled&&owner&&s.owner_id===owner&&t?.owner_base_task===true&&t.light_text?.[kind]===true&&
        p?.schema==='crowd-light-progress-v1'&&p.owner===owner&&p.task===t.id&&p.lease===t.lease_token&&p.installation===t.node_run?.installation_id&&
        p.note===s.note_id&&p.body.standard.note_id===p.note&&C.noteURL(s.note_url).id===p.note&&p.stage===(kind==='ocr'?'ocr_running':'asr_running')&&
        i?.admitted===true&&i.task===p.task&&i.lease===p.lease&&i.installation===p.installation&&i.note===p.note&&i.request===p.parent);}
      catch(_){return false;}
    }
    limitLightText(value,maxBytes) {
      const input=Array.from(value),encoder=new TextEncoder();let low=0,high=input.length;
      while(low<high){const middle=Math.ceil((low+high)/2);if(encoder.encode(JSON.stringify(input.slice(0,middle).join(''))).length<=maxBytes)low=middle;else high=middle-1;}
      return {text:input.slice(0,low).join(''),truncated:low<input.length};
    }
    queueLight(s,parent,note,observation,stage=null) {
      const task=s.task,owner=this.outboxOwner(s),installation=task?.node_run?.installation_id;
      if(task?.owner_base_task!==true||!task.light_text||!owner||!installation)throw Error('light_not_authorized');
      if(observation?.note_id!==note)throw Error('light_identity_mismatch');
      const subtitle=observation.subtitle||null,asr=!subtitle&&task.light_text.asr===true?observation.asr||null:null,ocr=task.light_text.ocr===true&&Array.isArray(observation.ocr)?observation.ocr:[],gaps=[];
      if(!subtitle){gaps.push(observation.reason||'subtitle_unavailable');if(task.light_text.asr===true&&(!asr||observation.asr_gap))gaps.push(observation.asr_gap||'audio_source_not_connected');}
      if(task.light_text.ocr===true){if(observation.ocr_gap)gaps.push(observation.ocr_gap);else if(!ocr.length)gaps.push('ocr_source_not_connected');else if(ocr[0].coverage==='first_image_only')gaps.push('ocr_partial_images');}
      const request=this.r.uuid();
      const coverage=observation.audio_coverage||(observation.audio_source_kind==='remote_video'&&Number.isFinite(observation.asr_source_duration)?{processed_until:observation.asr_processed_until||0,duration:observation.asr_source_duration,duration_source:observation.asr_duration_source||'container'}:null);
      const item={kind:'light_text',request,task:task.id,lease:task.lease_token,installation,parent,
        authorization:{schema:'crowd-light-outbox-scope-v1',owner,task:task.id,lease:task.lease_token,installation,request,parent,selected:true},
        record:{note_id:note,status:'partial',reason:subtitle?'source_unverified':observation.reason||'subtitle_unavailable',subtitle,asr,ocr,gaps,...(coverage?{audio_coverage:coverage}:{}),...(stage?{stage}: {})}};
      s.outbox.push(item);return item;
    }
    async readOwnerLight(s,alive,signal,body) {
      const note=s.note_id,task=s.task,intent=s.detail_intent,owner=this.outboxOwner(s),installation=task?.node_run?.installation_id;
      try{
        C.validate(body);
        if(!s.enabled||task?.owner_base_task!==true||!Number.isSafeInteger(task.id)||task.id<=0||!owner||!installation||typeof task.lease_token!=='string'||!task.lease_token||
           !task.light_text||typeof task.light_text.asr!=='boolean'||typeof task.light_text.ocr!=='boolean'||intent?.admitted!==true||typeof intent.request!=='string'||!intent.request||
           intent.task!==task.id||intent.lease!==task.lease_token||intent.installation!==installation||intent.note!==note||body.standard.note_id!==note||C.noteURL(s.note_url).id!==note||
           this.r.owner&&await this.r.owner()!==owner)throw Error('light_authorization_denied');
      }catch(_){throw Error('light_authorization_denied');}
      alive();let result,progress=s.light_processing;
      if(progress){
        if(progress.schema!=='crowd-light-progress-v1'||progress.owner!==owner||progress.task!==task.id||progress.lease!==task.lease_token||progress.installation!==installation||progress.parent!==intent.request||progress.note!==note)throw Error('light_checkpoint_mismatch');
        try{C.validate(progress.body);if(progress.body.standard.note_id!==note)throw Error('invalid');}catch(_){throw Error('light_checkpoint_mismatch');}
        result={note_id:note,subtitle:progress.subtitle,reason:progress.reason};
      }else{
        await this.lightStageControl(s,alive,signal,'subtitle');
        try{result=await this.r.probe('owner_light_read');alive();}
        catch(error){alive();if(['pool_recovery_required','login_required','captcha','rate_limit'].includes(error.message))throw error;result={note_id:note,subtitle:null,reason:'subtitle_probe_failed'};}
        if(result?.gate)throw Error(result.gate);
        if(!result?.note_id)result={note_id:note,subtitle:null,reason:'subtitle_probe_failed'};
        if(result?.note_id!==note)throw Error('light_identity_mismatch');
      }
      if(progress){
        if(['asr_running','ocr_running'].includes(progress.stage))throw Error('native_stop_unknown');
        if(['audio_probe_running','image_probe_running'].includes(progress.stage))throw Error('light_source_unknown');
      }else progress={schema:'crowd-light-progress-v1',owner,task:task.id,lease:task.lease_token,installation,parent:intent.request,note,body:JSON.parse(JSON.stringify(body)),stage:'observed',subtitle:result.subtitle||null,reason:result.reason||null,asr:null,asr_done:false,ocr:[],ocr_done:false};
      while(!progress.asr_done&&s.task.light_text.asr===true&&!progress.subtitle){
        await this.lightStageControl(s,alive,signal,'asr');const index=progress.asr_next||0;
        if(progress.audio_source_kind==='remote_video'&&progress.asr?.chunks?.length>=256){progress.asr_gap='audio_result_limit';progress.asr_done=true;progress.stage='observed';s.light_processing=progress;await this.save(s);if(this.r.cancelLightSource){try{await this.r.cancelLightSource();}catch(_){this.lightSourceUnknown=true;throw Error('light_source_unknown');}}break;}
        if(index===0&&!progress.audio_source_kind){const scope=await this.r.probe('owner_light_audio_scope');alive();if(scope?.gate)throw Error(scope.gate);if(scope?.note_id!==note||!['remote_audio','remote_video','existing_media','unavailable'].includes(scope.kind))throw Error('light_identity_mismatch');progress.audio_source_kind=scope.kind;s.light_processing=progress;await this.save(s);alive();}
        const reacquire=progress.audio_source_kind==='remote_audio'&&!progress.audio_admitted;
        if(reacquire){
          progress.audio_request ||= this.r.uuid();progress.stage='audio_admitting';s.light_processing=progress;await this.save(s);alive();
          const admission=await this.api.rpc('base_light_audio_admit',{p_request:progress.audio_request,p_task:task.id,p_lease:task.lease_token,p_installation:installation,p_parent:intent.request,p_note:note},signal);alive();
          if(admission?.request!==progress.audio_request||admission?.parent!==intent.request||admission?.note_id!==note||typeof admission?.allowed!=='boolean')throw Error('light_authorization_denied');
          progress.stage='observed';if(!admission.allowed){await this.save(s);throw Error(admission.reason||'control_unavailable');}progress.audio_admitted=true;await this.save(s);alive();
        }
        s.light_processing=progress;progress.stage='audio_probe_running';progress.stage_id=this.r.uuid();await this.save(s);alive();
        if(reacquire){progress.audio_started=true;await this.save(s);alive();}
        let audio;try{const action=progress.audio_source_kind==='remote_video'?'owner_light_audio_video_'+index+'_'+progress.stage_id+(index&&progress.audio_ref?'_'+progress.audio_ref:''):reacquire?'owner_light_audio_fetch_'+index+(index&&progress.audio_ref?'_'+progress.audio_ref:''):'owner_light_audio_'+index+(index&&progress.audio_ref?'_'+progress.audio_ref:'');audio=await this.r.probe(action);if(signal.aborted){this.lightCancelled={id:progress.stage_id,stage:progress.stage};throw Error('cancelled');}alive();}catch(error){if(error.message==='light_source_unknown'){this.lightSourceUnknown=true;throw error;}alive();if(['pool_recovery_required','login_required','captcha','rate_limit'].includes(error.message))throw error;audio={note_id:note,status:'unavailable',reason:'audio_probe_failed'};}
        if(progress.audio_source_kind==='remote_video'&&index===0&&audio?.status==='unavailable'&&['audio_mp4_range_unsupported','audio_mp4_access_denied','audio_mp4_validator_unavailable','audio_mp4_track_unavailable','audio_mp4_codec_unavailable','audio_mp4_decoder_unavailable'].includes(audio.reason)){
          try{const fallback=await this.r.probe('owner_light_audio_0');alive();if(fallback?.status==='available'&&fallback.coverage==='playing_media_audio'){audio=fallback;progress.audio_source_kind='existing_media';}}catch(error){if(error.message==='light_source_unknown'){this.lightSourceUnknown=true;throw error;}alive();}
        }
        progress.stage='observed';delete progress.stage_id;await this.save(s);alive();
        if(audio?.gate)throw Error(audio.gate);if(!audio?.note_id)audio={note_id:note,status:'unavailable',reason:'audio_probe_failed'};if(audio.note_id!==note)throw Error('light_identity_mismatch');
        if(progress.audio_source_kind==='remote_video'&&Number.isFinite(audio.source_duration)&&audio.source_duration>0){if(progress.asr_duration_source==='container'&&audio.status==='available'&&Math.abs(progress.asr_source_duration-audio.source_duration)>.05)throw Error('light_checkpoint_mismatch');if(audio.status==='available'||progress.asr_duration_source!=='container'){progress.asr_source_duration=audio.source_duration;progress.asr_duration_source=audio.status==='available'?'container':'media_element';}}
        if(audio.status!=='available')progress.asr_gap=['audio_scope_unavailable','audio_unavailable','audio_source_not_local','audio_format_or_size','audio_duration_limit','audio_decode_failed','audio_checkpoint_unavailable','audio_probe_failed','audio_domain_denied','audio_cors_unavailable','audio_playback_inactive','audio_capture_unavailable','audio_capture_busy','audio_capture_failed','audio_capture_limit','audio_capture_cancelled','audio_capture_empty','audio_cors_or_silence','audio_playback_changed','audio_remote_format_or_size','audio_remote_access_denied','audio_mp4_invalid','audio_mp4_range_invalid','audio_mp4_range_limit','audio_mp4_range_unsupported','audio_mp4_access_denied','audio_mp4_validator_unavailable','audio_mp4_source_changed','audio_mp4_source_limit','audio_mp4_index_limit','audio_mp4_track_unavailable','audio_mp4_codec_unavailable','audio_mp4_decoder_unavailable','audio_mp4_timeline_unavailable','audio_mp4_audio_limit','audio_mp4_decode_failed','audio_mp4_authorization_denied','audio_mp4_admission_unknown','audio_mp4_budget_unavailable'].includes(audio.reason)?audio.reason:'audio_probe_failed';
        else if(audio.index!==index||!Number.isSafeInteger(audio.total)||audio.total<1||audio.coverage!=='remote_video_audio_ranges'&&audio.total>19||index>=audio.total||!Number.isFinite(audio.start)||audio.start<0||audio.coverage!=='remote_video_audio_ranges'&&audio.start>300||!['playing_media_audio','local_media_blob_unverified','remote_audio_stream','remote_video_audio_ranges'].includes(audio.coverage)||(audio.coverage==='playing_media_audio'?progress.playback_end!==undefined&&audio.start+0.05<progress.playback_end:audio.start!==index*16))throw Error('light_checkpoint_mismatch');
        else if(!Number.isFinite(audio.duration)||audio.duration<=0||audio.duration>16||audio.coverage!=='remote_video_audio_ranges'&&audio.start+audio.duration>300.05||!/^[a-f0-9]{64}$/.test(audio.source_ref||'')||progress.audio_ref&&progress.audio_ref!==audio.source_ref||progress.asr_total!==undefined&&progress.asr_total!==audio.total||progress.asr&&progress.asr.coverage!==audio.coverage)throw Error('light_checkpoint_mismatch');
        else if(typeof this.r.lightASR!=='function')progress.asr_gap='asr_helper_unavailable';
        else{
          progress.asr_total=audio.total;progress.audio_ref=audio.source_ref;s.light_processing=progress;progress.stage='asr_running';progress.stage_id=this.r.uuid();await this.save(s);alive();
          try{const speech=await this.r.lightASR(audio.data,signal,progress.stage_id);alive();if(speech.segments.some(segment=>segment.end>audio.duration+0.05))throw Error('invalid_audio');const current=progress.asr||{processor:'apple_speech_ondevice',text:'',truncated:false,segments:[],coverage:audio.coverage};
            const limited=this.limitLightText((current.text?current.text+'\n':'')+speech.text,6000);current.text=limited.text;let incomplete=speech.truncated||limited.truncated;current.truncated||=incomplete;
            for(const segment of speech.segments){const row={...segment,start:segment.start+audio.start,end:segment.end+audio.start};if(current.segments.length>=100||new TextEncoder().encode(JSON.stringify([...current.segments,row])).length>7000){current.truncated=true;incomplete=true;break;}current.segments.push(row);} (current.chunks||=[]).push({index,start:audio.start,end:audio.start+audio.duration,status:incomplete?'failed':'text'});progress.asr_chunks=current.chunks;progress.asr=current;if(incomplete)progress.asr_gap='audio_result_limit';else{progress.asr_next=index+1;progress.asr_processed_until=audio.start+audio.duration;if(audio.coverage==='playing_media_audio')progress.playback_end=audio.start+audio.duration;(progress.completed_ids||=[]).push({kind:'asr',index,id:progress.stage_id});}
          }catch(error){if(error.message==='native_stop_unknown'||error.message==='light_authorization_denied'){if(progress.audio_source_kind==='remote_video'&&this.r.cancelLightSource){try{await this.r.cancelLightSource();}catch(_){this.lightSourceUnknown=true;}}if(error.message==='native_stop_unknown')this.lightStopUnknown=true;throw error;}if(error.message==='cancelled'&&signal.aborted){this.lightCancelled={id:progress.stage_id,stage:'asr_running'};throw error;}alive();const current=progress.asr||{processor:'apple_speech_ondevice',text:'',truncated:false,segments:[],coverage:audio.coverage};if(error.message==='speech_empty'){(current.chunks||=[]).push({index,start:audio.start,end:audio.start+audio.duration,status:'empty'});progress.asr_chunks=current.chunks;progress.asr=current;progress.asr_next=index+1;progress.asr_processed_until=audio.start+audio.duration;if(audio.coverage==='playing_media_audio')progress.playback_end=audio.start+audio.duration;(progress.completed_ids||=[]).push({kind:'asr',index,id:progress.stage_id});}else{(current.chunks||=[]).push({index,start:audio.start,end:audio.start+audio.duration,status:'failed'});progress.asr_chunks=current.chunks;progress.asr=current;progress.asr_gap=['speech_permission_required','speech_model_unavailable','invalid_audio','speech_recognition_failed','speech_timeout','local_asr_unavailable','local_asr_timeout','local_asr_failed','local_asr_busy','helper_version_mismatch'].includes(error.message)?error.message:'local_asr_failed';}}
        }
        progress.asr_done=!!progress.asr_gap||progress.asr_next===progress.asr_total;if(progress.asr_done&&progress.asr&&!progress.asr.text&&!progress.asr_gap)progress.asr_gap='speech_empty';if(progress.asr_done&&progress.asr?.coverage==='playing_media_audio'&&!progress.asr_gap)progress.asr_gap='audio_playback_partial';progress.stage='observed';delete progress.stage_id;s.light_processing=progress;await this.save(s);alive();
        if(progress.asr_gap&&progress.audio_source_kind==='remote_video'&&this.r.cancelLightSource){try{await this.r.cancelLightSource();}catch(_){this.lightSourceUnknown=true;throw Error('light_source_unknown');}alive();}
      }
      while(!progress.ocr_done&&s.task.light_text.ocr===true){
        await this.lightStageControl(s,alive,signal,'ocr');const index=progress.ocr_next||0;
        s.light_processing=progress;progress.stage='image_probe_running';progress.stage_id=this.r.uuid();await this.save(s);alive();
        let picture;try{picture=await this.r.probe('owner_light_image_'+index+(index&&progress.ocr_refs?'_'+progress.ocr_refs.join('.') : ''));if(signal.aborted){this.lightCancelled={id:progress.stage_id,stage:progress.stage};throw Error('cancelled');}alive();}catch(error){if(error.message==='light_source_unknown'){this.lightSourceUnknown=true;throw error;}alive();if(['pool_recovery_required','login_required','captcha','rate_limit'].includes(error.message))throw error;picture={note_id:note,status:'unavailable',reason:'image_probe_failed'};}
        progress.stage='observed';delete progress.stage_id;await this.save(s);alive();
        if(picture?.gate)throw Error(picture.gate);if(!picture?.note_id)picture={note_id:note,status:'unavailable',reason:'image_probe_failed'};if(picture.note_id!==note)throw Error('light_identity_mismatch');
        if(picture.status!=='available')progress.ocr_gap=['image_scope_unavailable','image_scope_changed','image_unavailable','image_not_loaded','image_size_limit','image_pixel_access_denied','image_probe_failed'].includes(picture.reason)?picture.reason:'image_probe_failed';
        else if(picture.index!==index||!Number.isInteger(picture.total)||picture.total<1||picture.total>1000||index>=picture.total||!/^[a-f0-9]{64}$/.test(picture.source_ref||'')||index!==(progress.ocr_refs||[]).length||progress.ocr_total!==undefined&&progress.ocr_total!==picture.total)throw Error('light_checkpoint_mismatch');
        else if(typeof this.r.lightOCR!=='function')progress.ocr_gap='ocr_helper_unavailable';
        else{
          progress.ocr_total=picture.total;s.light_processing=progress;progress.stage='ocr_running';progress.stage_id=this.r.uuid();await this.save(s);alive();
          try{const ocr=await this.r.lightOCR(picture.data,signal,progress.stage_id);alive();const limited=this.limitLightText(ocr.text,1500);progress.ocr.push({...ocr,text:limited.text,truncated:ocr.truncated||limited.truncated,coverage:'indexed_loaded_image',index,total:picture.total});(progress.ocr_refs||=[]).push(picture.source_ref);progress.ocr_next=index+1;(progress.completed_ids||=[]).push({kind:'ocr',index,id:progress.stage_id});}
          catch(error){if(error.message==='native_stop_unknown'){this.lightStopUnknown=true;throw error;}if(error.message==='cancelled'&&signal.aborted){this.lightCancelled={id:progress.stage_id,stage:'ocr_running'};throw error;}if(error.message==='light_authorization_denied')throw error;alive();progress.ocr_gap=['local_ocr_unavailable','local_ocr_timeout','local_ocr_failed','local_ocr_busy','helper_version_mismatch'].includes(error.message)?error.message:'local_ocr_failed';}
        }
        if(progress.ocr_next===4&&progress.ocr_total>4)progress.ocr_gap='ocr_partial_images';
        progress.ocr_done=!!progress.ocr_gap||progress.ocr_next===progress.ocr_total;progress.stage='observed';delete progress.stage_id;s.light_processing=progress;await this.save(s);alive();
      }
      return {...result,body:progress.body,subtitle:progress.subtitle,reason:progress.reason,asr:progress.asr,asr_gap:progress.asr_gap,ocr:progress.ocr,ocr_gap:progress.ocr_gap,...(progress.audio_source_kind==='remote_video'&&Number.isFinite(progress.asr_source_duration)?{audio_coverage:{processed_until:progress.asr_processed_until||0,duration:progress.asr_source_duration,duration_source:progress.asr_duration_source||'container'}}:{})};
    }
    async lightStageControl(s,alive,signal,kind) {
      const control=await this.control(s,'control',alive,signal,null,null,kind);alive();
      if(control?.paused||control?.reason&&!['action_gap'].includes(control.reason))throw Error(control.reason||'control_unavailable');
      if(!s.enabled||!Number.isFinite(Date.parse(s.task?.lease_until))||Date.parse(s.task.lease_until)<=this.r.now())throw Error('lease_lost');
    }
    async resumeOwnerLight(s,alive,signal) {
      const p=s.light_resume,t=s.task,owner=this.outboxOwner(s);
      if(!p||p.schema!=='crowd-light-resume-v1'||!['acked','opened'].includes(p.state)||p.owner!==owner||p.task!==t?.id||p.lease!==t.lease_token||p.installation!==t.node_run?.installation_id||!Number.isInteger(p.sequence)||p.sequence<0||typeof p.last_request!=='string'||p.intent?.request!==p.parent||p.intent?.admitted!==true||p.intent?.note!==p.note)throw Error('light_checkpoint_mismatch');
      try{C.validate(p.body);if(p.body.standard.note_id!==p.note||C.noteURL(p.url).id!==p.note)throw Error('invalid');}catch(_){throw Error('light_checkpoint_mismatch');}
      const page=await this.r.probe('note_ready');alive();if(page?.gate)throw Error(page.gate);if(!page?.ready||page.record?.standard?.note_id!==p.note)throw Error('light_resume_page_unavailable');
      s.note_id=p.note;s.note_url=p.url;s.detail_intent=JSON.parse(JSON.stringify(p.intent));
      if(s.light_processing&&p.progress){const current=s.light_processing,prior=p.progress;
        if((current.asr_next||0)<(prior.asr_next||0)||(current.ocr_next||0)<(prior.ocr_next||0)||JSON.stringify((current.ocr||[]).slice(0,(prior.ocr||[]).length))!==JSON.stringify(prior.ocr||[])||prior.asr&&!String(current.asr?.text||'').startsWith(prior.asr.text||''))throw Error('light_checkpoint_mismatch');
      }else if(!s.light_processing&&p.progress)s.light_processing=JSON.parse(JSON.stringify(p.progress));
      const result=await this.readOwnerLight(s,alive,signal,p.body);alive();delete result.body;
      const next=p.sequence+1,item=this.queueLight(s,p.parent,p.note,result,{sequence:next,previous:p.last_request});
      p.sequence=next;p.last_request=item.request;p.state='waiting_ack';p.progress=JSON.parse(JSON.stringify(s.light_processing||null));
      delete s.light_processing;s.phase='search_done';s.note_id=null;s.note_url=null;s.loaded_at=null;s.next_at=this.r.now();await this.save(s);alive();
      return await this.flushOutbox(s,alive,signal);
    }
    async reopenOwnerLight(s,alive,signal) {
      const p=s.light_resume,t=s.task;
      if(!p||p.schema!=='crowd-light-resume-v1'||p.owner!==this.outboxOwner(s)||p.task!==t?.id||p.lease!==t.lease_token||p.installation!==t.node_run?.installation_id||!p.reopen_request||C.noteURL(p.url).id!==p.note)throw Error('light_checkpoint_mismatch');
      if(['opening','unknown'].includes(p.state))throw Error('light_source_unknown');
      if(p.state==='admitted'){
        const control=await this.control(s,'control',alive,signal);alive();if(control.paused||control.reason&&control.reason!=='action_gap')throw Error(control.reason||'control_unavailable');
        p.state='opening';await this.save(s);alive();
        try{await this.r.open(p.url);alive();}catch(error){if(signal.aborted)throw error;p.state='unknown';await this.save(s);throw Error('light_source_unknown');}
        p.state='opened';s.page_deadline=this.r.now()+180000;s.next_at=this.r.now()+1000;await this.save(s);return;
      }
      if(p.state!=='opened')throw Error('light_checkpoint_mismatch');
      const page=await this.r.probe('note_ready');alive();if(page?.gate)throw Error(page.gate);if(!page?.ready){if(this.r.now()>=s.page_deadline)throw Error('light_resume_page_unavailable');s.next_at=this.r.now()+1000;await this.save(s);return;}
      if(page.record?.standard?.note_id!==p.note)throw Error('light_identity_mismatch');s.phase='light_resume';s.next_at=this.r.now();await this.save(s);return true;
    }
    async resumeReplyPage(s,alive) {
      const c=s.owner_reply_checkpoint,e=s.enrichment;
      if(!c||!e||c.owner!==this.outboxOwner(s)||c.task!==s.task?.id||c.new_lease!==s.task?.lease_token||c.installation!==s.task?.node_run?.installation_id||c.parent!==e.parent||C.noteURL(c.url).id!==c.note||e.record?.standard?.note_id!==c.note)throw Error('reply_checkpoint_invalid');
      if(c.state==='opening'){this.queueRootComments(s,e,'unknown');await this.save(s);throw Error('reply_action_unknown');}
      if(c.state==='admitted'){
        if(!Number.isFinite(Date.parse(s.task.lease_until))||Date.parse(s.task.lease_until)<=this.r.now()+60000)throw Error('lease_lost');
        const control=await this.control(s,'control',alive);alive();
        if(control?.paused&&control.owner_pause_requested===true){s.next_at=this.r.now();await this.save(s);return;}
        if(!s.enabled||control?.paused||control?.reason&&control.reason!=='action_gap'){c.state='blocked';s.enabled=false;s.last_error=control?.reason||'reply_resume_unavailable';await this.save(s);await this.r.cancel?.();return;}
        c.state='opening';await this.save(s);alive();
        try{await this.r.open(c.url);alive();}catch(_){this.queueRootComments(s,e,'unknown');await this.save(s);throw Error('reply_action_unknown');}
        c.state='opened';s.page_deadline=this.r.now()+180000;s.next_at=this.r.now()+1000;await this.save(s);return;
      }
      if(c.state!=='opened')throw Error('reply_resume_unavailable');
      const page=await this.r.probe('note_ready');alive();
      if(page?.gate)throw Error(page.gate);
      if(!page?.ready){if(this.r.now()>=s.page_deadline){this.queueRootComments(s,e,'unknown');await this.save(s);throw Error('reply_action_unknown');}s.next_at=this.r.now()+1000;return;}
      if(page.record?.standard?.note_id!==c.note)throw Error('wrong_note');
      c.state='active';s.phase='enrich';s.next_at=this.r.now();await this.save(s);
    }
    queueRootComments(s,e,reason) {
      if(e.root_queued)return;
      const task=s.task,installation=task.node_run?.installation_id;
      if(!installation)throw Error('node_binding_denied');
      const previous=s.outbox.length;
      if(!e.resumed_parent)s.outbox.push({request:e.parent,task:task.id,lease:task.lease_token,record:this.ownerBodyRecord(s,e.record),test_run_id:null});
      if(!e.resumed_parent&&task.light_text)this.queueLight(s,e.parent,e.record.standard.note_id,e.light_observation||{note_id:e.record.standard.note_id,subtitle:null,reason:'interrupted'});
      const common={kind:'root_comment',task:task.id,lease:task.lease_token,installation,parent:e.parent};
      for(const row of e.roots)if(!e.acked_comment_ids?.includes(row.comment_id))this.pushOutbox(s,{...common,request:this.r.uuid(),record:{kind:'comment',note_id:e.record.standard.note_id,...row}});
      this.pushOutbox(s,{...common,request:this.r.uuid(),record:{kind:'coverage',note_id:e.record.standard.note_id,coverage:'partial',reason,pages:e.rounds,captured:e.roots.length}});
      if(reason==='unknown'&&task.root_comments?.include_replies===true){
        const old=s.owner_reply_checkpoint,note=e.record.standard.note_id,url=s.note_url,owner=this.outboxOwner(s);
        if(!owner||!url||C.noteURL(url).id!==note)throw Error('reply_checkpoint_invalid');
        s.owner_reply_checkpoint={...(old||{}),schema:'crowd-owner-reply-checkpoint-v1',owner,task:task.id,lease:task.lease_token,origin_lease:old?.origin_lease||old?.lease||task.lease_token,installation,note,url,parent:e.parent,state:'unknown',enrichment:JSON.parse(JSON.stringify(e)),receipts:[...(old?.receipts||[]),...s.outbox.slice(previous).map(item=>({request:item.request,kind:item.kind||'body',record:item.record}))]};
        s.enabled=false;s.delivery_enabled=true;s.last_error='reply_action_unknown';
      }else if(e.resumed_parent){s.owner_reply_checkpoint=null;if(s.light_resume?.state==='waiting_reply'&&s.light_resume.parent===e.parent)s.light_resume.state='acked';}
      e.root_queued=true;s.enrichment=null;s.phase='search_done';s.note_url=null;s.note_id=null;s.loaded_at=null;s.notes_in_session=(s.notes_in_session||0)+1;s.next_at=this.r.now();
    }
    async rootEnrich(s,alive,signal) {
      if(s.task?.owner_base_task!==true||s.task?.root_comments?.enabled!==true)throw Error('root_comments_not_authorized');
      const e=s.enrichment,limit=s.task.root_comments.max_comments,includeReplies=s.task.root_comments.include_replies===true,includeRoots=s.task.root_comments.include_roots!==false;
      if(e.action_pending){this.queueRootComments(s,e,'unknown');return;}
      const leaseEnd=Date.parse(s.task.lease_until);
      if(!Number.isFinite(leaseEnd)||leaseEnd<this.r.now()+60000){this.queueRootComments(s,e,'interrupted');return;}
      let page;
      try{page=await this.r.probe(includeReplies?'owner_reply_read':'root_comment_read');}catch(error){
        if(error.message==='cancelled'||signal.aborted)throw error;
        if(error.message==='pool_recovery_required'){this.queueRootComments(s,e,'interrupted');return;}
        throw error;
      }alive();
      if(page.gate)throw Error(page.gate);
      if(!page.ready||page.record?.standard?.note_id!==e.record.standard.note_id||!page.record?.extra?.comments?.panel_found){this.queueRootComments(s,e,'panel_unavailable');return;}
      const comments=page.record.extra.comments,seen=new Set(e.roots.map(x=>x.comment_id));
      for(const item of comments.items||[]){
        if(!item.is_reply&&item.parent_key){e.identity_unknown=true;continue;}
        if(item.is_reply ? !includeReplies : !includeRoots)continue;
        if(!/^[a-zA-Z0-9_-]{1,80}$/.test(item.comment_id||'')){e.identity_unknown=true;continue;}
        if(item.is_reply&&!/^[a-zA-Z0-9_-]{1,80}$/.test(item.parent_comment_id||'')){e.identity_unknown=true;e.unresolved_parent=true;continue;}
        if(seen.has(item.comment_id))continue;
        if(limit>0&&e.roots.length>=limit)break;
        const row={comment_id:item.comment_id,text:item.text||'',author_display:item.author_display||null,published_label:item.published_label||null,...(item.is_reply?{parent_comment_id:item.parent_comment_id}:{})};
        const size=new TextEncoder().encode(JSON.stringify(row)).length;e.root_bytes??=new TextEncoder().encode(JSON.stringify(e.roots)).length;
        if(e.root_bytes+size>2*1024*1024){e.storage_limit=true;break;}
        seen.add(item.comment_id);e.roots.push(row);e.root_bytes+=size;
      }
      const signature=JSON.stringify((comments.items||[]).filter(x=>x.is_reply?includeReplies:includeRoots).map(x=>[x.comment_id,x.parent_comment_id,x.text]));
      e.stalls=e.last_signature===signature?(e.stalls||0)+1:0;e.last_signature=signature;
      await this.save(s);alive();
      if(e.storage_limit){this.queueRootComments(s,e,'storage_limit');return;}
      if(limit>0&&e.roots.length>=limit||e.roots.length>=10000){this.queueRootComments(s,e,'limit_reached');return;}
      if(comments.truncated||e.identity_unknown||comments.progress?.empty||comments.progress?.end_marker&&(!includeReplies||!comments.more_available)||(e.stalls||0)>=3||e.rounds>=10000){this.queueRootComments(s,e,e.unresolved_parent?'unresolved_parent':'source_unverified');return;}
      if(!await this.admit(s,'comment',alive,signal,e.record.standard.note_id)){
        if(['action_budget','user_stopped','task_full'].includes(s.last_error))this.queueRootComments(s,e,s.last_error==='action_budget'?'budget_exhausted':'interrupted');
        return;
      }
      e.action_pending=true;e.rounds++;await this.save(s);alive();
      const result=await this.r.probe(includeReplies?'owner_reply_advance':'root_comments');alive();
      if(result?.gate)throw Error(result.gate);
      if(!result?.ready||result.needs_visible_page){this.queueRootComments(s,e,'unknown');return;}
      e.action_pending=false;s.next_at=this.r.now()+1000;await this.save(s);
    }
    async enrich(s, alive, signal, slot = null) {
      const state=slot||s,e=state.enrichment, now=this.r.now(), platform=C.platform(e.record.standard.platform);
      const queueNote = () => {
        if(e.note_queued)return;
        const comments=e.record.extra.comments;
        this.queueCommentPages(s,e);this.queueStructuredPages(s,e);
        if(comments){
          if(e.repair){e.note_queued=true;return;}
          const record=this.legacyCommentNote(e.record);
          try {C.validate(record);this.pushOutbox(s,{request:this.r.uuid(),parent:e.parent,kind:'note',record});}
          catch(error){s.rejected.push({request:this.r.uuid(),parent:e.parent,kind:'note',record,reason:error.message});s.comment_partial=true;s.comment_validation_failed=true;}
        }
        e.note_queued=true;
      };
      const finish = () => {queueNote();state.enrichment=null;state.phase=slot?'done':'search_done';state.note_url=null;state.note_id=null;state.loaded_at=null;s.notes_in_session++;state.next_at=now;};
      if (Date.parse(s.task?.lease_until || '') < now+60000) e.stage='done';
      if (e.stage==='comments') {
        if(s.sdk_unknown===true)throw Error('sdk_unknown');
        if(e.sdk_pending?.status==='sending'||e.sdk_pending?.status==='unknown')throw Error('sdk_unknown');
        this.assertTest(s);e.timings ||= {started_at_ms:this.r.now(),reads:0,read_ms:0,guards:0,guard_ms:0,actions:0,action_ms:0};
        const readAt=this.r.now();const page=await this.r.probe('comment_read',slot?.id);alive();
        e.timings.reads++;e.timings.read_ms+=Math.max(0,this.r.now()-readAt);
        if(page.gate)throw new Error(page.gate);
        if(!page.ready || page.record.standard.note_id!==e.record.standard.note_id){e.stage='done';}
        else {
          for(const key of ['like_count','collect_count','comment_count','view_count','captured_at']) {
            if(key in page.record.standard)e.record.standard[key]=page.record.standard[key];
          }
          if(page.structured)e.structured=JSON.parse(JSON.stringify(page.structured));
          if(this.captureScope(s)&&Array.isArray(e.structured?.items)){const rows=e.structured.items;this.captureMetrics(s).sdk_progress={captured:rows.length,reported:page.record.standard.comment_count,roots:rows.filter(i=>i.parent===null).length,replies:rows.filter(i=>i.parent!==null).length};}
          e.record.extra.field_observations=page.record.extra.field_observations;
          e.record.extra.metric_labels=page.record.extra.metric_labels;
          e.record.extra.comments=this.mergeComments(e.record.extra.comments,page.record.extra.comments,true);
          if(e.record.extra.comments.items.length>10000){e.record.extra.comments.truncated=true;e.record.extra.comments.capture_reason='storage_limit';}
          // Keep the immutable base text/title; only supplement visible observations.
          const comments=e.record.extra.comments;
          if(e.sdk_pending?.status==='accepted'&&e.structured?.pages?.join('|')!==e.sdk_observed_pages){e.sdk_observed_pages=e.structured.pages.join('|');e.last=null;e.observed_signature=null;e.stalls=0;}
          if(this.experimentalAPIComplete(s,e,page)) {
            e.api_early_finish=true;
            comments.capture_reason='api_graph_closed_dom_subset';
            comments.complete=false;comments.terminal_stable=false;
            queueNote();
            if(!s.profiles || !e.record.extra.author?.id)finish();
            else {e.stage='profile';state.next_at=now;}
            return;
          }
          if(e.sdk_pending?.status==='accepted'&&e.structured?.main_ended===true&&Array.isArray(e.structured.groups)&&e.structured.groups.every(g=>g.ended===true)&&!e.structured.errors?.length){
            comments.complete=false;comments.terminal_stable=false;comments.capture_reason=e.structured.items?.length!==page.record.standard.comment_count?'api_counter_mismatch':'api_coverage_partial';s.structured_partial=true;s.comment_partial=true;if(s.test_run)s.test_run.sdk_stop_reason=comments.capture_reason;finish();return;
          }
          // Scroll movement alone is not newly loaded comment content.
          const signature=JSON.stringify([comments?.items.map(item=>[item.comment_id,item.is_reply,item.parent_comment_id,item.text,item.media]),comments?.dom_census,comments?.reply_coverage,comments?.media_pending,comments?.more_available,comments?.progress && {height:comments.progress.height,end_marker:comments.progress.end_marker,expand_count:comments.progress.expand_count,empty:comments.progress.empty}]);
          if(e.last!==null){
            // Wait for DOM loading/stability before counting a stalled expansion.
            if(e.observed_signature!==signature){e.observed_signature=signature;e.stable_at=this.r.now();}
            if(this.r.now()<(e.read_deadline||0) && (comments?.loading || signature===e.last && this.r.now()-(e.stable_at||0)<1000)) {state.next_at=this.r.now()+1000;return;}
            if(comments?.loading){e.record.extra.comments.capture_reason='loading_timeout';finish();return;}
            const top=comments?.progress?.top,forward=Number.isFinite(top) && top>(e.scroll_peak ?? Infinity) && comments?.progress?.at_end===false;
            // Long loaded replies need several scrolls before the next page. A bottom bounce cannot reset this high-water mark.
            e.stalls=signature===e.last && !forward?e.stalls+1:0;
            if(Number.isFinite(top))e.scroll_peak=signature===e.last?Math.max(e.scroll_peak ?? top,top):top;e.last=null;e.observed_signature=null;
          }
          const empty=(comments?.progress?.empty || page.record.standard.comment_count===0) && !comments?.items.length && !comments?.more_available;
          const exhausted=comments?.progress?.end_marker===true || Number.isInteger(page.record.standard.comment_count) && comments?.items.length===page.record.standard.comment_count;
          const ended=comments?.progress?.at_end && exhausted && !comments.more_available && !comments.loading && !comments.media_pending && e.stalls>=1;
          // Confirm a terminal DOM without spending another source action on an already exhausted page.
          if(comments && !comments.truncated && (empty || comments.progress?.at_end && comments.progress?.end_marker && !comments.more_available && !comments.loading && !comments.media_pending) && e.stalls<1) {
            e.last=signature;e.observed_signature=signature;e.stable_at=this.r.now();e.read_deadline=this.r.now()+20000;state.next_at=this.r.now()+1000;return;
          }
          if(!comments || comments.truncated || empty || ended || e.stalls>=3) {
            if(comments)comments.terminal_stable=ended || empty && e.stalls>=1;
            if(comments)comments.capture_reason=empty?'visible_empty':comments.truncated?'text_truncated':ended?'loaded_end':'loaded_stall';
            queueNote();
            if (!s.profiles || !e.record.extra.author?.id) finish();
            else { e.stage='profile'; state.next_at=now; }
          } else {
            if(slot && now<(s.action_not_before||0)){state.next_at=s.action_not_before;return;}
            let sdkPlan=null,leaseScope=null;
            if(this.captureScope(s)&&s.enabled===true&&s.task?.structured_capture===true&&s.task?.comments_capture===true&&!s.pending_risk&&!s.control?.paused&&!['sending','unknown'].includes(s.risk_report?.state)&&Number.isFinite(Date.parse(s.task.lease_until))&&Date.parse(s.task.lease_until)>this.r.now()+60000&&(e.repair?s.task.repair_notes?.some(p=>p.parent===e.parent&&p.record?.standard?.note_id===e.record.standard.note_id):s.test_run?.accepted?.some(p=>p.request===e.parent&&p.note_id===e.record.standard.note_id)||s.accepted_parents?.some(p=>p.parent===e.parent&&p.owner===s.owner_id&&p.task===s.task.id&&p.lease===s.task.lease_token&&p.note===e.record.standard.note_id))&&e.structured?.body_dom_match===true&&e.structured?.observer_status==='installed'&&!e.structured?.gate&&!e.structured?.errors?.length&&await this.r.sdkAllowed?.(s)){
              leaseScope=await this.r.leaseScope?.(s.task.lease_token);alive();const plan=await this.r.probe('sdk_plan',slot?.id,{type:'plan',id:this.r.uuid(),binding:{owner:s.owner_id,test:this.captureScope(s),note:e.record.standard.note_id,generation:this.generation,lease:leaseScope}});alive();
              if(plan.gate)throw Error(plan.gate);
              if(plan.sdk_status==='wait'){e.sdk_wait_deadline ||= this.r.now()+20000;if(this.r.now()>=e.sdk_wait_deadline)throw Error('page_timeout');state.next_at=this.r.now()+1000;return;}
              e.sdk_wait_deadline=null;if(plan.sdk_status==='available')sdkPlan=plan.sdk_plan;
            }
            const guardAt=this.r.now(), admitted=await this.admit(s,'comment',alive,signal);
            e.timings.guards++;e.timings.guard_ms+=Math.max(0,this.r.now()-guardAt);if(!admitted)return;
            e.last=signature;if(Number.isFinite(comments?.progress?.top))e.scroll_peak=Math.max(e.scroll_peak ?? comments.progress.top,comments.progress.top);e.observed_signature=null;e.read_deadline=this.r.now()+20000;e.rounds++;state.next_at=Math.max(this.r.now()+250,s.action_not_before||0);await this.save(s);alive();
            this.assertTest(s);const actionAt=this.r.now();let progress;
            if(sdkPlan){
              const id=this.r.uuid(),binding={owner:s.owner_id,test:this.captureScope(s),note:e.record.standard.note_id,generation:this.generation,lease:leaseScope};
              this.captureMetrics(s).sdk_timing ||= {attempts:0,accepted:0,fallbacks:0,dom_actions:0};this.captureMetrics(s).sdk_timing.attempts++;s.sdk_pending={id,status:'sending'};
              e.sdk_pending={id,status:'sending',operation:sdkPlan,owner:s.owner_id,test:this.captureScope(s),lease:s.task.lease_token};await this.save(s);alive();this.assertTest(s);
              progress=await this.r.probe('sdk_action',slot?.id,{type:'action',id,binding,operation:sdkPlan,grant:{...binding,...sdkPlan,id,allowed:true,expires:this.r.now()+10000}});alive();
              if(progress.gate){e.sdk_pending.status='risk';s.sdk_pending.status='risk';await this.save(s);throw Error(progress.gate);}
              if(['not_sent','stale'].includes(progress.sdk_status)){e.sdk_pending.status='not_sent';s.sdk_pending.status='not_sent';e.last=null;e.observed_signature=null;e.stalls=0;state.next_at=Math.max(this.r.now()+1000,s.action_not_before||0);await this.save(s);return;}
              if(progress.sdk_status!=='accepted'){e.sdk_pending.status='unknown';s.sdk_pending.status='unknown';s.sdk_unknown=true;await this.save(s);throw Error('sdk_unknown');}
              e.sdk_pending.status='accepted';s.sdk_pending.status='accepted';this.captureMetrics(s).sdk_timing.accepted++;await this.save(s);alive();
            }else {if(this.captureScope(s)){this.captureMetrics(s).sdk_timing ||= {attempts:0,accepted:0,fallbacks:0,dom_actions:0};this.captureMetrics(s).sdk_timing.fallbacks++;this.captureMetrics(s).sdk_timing.dom_actions++;}progress=await this.r.probe('comments',slot?.id);}alive();
            e.timings.actions++;e.timings.action_ms+=Math.max(0,this.r.now()-actionAt);if(progress.gate)throw new Error(progress.gate);
          }
        }
      } else if(e.stage==='profile') {
        if(!s.profiles || !e.record.extra.author?.id){finish();return;}
        this.assertTest(s);await this.r.sourceHealth?.(e.record.standard.platform);alive();
        this.assertTest(s);const grant=await this.api.rpc('profile_claim',{p_parent:e.parent},signal);alive();
        if(!grant || typeof grant.allowed!=='boolean')throw new Error('invalid_receipt');
        if(!grant.allowed){
          if(grant.reason==='action_gap' && Number.isFinite(grant.wait_ms) && grant.wait_ms>=0 && grant.wait_ms<=60000){state.next_at=this.r.now()+Math.max(1000,grant.wait_ms);return;}
          finish();return; // Optional work never holds the base task through cooldown/cache/quota.
        }
        const p=platform.profileURL(grant.url);
        if(p.id!==e.record.extra.author.id)throw new Error('wrong_note');
        e.stage='profile_read';e.deadline=now+120000;e.profile_grant=grant.token;state.next_at=this.r.now()+1000;await this.save(s);alive();
        const destination=e.author_navigation && platform.profileURL(e.author_navigation).id===p.id ? e.author_navigation : p.url;
        this.assertTest(s);await this.r.open(destination,false,slot?.id);alive();
      } else if(e.stage==='profile_read') {
        if(!s.profiles){finish();return;}
        this.assertTest(s);const page=await this.r.probe('profile',slot?.id);alive();if(page.gate)throw new Error(page.gate);
        if(page.ready && page.profile?.author_id===e.record.extra.author.id){
          s.outbox.push({request:this.r.uuid(),parent:e.parent,kind:'profile',record:{...page.profile,grant:e.profile_grant}});finish();
        } else if(now>=e.deadline)finish();else state.next_at=now+30000;
      } else finish();
    }
    checkPage(page, s, now) {
      now = Math.max(now, this.r.now());
      if (page.gate) throw new Error(page.gate);
      if (page.ready) s.last_error = null;
      if (page.reopen) {
        if (s.phase === 'search') throw new Error('navigation_failed');
        s.phase = 'reopen_note'; s.search_round = 0; s.next_at = now + 30000; return;
      }
      if (!page.ready) { if (now >= s.page_deadline) throw new Error(['navigation_uncommitted','page_loading','content_unavailable','probe_timeout'].includes(page.reason) ? page.reason : 'page_timeout'); s.next_at = now + (s.phase==='search'||s.fast_note?1000:30000); }
    }
  }
  root.CrowdAgent = CrowdAgent;
})(globalThis);
