# Linux / WSL2 installer bootstrap candidate

This package contains owned worker code only. It never downloads the purchased Pro SDK, clones a private repository, pairs a worker, copies a browser login, or starts collection during install/bind. Use an already paired worker-only cloud config, not an Owner config.

Keep the worker root, venvs and outbox in Linux `/home`, including under WSL2, rather than `/mnt/c`. WSL2 requires an existing user-installed distribution; no Windows host was tested.

For a new node, place your legally installed original SDK, Signer and CookieBridge checkouts together under one directory, then run:

```sh
sh install-linux.sh --root "$HOME/.local/share/CrowdWorker" --cloud-config /private/worker-only.json --pro-home /path/to/local/Pro
sh bind-linux.sh --root "$HOME/.local/share/CrowdWorker"
sh start-linux.sh --root "$HOME/.local/share/CrowdWorker"
```

The installer first reuses Python 3.12 and uv. If absent, it installs the fixed official uv 0.12.7 and uv-managed Python 3.12.14 under a private user directory without changing PATH/profile. Public archives can be supplied with `--bootstrap-cache DIR`; both hashes are fixed in the installer and the original uv file mirror performs the Python installation. Missing git/curl use the existing distro package manager only with root or already available passwordless sudo, with bounded timeouts. It never asks for a password or adds an OS repository. If permission/network is unavailable it stops with a specific system-package error; the operator must supply those system tools through the machine's normal administration.

Bridge runtime dependencies use the original direct pins (Pydantic 2.10.4, Tornado 6.1), fixed public transitive/build pins and PyPI hashes; venv installation uses copy mode. The original licensed `server/app.py` is run only on 127.0.0.1:8274, never an exposed listener or test relay. An already running service is checked and reused. No browser is opened. The original browser CookieBridge extension must already exist and have a local login; absent/multiple eligible clients produce a clear error. A unique connected XHS client is selected automatically; `--client-id` remains an explicit disambiguation option. A previously authenticated local SID is reused without self/auth or a new SID.

For an existing node, stop its worker normally, keep the same root/config/Python/collector and run `install-linux.sh ... --upgrade`. Only the three runtime pointer/digest/entry fields change after stopped/idle/lock/outbox guards and a durable intent. Unknown upgrade intents are not retried. Do not create a different root or pair to work around a refused upgrade.

Read-only checks:

```sh
sh install-linux.sh --check --root "$HOME/.local/share/CrowdWorker"
sh bind-linux.sh --status --root "$HOME/.local/share/CrowdWorker"
sh start-linux.sh --check --root "$HOME/.local/share/CrowdWorker"
```

`--check` does not install/download/start Bridge, authenticate or run the scheduler. Start intentionally runs the normal scheduler only after original Bridge readiness.

Actual scope: separate Linux aarch64 empty container had no Python/uv/git/curl; fixed official public archive cache installed real uv/Python and verified ssl/sqlite. Online apt in that container timed out (HTTP and HTTPS); git automatic installation is not claimed passed. Original Linux node check/status exited 0 and reused its existing SID; source activity prevented a whole-state equality assertion, which is retained as an inapplicable concurrent observation rather than a product failure. Its fixed identity and Pro binding were subsequently compared as two exact files when stopped. Original Bridge imports were run offline in its original dependency environment. New Bridge dependency preparation/start remain candidate behaviors, not actual login proof. Windows/physical Linux/automatic cross-OS OTA remain unverified.

Official public dependency references:
- https://docs.astral.sh/uv/getting-started/installation/
- https://docs.astral.sh/uv/guides/install-python/
- https://docs.astral.sh/uv/reference/settings/#python-install-mirror
- https://git-scm.com/install/linux
- https://learn.microsoft.com/en-us/windows/wsl/install
- https://learn.microsoft.com/en-us/windows/wsl/filesystems
