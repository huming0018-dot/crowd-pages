/* Alarm driven: each transition is durable; no long timers in a service worker. */
(function (root) {
  'use strict';
  const C = root.CrowdCore;
  class CrowdAgent {
    constructor(runtime, api) { this.r = runtime; this.api = api; this.active = null; this.generation = 0; this.recover = false; }
    async read() {
      await this.initializeGeneration();
      const owner=await this.r.owner?.();
      const s = {...C.initial(), ...await this.r.storage.get('agent')};
      if(this.r.owner && owner!==await this.r.owner())throw Error('cancelled');
      if(this.r.owner)s.owner_id=owner;
      // Old next_at remains authoritative. Only new navigations create a page wait.
      if (s.timing_version !== 1) {s.timing_version=1;s.wait_kind='legacy';s.retry_at=0;s.action_not_before=0;}
      s.run_generation = this.generation;
      return s;
    }
    async initializeGeneration() {
      const owner=this.r.owner ? await this.r.owner() : 'standalone';
      if(this.generationOwner!==owner || !this.initializing) {
        this.generationOwner=owner;
        this.initializing=(async()=>{
          const s=await this.r.storage.get('agent');
          if(this.r.owner && owner!==await this.r.owner())throw Error('cancelled');
          this.generation=Math.max(this.generation,s?.run_generation||0);
        })();
      }
      await this.initializing;
    }
    async save(s, stopping = false) {
      await this.initializeGeneration();
      const snapshot=JSON.parse(JSON.stringify(s));snapshot.run_generation ??= this.generation;
      if(this.r.owner && !Object.hasOwn(snapshot,'owner_id'))snapshot.owner_id=await this.r.owner();
      const pending=(this.writeTail||Promise.resolve()).catch(()=>{}).then(async()=>{
        if((this.stopping && !stopping) || snapshot.run_generation!==this.generation)throw Error('cancelled');
        if(this.r.owner && snapshot.owner_id!==await this.r.owner())throw Error('cancelled');
        await this.r.storage.set('agent',snapshot);
      });this.writeTail=pending;return pending;
    }
    async pageReady(target, keyword) {
      const s = await this.read();
      if (!s.enabled || s.wait_kind !== 'page' || s.last_error && !['page_loading','body_pending','content_unavailable','probe_timeout'].includes(s.last_error)) return;
      if (s.phase === 'search' ? keyword !== s.task?.query : target !== s.note_id) return;
      this.readyPending = {generation:this.generation,target,keyword};
      if (this.active) return;
      return this.tick();
    }
    async control(s, action, alive, signal, note = null) {
      const before = this.r.now();
      let value;
      try { value = await this.api.rpc('guard', {p_action: action, p_task: s.task?.id || null, p_note: note}, signal); }
      catch (error) { if (error.status === 401 || error.status === 403) throw error; throw new Error('control_unavailable'); }
      alive();
      if (value?.error) throw new Error(value.error);
      // A broken/older backend cannot silently disable limits. No offline page actions.
      const caps = {search:30, detail:60, comment:120, scroll:120};
      if (!value || !Number.isSafeInteger(value.version) || value.version < 1 ||
        !Number.isSafeInteger(value.ttl_ms) || value.ttl_ms < 1 || value.ttl_ms > 600000 ||
        typeof value.paused !== 'boolean' || typeof value.allowed !== 'boolean' || (value.allowed && (value.paused || value.reason !== null)) ||
        !Number.isFinite(value.wait_ms) || value.wait_ms < 0 || value.wait_ms > 172800000 ||
        !Number.isFinite(value.gap_ms) || value.gap_ms < 30000 ||
        Object.entries(caps).some(([key,max]) => !Number.isInteger(value.caps?.[key]) || value.caps[key] < 1 || value.caps[key] > max || !Number.isInteger(value.counts?.[key]) || value.counts[key] < 0) ||
        (s.control && value.version < s.control.version) || this.r.now() - before > 30000 || this.r.now() < before)
        throw new Error('control_unavailable');
      // A current server-clear retires a stale lab action wait; source risk waits remain.
      if(this.r.localTest === true && s.wait_kind === 'action' && !s.pending_risk && !['captcha','rate_limit'].includes(s.last_error) && value.reason === null && !value.paused) {
        s.next_at=this.r.now();s.action_not_before=0;s.wait_kind=null;s.last_error=null;
      }
      s.control = value; s.control_checked = this.r.now(); s.control_expires = before + value.ttl_ms;
      s.control_error = false;
      if (['captcha','rate_limit'].includes(action)) s.pending_risk = null;
      return value;
    }
    assertTest(s) {
      if(s.test_run && ['waiting','active'].includes(s.test_run.state) && this.r.now()>=s.test_run.expires_at) throw Error('test_expired');
    }
    async admit(s, action, alive, signal, note = null) {
      this.assertTest(s);
      this.assertTest(s);await this.r.sourceHealth?.(s.task?.platform||'xiaohongshu');alive();
      const value = await this.control(s, action, alive, signal, note);
      this.assertTest(s);
      if (!value.allowed || value.paused) {
        s.last_error = value.reason || 'control_unavailable';
        s.next_at = this.r.now() + Math.max(30000, value.wait_ms);
        s.wait_kind = 'action'; s.action_not_before = s.next_at;
        await this.save(s); await this.schedule(s,s.next_at); return false;
      }
      // The server has already charged this attempt, even if open/probe later fails.
      s.last_error = null; await this.save(s); alive(); return true;
    }
    async preferences() {
      const owner = await this.r.owner?.() || 'standalone';
      const value = await this.r.storage.get('agent-settings:' + owner);
      return value?.owner === owner && [1,2].includes(value.parallelism) ? value : null;
    }
    async requestParallelism(value) {
      await this.initializeGeneration();const owner=this.generationOwner,generation=this.generation;
      if (![1,2].includes(value) || value === 2 && !await this.r.poolAllowed?.()) throw Error('parallel_unavailable');
      if(generation!==this.generation || owner!==(await this.r.owner?.() || 'standalone'))throw Error('cancelled');
      await this.r.storage.set('agent-settings:' + owner, {owner,parallelism:value});
      // Preference IO never rewrites the actor's live state or its evidence queue.
      if (!this.active && !this.stopping && !this.maintenance) {
        this.active = (async()=>{const s=await this.read();await this.applyPreferences(s);})().finally(()=>{this.active=null;});
        await this.active;
      }
    }
    async applyPreferences(s) {
      if (s.outbox.length || s.work_slots?.length || s.enrichment || s.enabled && !['idle','search_done'].includes(s.phase)) return;
      const value=await this.preferences();
      if (value && value.parallelism !== (s.parallelism || 1)) {
        if (value.parallelism === 2 && !await this.r.poolAllowed?.()) return;
        s.parallelism=value.parallelism;await this.save(s);
      }
    }
    async schedule(s, at, replace = false) {
      if(s.test_run && ['waiting','active'].includes(s.test_run.state)) at=Math.min(at,s.test_run.expires_at);
      return this.r.schedule(at,replace);
    }
    testRemaining(s) {
      if (!s.test_run || !['waiting','active'].includes(s.test_run.state)) return s.test_run ? 0 : Infinity;
      const inflight = (s.work_slots || []).filter(slot => slot.phase !== 'done' && !slot.base_received).length;
      return s.test_run.state === 'waiting' ? 0 : Math.max(0, Math.min(s.test_run.limit-s.test_run.attempts, 2-s.test_run.accepted.length-inflight));
    }
    async endTest(s, reason) {
      s.test_run.state=reason==='test_completed'?'complete':'stopped';
      s.test_run.reason=reason;s.test_run.ended_at=this.r.now();
      s.enabled=false;s.delivery_enabled=true;s.last_error=reason;
      await this.save(s);
      // Stop waits for the writer. Defer cleanup until tick releases that writer.
      this.testStop={generation:this.generation,reason};
    }
    async start(test = false, {valid = async()=>true} = {}) {
      const stopIntent=this.stopIntent || 0,requested=valid;
      valid=async()=>stopIntent===(this.stopIntent || 0) && await requested();
      test = test || this.r.localTest === true;
      await this.initializeGeneration();
      if(!await valid())throw Error('cancelled');
      const owner=this.generationOwner,generation=this.generation;
      if (test && !await this.r.poolAllowed?.()) throw Error('parallel_unavailable');
      if(generation!==this.generation || owner!==(await this.r.owner?.() || 'standalone'))throw Error('cancelled');
      if(this.stopping)throw Error('executor_busy');
      if (this.maintenance) throw new Error('update_in_progress');
      await this.active?.catch(() => {});
      if (this.maintenance) throw new Error('update_in_progress');
      if (generation !== this.generation || owner!==(await this.r.owner?.() || 'standalone')) throw new Error('cancelled');
      // Hold the same single-writer lock while status IO is pending.
      if (this.active) return this.start(test,{valid});
      const prior = await this.read();
      if (generation !== this.generation || !await valid()) throw Error('cancelled');
      if (this.maintenance) throw Error('update_in_progress');
      if (this.stopping) throw Error('executor_busy');
      if (this.active) return this.start(test,{valid});
      if (test && prior.test_run && ['waiting','active'].includes(prior.test_run.state) && this.r.now() >= prior.test_run.expires_at) {
        // An explicit new test retires expired work before opening its new boundary.
        // Stop preserves original delivery UUIDs; no old page is reopened here.
        await this.stop('test_expired',{drain:true,restart:true});
        if(!await valid())throw Error('cancelled');
        return this.start(test,{valid});
      }
      this.active = this.activate(generation,test,valid).finally(() => { this.active = null;const stop=this.testStop;this.testStop=null;if(stop?.generation===this.generation)this.stop(stop.reason,{drain:true}).catch(()=>{}); });
      return this.active;
    }
    async activate(generation, test = false, valid = async()=>true) {
      const s = await this.read();
      if (s.consent !== C.CONSENT) throw new Error('consent_required');
      if(s.test_run && ['waiting','active'].includes(s.test_run.state) && this.r.now()>=s.test_run.expires_at){await this.endTest(s,'test_expired');return;}
      await this.r.sourceHealth?.(s.task?.platform||'xiaohongshu');if(generation!==this.generation || !await valid())throw new Error('cancelled');
      const status = await this.api.rpc('status');
      if (generation !== this.generation || !await valid()) throw new Error('cancelled');
      if (status.participant?.status !== 'approved') throw new Error('approval_required');
      // Every explicit resume reconciles the assignment after durable deliveries.
      s.assignment_refresh = true;
      if (test) {
        if (!s.test_run || !['waiting','active'].includes(s.test_run.state)) {
          s.test_run={id:this.r.uuid(),limit:4,attempts:0,accepted:[],state:'waiting',created_at:this.r.now(),expires_at:Math.min(this.r.now()+900000,Math.floor((this.r.now()+8*3600000)/86400000)*86400000+86400000-8*3600000),day:new Date(this.r.now()+8*3600000).toISOString().slice(0,10)};
        }
        // Adding a test boundary must not restart a running page or change its UUID.
        if (s.enabled) {await this.save(s);await this.schedule(s,this.r.now()+1000);return;}
      } else if (s.test_run && !['waiting','active'].includes(s.test_run.state)) {
        // A completed/stopped bounded run never silently becomes unlimited.
        throw Error('test_new_run_required');
      }
      if (s.enrichment) s.enrichment.stage='done';
      if (s.phase === 'note') s.phase = 'reopen_note';
      if (s.phase === 'search') { s.phase = 'idle'; s.search_round = 0; }
      s.enabled = true; s.delivery_enabled = true; s.delivery_error = null; s.last_error = null; s.page_failures = 0; s.control_checked = 0; s.last_tick = this.r.now();
      // Continuing never clears a durable deadline or a pending risk report.
      await this.save(s); await this.schedule(s,this.r.now() + 1000);
    }
    async stop(reason = 'user_stopped', options = {}) {
      if(!options.restart && !options.stoppedCheckpoint)this.stopIntent=(this.stopIntent || 0)+1;
      if(this.stopActive)return this.stopActive;
      this.stopActive=this.performStop(reason,options).finally(()=>{this.stopping=false;this.stopActive=null;});return this.stopActive;
    }
    async performStop(reason, {keepPage = false, drain = false, expectedOwner = null, stoppedCheckpoint = false} = {}) {
      if(expectedOwner&&expectedOwner!==(await this.r.storage.get('session'))?.user?.id)return;
      if(stoppedCheckpoint) {
        const checkpoint=await this.read();
        if(expectedOwner&&expectedOwner!==(await this.r.storage.get('session'))?.user?.id)return;
        if(checkpoint.enabled || checkpoint.outbox?.length || checkpoint.work_slots?.some(slot=>slot.request && slot.base_received!==true) || this.active || this.poolJobs?.size)return;
      }
      this.stopping=true;await this.initializeGeneration();
      this.generation++; this.controller?.abort();this.readyPending=null;this.poolWake=false;this.poolResults?.clear();
      await this.writeTail?.catch(()=>{});
      if(expectedOwner&&expectedOwner!==(await this.r.storage.get('session'))?.user?.id)return;
      const s = expectedOwner?{...C.initial(),...await this.r.storage.get('agent:'+expectedOwner)}:await this.read(); s.enabled = false; s.delivery_enabled = drain; s.last_error = reason;
      if(s.test_run && ['waiting','active'].includes(s.test_run.state)) {s.test_run.state='stopped';s.test_run.reason=reason;s.test_run.ended_at=this.r.now();}
      s.run_generation=this.generation;
      if(['captcha','rate_limit'].includes(reason)){s.pending_risk=reason;s.next_at=Math.max(s.next_at,this.r.now()+(reason==='rate_limit'?86400000:1800000));}
      // Optional supplements must never prevent the durable stop.
      if(expectedOwner)await this.r.storage.set('agent:'+expectedOwner,s);else await this.save(s,true);
      for(const slot of [...(s.work_slots||[]),...(this.r.localTest===true && s.enrichment?[{enrichment:s.enrichment}]:[])]) {
        const e=slot.enrichment;
        if(e?.record?.extra?.comments && !e.note_queued) {
          const item={kind:'note',request:this.r.uuid(),parent:e.parent,record:JSON.parse(JSON.stringify(e.record))};
          try {
            const comments=item.record.extra.comments;
            while(JSON.stringify(item.record).length>55000 && comments.items?.length){comments.items.pop();comments.truncated=true;comments.captured_count=comments.items.length;}
            C.validate(item.record);s.outbox.push(item);
          } catch(error) {s.rejected.push({...item,reason:error.message||'invalid_record'});}
          e.note_queued=true;
        }
      }
      if(expectedOwner)await this.r.storage.set('agent:'+expectedOwner,s);else await this.save(s,true);
      // A worker lost during cancellation must restart into the durable stop.
      await this.active?.catch(() => {});
      await Promise.allSettled([...(this.poolJobs?.values()||[])]);
      if(expectedOwner&&expectedOwner!==(await this.r.storage.get('session'))?.user?.id)return;
      try {
        await this.r.cancel();
        if(expectedOwner&&expectedOwner!==(await this.r.storage.get('session'))?.user?.id)return;
        if (!keepPage) {
          await this.r.close(expectedOwner);
          if(expectedOwner&&expectedOwner!==(await this.r.storage.get('session'))?.user?.id)return;
          const settled=await this.read();
          if(expectedOwner&&expectedOwner!==(await this.r.storage.get('session'))?.user?.id)return;
          if(this.r.localTest===true && settled.enrichment?.note_queued) {
            settled.enrichment=null;
            if(settled.phase==='enrich')settled.phase='search_done';
            await this.save(settled,true);
          }
          if(settled.work_slots?.length) {
            settled.interrupted ||= [];
            for(const slot of settled.work_slots)settled.interrupted.push({task:slot.task,note_id:slot.note_id||slot.enrichment?.record?.standard?.note_id,attempt:slot.id,request:slot.request||null,reason,action_consumed:true,outcome:slot.base_received?'base_received_supplement_stopped':slot.request?'delivery_unknown':'confirmed_abandoned'});
            settled.work_slots=[];if(settled.phase==='parallel')settled.phase='search_done';
            await this.save(settled,true);
          }
          if(settled.test_run && ['note','reopen_note','search'].includes(settled.phase)) {
            if(settled.note_id){settled.interrupted ||= [];settled.interrupted.push({task:settled.task?.id,note_id:settled.note_id,test_run_id:settled.note_test_run || null,reason,action_consumed:true,outcome:'confirmed_abandoned'});}
            // Closed, unsubmitted test pages are retired, never reopened outside the next batch's cap.
            settled.phase=settled.task && settled.candidates.length?'search_done':'idle';
            settled.note_id=null;settled.note_url=null;settled.note_test_run=null;settled.wait_kind=null;
            await this.save(settled,true);
          }
        }
        await this.repairDelivery();
      }
      finally {this.stopping=false;}
    }
    async tick(recover = false, deliveryOnly = false) {
      if (this.maintenance || this.stopping) return;
      await this.initializeGeneration();
      if(this.stopping)return;
      this.recover ||= recover;
      if (this.active) return this.active;
      this.controller = new AbortController();
      const gen = this.generation;
      const alive = () => { if (gen !== this.generation || this.controller.signal.aborted) throw new Error('cancelled'); };
      this.active = (async () => {
        // Drain ready local transitions under the same writer; never recurse into tick().
        for (let turns = 0; turns < 4; turns++) {
          this.poolWake=false;
          if (!await this.step(alive, this.controller.signal, deliveryOnly)) break;
        }
      })().finally(() => {
        this.active = null;
        const stop=this.testStop;this.testStop=null;
        if(stop?.generation===this.generation){this.stop(stop.reason,{drain:true}).catch(()=>{});return;}
        if(this.poolWake && !this.stopping){this.poolWake=false;this.tick().catch(()=>{});}
        if (this.readyPending?.generation === this.generation) {
          const pending = this.readyPending; this.readyPending = null;
          this.pageReady(pending.target,pending.keyword).catch(() => {});
        }
      });
      return this.active;
    }
    async step(alive, signal, deliveryOnly = false) {
      let s = await this.read(); const recover = this.recover; this.recover = false;
      const ready = this.readyPending; this.readyPending = null;
      if (!s.enabled && !(deliveryOnly && s.delivery_enabled && s.outbox.length)) return;
      if (s.consent !== C.CONSENT) { s.enabled = false; s.delivery_enabled = false; s.last_error = 'consent_required'; await this.save(s); await this.r.cancel(); await this.r.cancelDelivery?.(); return; }
      if (deliveryOnly) {
        const stoppedReason = !s.enabled ? s.last_error : null;
        try {
          alive();
          if (s.outbox.length) { await this.flushOutbox(s, alive, signal); s.delivery_error = null; await this.save(s); }
        } catch (error) {
          alive();
          const auth = error.status === 401 || error.status === 403;
          s.delivery_error = auth ? 'backend_login_required' : error.message === 'review_local_rejections' ? error.message : 'backend_unavailable';
          if (auth || error.message === 'review_local_rejections') { s.delivery_enabled = false; s.enabled = false; await this.r.cancel(); }
          if (s.outbox.length) {
            const item = s.outbox[0]; item.retries = (item.retries || 0) + 1;
            item.retry_at = this.r.now() + Math.min(900000, 60000 * 2 ** Math.min(item.retries - 1, 4));
          }
          await this.save(s);
        }
        if (stoppedReason) { s.last_error = stoppedReason; await this.save(s); }
        await this.repairDelivery(); return;
      }
      await this.repairDelivery();
      const now = this.r.now();
      const day = new Date(now + 8 * 3600000).toISOString().slice(0, 10);
      if (s.day !== day) { s.day = day; s.visits = 0; }
      try {
        alive();
        if(s.test_run && ['waiting','active'].includes(s.test_run.state) && (now>=s.test_run.expires_at || day!==s.test_run.day)) {await this.endTest(s,'test_expired');return;}
        if(s.assignment_refresh && s.outbox.length){await this.flushOutbox(s,alive,signal);return;}
        if(s.assignment_refresh && s.last_error==='daily_quota' && s.next_at>now){await this.schedule(s,s.next_at);return;}
        if(s.assignment_refresh) {
          const claimed=await this.api.rpc('claim',{p_task:s.task?.id || null},signal);alive();
          if(claimed.error==='daily_quota') {if(s.test_run){await this.endTest(s,'test_quota');return;}s.next_at=C.quotaRetry(claimed,now);s.last_error='daily_quota';await this.save(s);await this.schedule(s,s.next_at);return;}
          if(claimed.error)throw Error(claimed.error);
          let task=claimed.task;
          if(!task && s.task) {
            if(s.work_slots?.length || s.enrichment || ['note','reopen_note'].includes(s.phase))throw Error('pool_recovery_required');
            const fresh=await this.api.rpc('claim',{p_task:null},signal);alive();
            if(fresh.error==='daily_quota') {if(s.test_run){await this.endTest(s,'test_quota');return;}s.next_at=C.quotaRetry(fresh,now);s.last_error='daily_quota';await this.save(s);await this.schedule(s,s.next_at);return;}
            if(fresh.error)throw Error(fresh.error);task=fresh.task;
          }
          if(s.task?.id!==task?.id || s.task?.lease_token!==task?.lease_token || s.task?.query!==task?.query || s.task?.platform!==task?.platform) {
            if(s.work_slots?.length || s.enrichment || ['note','reopen_note'].includes(s.phase))throw Error('pool_recovery_required');
            s.phase='idle';s.seen=[];s.candidates=[];s.search_round=0;s.note_url=null;s.note_id=null;
          } else if(task) {
            if(task.received<s.task.received)throw Error('backend_unavailable');
            const known=new Set(task.known_note_ids || []);
            s.candidates=s.candidates.filter(url=>!known.has(C.taskPlatform(task).noteURL(url).id));
          }
          s.task=task || null;s.assignment_refresh=false;await this.save(s);
          // Re-enter the normal terminal/quota checks with the refreshed snapshot.
          return true;
        }
        // Local upgrades must also retire an older unlimited run, before optional visits.
        if(this.r.localTest === true && !s.assignment_refresh && s.task &&
          (s.task.received>=s.task.target || s.task.remaining_today===0 || s.test_run?.accepted.length===2)) {
          s.test_run ||= {id:this.r.uuid(),limit:4,attempts:0,accepted:[],state:'waiting',created_at:now,expires_at:now,day};
          await this.endTest(s,s.test_run.accepted.length===2?'test_completed':'test_quota');
          if(!s.outbox.some(item=>!item.kind) && s.task.received>=s.task.target && Date.parse(s.task.lease_until)>=now+60000) {
            try {
              const finished=await this.api.rpc('finish',{p_task:s.task.id,p_lease:s.task.lease_token},signal);alive();
              if(!finished || finished.error || !['open','complete','exhausted','closed'].includes(finished.status) || !Number.isSafeInteger(finished.received) || finished.received<0)throw Error('backend_unavailable');
              s.task=null;
            } catch(error) {alive();s.test_run.finish_error=error.message || 'backend_unavailable';}
            await this.save(s);
          }
          return;
        }
        // Restore active work, never a stopped/blocked participant. A long
        // suspension must restart dwell; wake detection is an alarm-gap heuristic.
        if (recover || (s.last_tick != null && now - s.last_tick > 120000)) {
          if(this.r.localTest === true && s.wait_kind === 'action')s.control_checked=0;
          if (s.enrichment) { s.enrichment.stage = 'done'; }
          if (s.phase === 'note') { s.phase = 'reopen_note'; s.loaded_at = null; s.scrolls = 0; }
          // An admitted search survives suspension. Probe its existing page and
          // original deadline; resetting to idle would charge and navigate again.
          // Keep persisted cooldowns, quota waits and evidence retry deadlines.
        }
        s.last_tick = now; await this.save(s); alive();
        // Repair a cleared alarm before network IO can suspend this worker.
        await this.schedule(s,Math.max(s.next_at, now + 30000)); alive();
        // Independent of task caching and collection waits. Explicit user stop still cancels work.
        if (s.pending_risk || !s.control || now >= (s.control_checked || 0) + 300000 || now < s.control_checked) {
          try { await this.control(s, s.pending_risk || 'control', alive, signal); }
          catch (error) { alive(); s.control_error = true; if (error.status === 401 || error.status === 403) throw error; }
          await this.save(s);
        }
        // Recheck only a rules-revision change, once, with the original evidence and UUID.
        const revision=s.control?.relevance_revision || 0;
        const retry=s.rejected.findIndex(item=>item.reason==='unrelated_note' && !item.kind && item.task===s.task?.id &&
          (item.relevance_revision || 0)<revision && now-Date.parse(item.record?.standard?.captured_at)<86400000);
        if(!s.outbox.length && retry>=0){
          const item=s.rejected.splice(retry,1)[0];item.relevance_revision=revision;item.lease=s.task.lease_token;
          s.outbox.push(item);await this.save(s);alive();
        }
        // Delivery runs even during collection cooldown. One stable UUID per record.
        if (s.outbox.length) { await this.flushOutbox(s, alive, signal); return; }
        if(s.test_run?.state==='active' && s.note_test_run===s.test_run.id && s.phase==='reopen_note') {await this.endTest(s,'test_partial');return;}
        await this.applyPreferences(s);alive();
        if(s.test_run?.state==='waiting' && !s.work_slots?.length && !s.enrichment && ['idle','search_done'].includes(s.phase)) {
          s.test_run.state='active';s.test_run.started_at=now;await this.save(s);
        }
        if(s.test_run?.state==='active' && this.testRemaining(s)===0 && !s.work_slots?.length && !s.enrichment && ['idle','search_done','parallel'].includes(s.phase)) {
          await this.endTest(s,s.test_run.accepted.length===2?'test_completed':'test_partial');
          // Only a filled task is finished; a two-note test must not exhaust a larger task.
          if(s.task?.received>=s.task?.target && Date.parse(s.task.lease_until)>=now+60000) {
            try {
              const finished=await this.api.rpc('finish',{p_task:s.task.id,p_lease:s.task.lease_token},signal);alive();
              if(!finished || finished.error || !['open','complete','exhausted','closed'].includes(finished.status) || !Number.isSafeInteger(finished.received) || finished.received<0)throw Error('backend_unavailable');
              s.task=null;s.phase='idle';
            } catch(error) {alive();s.test_run.finish_error=error.message || 'backend_unavailable';}
            await this.save(s);
          }
          return;
        }
        if (s.pending_risk || !s.control || this.r.now() >= s.control_expires || this.r.now() < s.control_checked) {
          s.last_error = 'control_unavailable'; await this.save(s); return;
        }
        if (s.control.paused || ['captcha','rate_limit','session_rest'].includes(s.control.reason) && now < s.control_checked + s.control.wait_ms) {
          s.last_error = s.control.reason || 'global_pause'; await this.save(s); return;
        }
        const pageWake = s.wait_kind === 'page' && ready?.generation === this.generation &&
          now >= (s.retry_at || 0) && now >= (s.action_not_before || 0) &&
          (s.phase === 'search' ? ready.keyword === s.task?.query : ready.target === s.note_id);
        if (s.next_at > now && !pageWake && !s.work_slots?.length) { await this.schedule(s,s.next_at); return; }
        if (s.visits >= 60) { s.next_at = now + 3600000; s.wait_kind = 'budget'; await this.save(s); await this.schedule(s,s.next_at); return; }
        if (s.enrichment) {
          await this.enrich(s, alive, signal); await this.save(s); alive();
          if (s.outbox.length) await this.flushOutbox(s, alive, signal);
          await this.schedule(s,Math.max(s.next_at,now+30000));
          return !s.outbox.length && s.next_at <= this.r.now();
        }
        if (!s.task || Date.parse(s.task.lease_until) < now + 180000) {
          const claimed = await this.api.rpc('claim', {p_task: s.task?.id || null}, signal); alive();
          if (claimed.error === 'daily_quota') { if(s.test_run){await this.endTest(s,'test_quota');return;} s.next_at = C.quotaRetry(claimed, now); s.last_error = 'daily_quota'; await this.save(s); await this.schedule(s,s.next_at); return; }
          if (claimed.error) throw new Error(claimed.error);
          if (!claimed.task) { s.task = null; s.phase = 'idle'; s.next_at = now + 300000; }
          else {
            if (s.task?.id !== claimed.task.id || s.task?.lease_token !== claimed.task.lease_token) {
              if(s.work_slots?.length)throw Error('pool_recovery_required');
              s.phase = 'idle'; s.seen = []; s.candidates = []; s.search_round = 0;
              s.note_url = null; s.note_id = null;
            }
            s.task = claimed.task;
          }
        }
        if (!s.task) { if(s.test_run){await this.endTest(s,'test_no_task');return;} await this.save(s); await this.schedule(s,s.next_at); return; }
        const platform = C.taskPlatform(s.task);
        if(s.work_slots?.length || s.parallelism===2 && ['search_done','parallel'].includes(s.phase) &&
          s.task.received<s.task.target && s.task.remaining_today!==0 && s.candidates.length) {
          if(!this.parallelStep)throw Error('parallel_unavailable');
          if(!s.work_slots?.length && s.phase==='search_done'){await this.r.closeLegacy?.();alive();}
          return await this.parallelStep(s,alive,signal);
        }
        if (s.task.received >= s.task.target || (s.phase === 'search_done' && !s.candidates.length)) {
          const finished = await this.api.rpc('finish', {p_task: s.task.id, p_lease: s.task.lease_token}, signal); alive();
          if (!finished || (finished.error && finished.error !== 'lease_lost') ||
            (!finished.error && (!['open','complete','exhausted','closed'].includes(finished.status) || !Number.isSafeInteger(finished.received) || finished.received < 0))) throw new Error('backend_unavailable');
          s.last_error = finished.error || null;
          s.task = null; s.phase = 'idle'; s.next_at = now + 60000; await this.r.close();
        } else if (s.task.remaining_today === 0) {
          if(s.test_run){await this.endTest(s,'test_quota');return;}
          s.next_at = now + 3600000;
        } else if (s.phase === 'idle') {
          if (!await this.admit(s, 'search', alive, signal)) return;
          // One alarm interval for initial search loading; never auto-reopen it.
          s.phase = 'search'; s.page_deadline = this.r.now() + 30000; s.next_at = s.page_deadline; s.wait_kind = 'page';
          // Persist before navigation: a worker restart after tabs.update must
          // resume probing instead of opening/charging the same search again.
          await this.save(s); alive();
          // The pre-admission heartbeat can precede this new deadline. Re-arm
          // once so a slow guard does not cost another full alarm interval.
          await this.schedule(s,s.next_at, true); alive();
          this.assertTest(s);await this.r.open(platform.searchURL(s.task.query)); alive();
        } else if (s.phase === 'search') {
          this.assertTest(s);const page=await this.r.probe('search'); alive();
          const normalize = value => String(value || '').normalize('NFC').replace(/\s+/g, ' ').trim().toLowerCase();
          if ('keyword' in page && normalize(page.keyword) !== normalize(s.task.query)) throw new Error('page_mismatch');
          this.checkPage(page, s, now);
          if (page.ready) {
            s.data_ready_at = this.r.now();
            const known = new Set(Array.isArray(s.task.known_note_ids) ? s.task.known_note_ids : []);
            const found = new Map(s.candidates.map(url => [platform.noteURL(url).id, url]).filter(([id]) => !known.has(id)));
            for (const url of page.links) { try { const note = platform.noteURL(url); if (!known.has(note.id) && !s.seen.includes(note.id) && !s.history.includes(note.id)) found.set(note.id, note.navigation); } catch (_) {} }
            s.card_meta ||= {};
            for (const card of page.cards || []) { try { s.card_meta[platform.noteURL(card.url).id] = {title:card.title,author_display:card.author_display}; } catch (_) {} }
            const normalizeTerm = value => String(value || '').normalize('NFKC').toLowerCase().replace(/[\s\p{P}]/gu,'');
            const score = url => (s.task.anchor_terms || []).filter(term => normalizeTerm(s.card_meta[platform.noteURL(url).id]?.title).includes(normalizeTerm(term))).length;
            s.candidates = [...found.values()].sort((a,b) => score(b)-score(a)).slice(0, 80);
            s.card_meta = Object.fromEntries(s.candidates.map(url => {const id=platform.noteURL(url).id;return [id,s.card_meta[id] || {}];}));
            s.search_round = (s.search_round || 0) + 1;
            // Stop expanding once enough unseen candidates exist for this task.
            // This saves page actions for small trials without changing server gaps.
            const needed = Math.max(1, Math.min(s.task.target - s.task.received,this.testRemaining(s)));
            if (s.search_round < 3 && s.candidates.length < needed) { if (!await this.admit(s, 'scroll', alive, signal)) { s.search_round--; await this.save(s); return; } this.assertTest(s);await this.r.probe('scroll'); alive(); s.next_at = now + C.between(30000, 45000, this.r.random); }
            else { s.search_round = 0; s.phase = 'search_done'; s.next_at = now; s.wait_kind = null; }
          }
        } else if (s.phase === 'search_done') {
          const url = s.candidates[0]; const id = platform.noteURL(url).id;
          if (!await this.admit(s, 'detail', alive, signal, id)) {
            if (['known_note','note_busy'].includes(s.last_error)) { s.candidates.shift(); s.seen.push(id); await this.save(s); }
            return;
          }
          s.candidates.shift();
          // Mark before navigation: crashes cannot create infinite note loops.
          s.seen.push(id); s.visits++; s.note_id = id; s.note_url = url; s.phase = 'note'; s.loaded_at = null; s.scrolls = 0; s.comment_rounds = 0; s.comment_snapshot = null; s.comment_stalls = 0;
          s.note_test_run=null;
          if(s.test_run?.state==='active'){s.test_run.attempts++;s.note_test_run=s.test_run.id;}
          s.dwell_ms = C.between(45000, 90000, this.r.random); s.page_deadline = now + 180000;
          s.next_at = now + 30000; s.wait_kind = 'page'; s.fast_note = this.r.fastCapture === true; await this.save(s);
          this.assertTest(s);await this.r.open(url); alive();
        } else if (s.phase === 'reopen_note') {
          if (!s.note_url) { s.phase = 'idle'; s.next_at = now + 30000; }
          else {
            if (!await this.admit(s, 'detail', alive, signal, s.note_id)) {
              if (['known_note','note_busy'].includes(s.last_error)) { s.phase = 'search_done'; s.note_url = null; s.note_id = null; await this.save(s); }
              return;
            }
            this.assertTest(s);await this.r.open(s.note_url); alive(); s.phase = 'note'; s.loaded_at = null; s.scrolls = 0; s.comment_rounds = 0; s.comment_snapshot = null; s.comment_stalls = 0;
            s.page_deadline = now + 180000; s.next_at = now + 30000; s.wait_kind = 'page'; s.fast_note = this.r.fastCapture === true;
          }
        } else if (s.phase === 'note') {
          this.assertTest(s);const page=await this.r.probe(s.fast_note ? 'note_ready' : 'note'); alive(); this.checkPage(page, s, now);this.assertTest(s);await this.r.sourceHealth?.(s.task?.platform||'xiaohongshu');alive();
          if (page.ready) {
            if (page.record.standard.note_id !== s.note_id) throw new Error('wrong_note');
            s.data_ready_at = this.r.now();
            if (s.loaded_at === null) s.loaded_at = now;
            if (!s.fast_note && (now - s.loaded_at < s.dwell_ms || s.scrolls < 2)) {
              if (!await this.admit(s, 'scroll', alive, signal)) return;
              this.assertTest(s);await this.r.probe('scroll'); alive(); s.scrolls++; s.next_at = now + C.between(30000, 45000, this.r.random);
            } else if (this.r.splitCapture && s.control.observations === 1) {
              C.validate(page.record);
              page.record.extra.discovery = {method:'task_search',candidate:s.card_meta?.[s.note_id] || null};
              const request = this.r.uuid();
              s.outbox.push({request,task:s.task.id,lease:s.task.lease_token,record:page.record,test_run_id:s.note_test_run || null});
              s.enrichment = {parent:request,author_navigation:page.author_navigation || null,record:JSON.parse(JSON.stringify(page.record)),stage:'comments',rounds:0,stalls:0,last:null};
              s.phase = 'enrich'; s.next_at = now; s.wait_kind = null;
            } else {
              const comments = page.record.extra.comments;
              // Compare actual loaded content, not just item count: virtual lists
              // and reply updates can change text without increasing the count.
              const snapshot = comments ? JSON.stringify(comments.items.map(item => [item.comment_id || item.key, item.parent_key, item.text])) : null;
              if (s.comment_snapshot != null) {
                s.comment_stalls = snapshot === s.comment_snapshot ? (s.comment_stalls || 0) + 1 : 0;
                s.comment_snapshot = null; // Consume each attempted expansion once, even if admission is denied.
              }
              const empty = comments && page.record.standard.comment_count === 0 && !comments.items.length && !comments.more_available;
              const stalled = (s.comment_stalls || 0) >= (comments?.more_available ? 2 : 1);
              if (comments && !comments.truncated && !empty && !stalled && (s.comment_rounds || 0) < 4) {
                if (!await this.admit(s, 'comment', alive, signal)) return;
                s.comment_snapshot = snapshot;
                // Persist before the DOM action so worker restart cannot repeat an uncounted expansion.
                s.comment_rounds = (s.comment_rounds || 0) + 1;
                s.next_at = this.r.now() + 30000; await this.save(s); alive();
                this.assertTest(s);const progress=await this.r.probe('comments'); alive(); this.checkPage(progress, s, now);
              } else {
                C.validate(page.record);
                s.outbox.push({request: this.r.uuid(), task: s.task.id, lease: s.task.lease_token, record: page.record,test_run_id:s.note_test_run || null});
                s.page_failures = 0;
                s.phase = 'search_done'; s.notes_in_session++; s.note_url = null; s.note_id = null; s.loaded_at = null;
                s.next_at = now + (s.notes_in_session % 8 === 0 ? C.between(300000, 600000, this.r.random) : C.between(30000, 60000, this.r.random));
              }
            }
          }
        }
        await this.save(s); alive();
        // The durable outbox is the crash boundary, not a reason to delay its first send.
        if (s.outbox.length) await this.flushOutbox(s, alive, signal);
        await this.schedule(s,Math.max(s.next_at, now + 30000));
        return !s.outbox.length && ['enrich','search_done'].includes(s.phase) && s.next_at <= this.r.now();
      } catch (err) {
        if (err.message === 'cancelled' || signal.aborted) return;
        alive(); s.last_error = err.message;
        if (['captcha','rate_limit'].includes(err.message)) {
          // Persist before IO. If reporting fails, the next start must report before any action.
          s.pending_risk = err.message;
          s.next_at = Math.max(s.next_at, now + (err.message === 'rate_limit' ? 86400000 : 1800000));
          await this.save(s);
          try { await this.control(s, err.message, alive, signal); } catch (_) { alive(); }
        }
        s.failure_kind = ['captcha','rate_limit'].includes(err.message) ? 'platform_gate' :
          ['login_required','identity_verification_required','platform_identity_changed'].includes(err.message) ? 'platform_login' :
          ['navigation_failed','navigation_uncommitted','page_loading','probe_timeout'].includes(err.message) ? 'page_transport' :
          ['page_timeout','content_unavailable','wrong_note','invalid_content','invalid_comments','invalid_count','page_mismatch'].includes(err.message) ? 'page_contract' : 'backend';
        const pageFailure = ['page_timeout', 'page_loading', 'content_unavailable', 'probe_timeout', 'wrong_note', 'invalid_content', 'invalid_comments', 'invalid_count'].includes(err.message);
        if (pageFailure) {
          s.page_failures = (s.page_failures || 0) + 1;
          if (s.page_failures >= 3) {
            if(s.test_run){await this.endTest(s,err.message);return;}
            s.enabled = false; await this.save(s); await this.r.cancel(); return;
          }
        }
        if (err.message==='navigation_uncommitted') await this.r.trace?.('navigation_timeout');
        if (['test_expired','parallel_unavailable','pool_recovery_required','identity_verification_required','platform_identity_changed','navigation_failed', 'navigation_uncommitted', 'page_loading', 'page_timeout', 'content_unavailable', 'probe_timeout', 'captcha', 'rate_limit', 'login_required', 'backend_login_required', 'page_mismatch', 'approval_required', 'consent_required', 'review_local_rejections', 'unsupported_platform'].includes(err.message) || err.status === 401 || err.status === 403) {
          if(s.test_run){await this.endTest(s,err.message);return;}
          s.enabled = false; await this.save(s); await this.r.cancel(); return;
        }
        if (pageFailure || err.message === 'wrong_note') {
          s.phase = 'idle'; s.search_round = 0; s.candidates = []; s.note_url = null; s.note_id = null;
        }
        s.next_at = Math.max(s.next_at, now + (pageFailure ? 60000 * 2 ** (s.page_failures - 1) : 60000));
        s.retry_at = s.next_at; s.wait_kind = 'retry';
        if (s.outbox.length) { const item = s.outbox[0]; item.retries = (item.retries || 0) + 1; item.retry_at = now + Math.min(900000, 60000 * 2 ** Math.min(item.retries - 1, 4)); s.next_at = item.retry_at; }
        await this.save(s); await this.schedule(s,s.next_at);
      }
    }
    async scheduleReceipt(s, at) {
      if (s.enabled) await this.schedule(s,at);
      else await this.r.scheduleDelivery?.();
    }
    async queueRating(proof, score, reason) {
      await this.initializeGeneration();
      if (this.maintenance) throw new Error('update_in_progress');
      if (!Number.isSafeInteger(proof) || proof < 1 || !Number.isInteger(score) || score < 1 || score > 5 ||
        typeof reason !== 'string' || reason.length > 200 || reason.replace(/[\s\p{P}\p{S}]/gu,'').length < 8) throw new Error('invalid_rating');
      const generation = this.generation;
      await this.active?.catch(()=>{});
      if (generation !== this.generation) throw new Error('cancelled');
      if (this.maintenance) throw new Error('update_in_progress');
      if (this.active) return this.queueRating(proof, score, reason);
      this.active = (async()=>{
        const s=await this.read(); if(s.consent!==C.CONSENT)throw new Error('consent_required');
        if(s.outbox.some(i=>i.kind==='rating'&&i.proof===proof))throw new Error('rating_queued');
        if(s.outbox.length>=100)throw new Error('queue_full');
        s.outbox.push({kind:'rating',request:this.r.uuid(),proof,score,rating_reason:reason});
        s.delivery_enabled=true;await this.save(s);await this.repairDelivery();
      })().finally(()=>{this.active=null;});
      return this.active;
    }
    async repairDelivery() {
      const s = await this.read();
      if (s.consent === C.CONSENT && (s.enabled || s.delivery_enabled) && s.outbox.length) await this.r.scheduleDelivery?.();
      else await this.r.cancelDelivery?.();
    }
    async flushOutbox(s, alive, signal) {
      const now = this.r.now();
      const item = s.outbox[0];
      if ((item.retry_at || 0) > now) { await this.scheduleReceipt(s, item.retry_at); return; }
      if (item.kind === 'rating') {
        const receipt=await this.api.rpc('rating',{p_request:item.request,p_proof:item.proof,p_score:item.score,p_reason:item.rating_reason},signal);alive();
        if(receipt?.request!==item.request || !['rated','rejected'].includes(receipt.gate) ||
          (receipt.gate==='rated' && typeof receipt.inserted!=='boolean') ||
          (receipt.gate==='rejected' && !['invalid_rating','invalid_anchor','already_rated','request_reused'].includes(receipt.error)))throw new Error('invalid_receipt');
        if(receipt.gate==='rejected')s.rejected.push({...item,reason:receipt.error});
        s.outbox.shift();if(s.rejected.length>=20)throw new Error('review_local_rejections');await this.save(s);await this.scheduleReceipt(s,now+30000);return;
      }
      if (item.kind) {
        const receipt = await this.api.rpc('observe', {p_request:item.request,p_parent:item.parent,p_kind:item.kind,p_data:item.record}, signal); alive();
        if (!receipt || receipt.request !== item.request || !['observed','rejected'].includes(receipt.gate)) throw new Error('invalid_receipt');
        if (receipt.gate === 'rejected') s.rejected.push({...item,reason:receipt.error || 'invalid_record'});
        s.outbox.shift(); if(s.rejected.length>=20)throw new Error('review_local_rejections'); await this.save(s); await this.scheduleReceipt(s, now+30000); return;
      }
      const receipt = C.receipt(await this.api.rpc('submit', {p_request: item.request, p_task: item.task,
        p_lease: item.lease, p_record: item.record}, signal), item.request);
      alive();
      if (receipt.error === 'daily_quota') {
        item.retry_at = C.quotaRetry(receipt, now); s.last_error = 'daily_quota'; await this.save(s); await this.scheduleReceipt(s, item.retry_at); return;
      } else if (receipt.error === 'lease_expired') {
        const renewed = await this.api.rpc('claim', {p_task: item.task}, signal); alive();
        if (renewed.error === 'daily_quota') {
          item.retry_at = C.quotaRetry(renewed, now); s.last_error = 'daily_quota';
          await this.save(s); await this.scheduleReceipt(s, item.retry_at); return;
        }
        if (renewed.error) throw new Error(renewed.error);
        if (renewed.task?.id === item.task) { item.lease = renewed.task.lease_token; s.task = renewed.task; }
        else { s.rejected.push({...item, reason: 'lease_lost'}); s.outbox.shift(); s.task = null; s.phase = 'idle'; }
      } else {
        s.outbox.shift();
        const slot=s.work_slots?.find(slot=>slot.request===item.request);
        if(slot){if(receipt.error){slot.phase='done';slot.enrichment=null;}else slot.base_received=true;}
        if (receipt.error) {
          s.rejected.push({...item, reason: receipt.error,relevance_revision:s.control?.relevance_revision || 0});
          if (s.enrichment?.parent === item.request) { s.enrichment = null; s.phase = 'search_done'; }
        }
        else {
          s.last_error = null;
          s.received += receipt.inserted ? 1 : 0;
          if(s.test_run && item.test_run_id===s.test_run.id && receipt.inserted && !receipt.duplicate && !s.test_run.accepted.some(a=>a.request===item.request || a.note_id===item.record.standard.note_id)) {
            s.test_run.accepted.push({request:item.request,note_id:item.record.standard.note_id});
          }
          s.history = [...new Set([...s.history, item.record.standard.note_id])].slice(-2000);
          if (s.task?.id === item.task) {
            const newlyReceived=Math.max(0,receipt.task_received-s.task.received);
            s.task.received=Math.max(s.task.received,receipt.task_received);
            if(s.task.remaining_today!=null)s.task.remaining_today=Math.max(0,s.task.remaining_today-newlyReceived);
          }
        }
      }
      // Failed records remain exportable; bounded by stopping, never by deleting evidence.
      if (s.rejected.length >= 20) throw new Error('review_local_rejections');
      await this.save(s); await this.scheduleReceipt(s, now + 30000); return;
    }
    mergeComments(previous, current) {
      if (!current) return previous;
      if (!previous) return JSON.parse(JSON.stringify(current));
      const result = JSON.parse(JSON.stringify(previous));
      const identity = item => item.comment_id ? 'id:'+item.comment_id : JSON.stringify([item.author_display,item.text,item.published_label,item.is_reply]);
      const seen = new Map(result.items.map(item => [identity(item),item]));
      const remap = new Map();
      for (const item of current.items) {
        let known = seen.get(identity(item));
        if (!known) {
          if (result.items.length >= 50 || JSON.stringify(result).length + JSON.stringify(item).length > 20000) {result.truncated=true;break;}
          known = {...item,key:'comment-'+(result.items.length+1),parent_key:remap.get(item.parent_key) || null};
          result.items.push(known); seen.set(identity(item),known);
        } else { const key=known.key,parent=known.parent_key; Object.assign(known,item,{key,parent_key:remap.get(item.parent_key) || parent}); }
        remap.set(item.key,known.key);
      }
      result.captured_count=result.items.length; result.complete=false;
      result.identity_method='platform_id_or_content_fingerprint';result.identity_uncertain=result.items.some(item=>!item.comment_id);
      result.loaded_count=Math.max(previous.loaded_count || 0,current.loaded_count || 0,result.items.length);
      result.omitted_count=Math.max(previous.omitted_count || 0,current.omitted_count || 0);
      result.more_available=current.more_available; result.truncated ||= current.truncated;
      return result;
    }
    async enrich(s, alive, signal, slot = null) {
      const state=slot||s,e=state.enrichment, now=this.r.now(), platform=C.platform(e.record.standard.platform);
      const queueNote = () => {
        if(e.note_queued)return;
        const comments=e.record.extra.comments;
        if(comments){
          while(JSON.stringify(e.record).length>55000 && comments.items.length){comments.items.pop();comments.truncated=true;comments.omitted_count=(comments.omitted_count||0)+1;}
          comments.captured_count=comments.items.length;
          C.validate(e.record);s.outbox.push({request:this.r.uuid(),parent:e.parent,kind:'note',record:JSON.parse(JSON.stringify(e.record))});
        }
        e.note_queued=true;
      };
      const finish = () => {queueNote();state.enrichment=null;state.phase=slot?'done':'search_done';state.note_url=null;state.note_id=null;state.loaded_at=null;s.notes_in_session++;state.next_at=now;};
      // A two-note lab verifies full bodies and receipts using already-visible optional observations.
      if(this.r.localTest === true && s.test_run && ['waiting','active'].includes(s.test_run.state)) { finish(); return; }
      if (Date.parse(s.task?.lease_until || '') < now+60000) e.stage='done';
      if (e.stage==='comments') {
        this.assertTest(s);const page=await this.r.probe('note',slot?.id);alive();
        if(page.gate)throw new Error(page.gate);
        if(!page.ready || page.record.standard.note_id!==e.record.standard.note_id){e.stage='done';}
        else {
          for(const key of ['like_count','collect_count','comment_count','view_count','captured_at']) {
            if(key in page.record.standard)e.record.standard[key]=page.record.standard[key];
          }
          e.record.extra.field_observations=page.record.extra.field_observations;
          e.record.extra.metric_labels=page.record.extra.metric_labels;
          e.record.extra.comments=this.mergeComments(e.record.extra.comments,page.record.extra.comments);
          // Keep the immutable base text/title; only supplement visible observations.
          const comments=e.record.extra.comments;
          const signature=JSON.stringify(comments?.items.map(item=>[item.comment_id,item.text]) || []);
          if(e.last!==null){e.stalls=signature===e.last?e.stalls+1:0;e.last=null;}
          const empty=page.record.standard.comment_count===0 && !comments?.items.length && !comments?.more_available;
          if(!comments || comments.truncated || empty || e.rounds>=4 || e.stalls >= (comments.more_available?2:1)) {
            queueNote();
            if (!s.profiles || !e.record.extra.author?.id) finish();
            else { e.stage='profile'; state.next_at=now; }
          } else {
            if(slot && now<(s.action_not_before||0)){state.next_at=s.action_not_before;return;}
            if(!await this.admit(s,'comment',alive,signal))return;
            e.last=signature;e.rounds++;state.next_at=this.r.now()+30000;await this.save(s);alive();
            this.assertTest(s);const progress=await this.r.probe('comments',slot?.id);alive();if(progress.gate)throw new Error(progress.gate);
          }
        }
      } else if(e.stage==='profile') {
        if(!s.profiles || !e.record.extra.author?.id){finish();return;}
        this.assertTest(s);await this.r.sourceHealth?.(e.record.standard.platform);alive();
        this.assertTest(s);const grant=await this.api.rpc('profile_claim',{p_parent:e.parent},signal);alive();
        if(!grant || typeof grant.allowed!=='boolean')throw new Error('invalid_receipt');
        if(!grant.allowed){finish();return;} // Optional work never holds the base task through cooldown/cache/quota.
        const p=platform.profileURL(grant.url);
        if(p.id!==e.record.extra.author.id)throw new Error('wrong_note');
        e.stage='profile_read';e.deadline=now+120000;e.profile_grant=grant.token;state.next_at=now+30000;await this.save(s);alive();
        const destination=e.author_navigation && platform.profileURL(e.author_navigation).id===p.id ? e.author_navigation : p.url;
        this.assertTest(s);await this.r.open(destination,false,slot?.id);alive();
      } else if(e.stage==='profile_read') {
        if(!s.profiles){finish();return;}
        this.assertTest(s);const page=await this.r.probe('profile',slot?.id);alive();if(page.gate)throw new Error(page.gate);
        if(page.ready && page.profile?.author_id===e.record.extra.author.id){
          s.outbox.push({request:this.r.uuid(),parent:e.parent,kind:'profile',record:{...page.profile,grant:e.profile_grant}});finish();
        } else if(now>=e.deadline)finish();else state.next_at=now+30000;
      } else finish();
    }
    checkPage(page, s, now) {
      now = Math.max(now, this.r.now());
      if (page.gate) throw new Error(page.gate);
      if (page.ready) s.last_error = null;
      if (page.reopen) {
        if (s.phase === 'search') throw new Error('navigation_failed');
        s.phase = 'reopen_note'; s.search_round = 0; s.next_at = now + 30000; return;
      }
      if (!page.ready) { if (now >= s.page_deadline) throw new Error(['navigation_uncommitted','page_loading','content_unavailable','probe_timeout'].includes(page.reason) ? page.reason : 'page_timeout'); s.next_at = now + 30000; }
    }
  }
  root.CrowdAgent = CrowdAgent;
})(globalThis);
