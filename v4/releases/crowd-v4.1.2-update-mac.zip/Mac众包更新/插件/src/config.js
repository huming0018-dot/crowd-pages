globalThis.CROWD_CONFIG = {"url": "https://bdwrhshgdeghgyzwpxnl.supabase.co", "key": "sb_publishable_c93XenGzZsoa308e3bTg6A__lfaqQ-B", "portal": "https://app-lyart-eta-22.vercel.app"};
