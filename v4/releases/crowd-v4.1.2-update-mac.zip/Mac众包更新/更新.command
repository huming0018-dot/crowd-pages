#!/bin/bash
set -euo pipefail
kit_dir=$(cd "$(dirname "$0")" && pwd)
exec /bin/bash "$kit_dir/prepare.command" --update-only
