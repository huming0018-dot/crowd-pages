/* Explicit local opt-in; consumes one signed upgrade per participant. No external command bridge. */
(function(root){
 'use strict';
 class CrowdLocalTest {
  constructor({storage,id,version,owner,agent,start,isBusy}){Object.assign(this,{storage,id,version,owner,agent,start,isBusy});this.active=null;this.generation=0;this.writes=Promise.resolve();}
  write(owner,generation,change){const key='local-test-update:'+owner;const next=this.writes.catch(()=>{}).then(async()=>{if(generation!==this.generation || owner!==await this.owner())return;const prior=await this.storage.get(key)||{};await this.storage.set(key,change(prior));});this.writes=next;return next;}
  allowed(){return this.id==='ipccepibnkcfpikgebdaanimocdappfk';}
  async status(){const owner=await this.owner();return this.allowed()&&owner?(await this.storage.get('local-test-update:'+owner)||{enabled:false}):{enabled:false};}
  async settings(enabled){
   if(!this.allowed() || typeof enabled!=='boolean')throw Error('invalid_request');
   const generation=++this.generation;
   if(!enabled && this.starting)this.agent.stop('user_stopped',{drain:true}).catch(()=>{});
   const owner=await this.owner();if(!owner)throw Error('backend_login_required');
   if(generation!==this.generation || owner!==await this.owner())throw Error('cancelled');
   await this.write(owner,generation,prior=>({...prior,enabled,baseline:this.version}));
  }
  async cancel(){const generation=++this.generation,owner=await this.owner();if(owner)await this.write(owner,generation,prior=>({...prior,enabled:false}));}
  async run(){if(!this.active)this.active=this.perform().finally(()=>{this.active=null;});return this.active;}
  async perform(){
   if(!this.allowed())return;
   const generation=this.generation,owner=await this.owner();if(!owner)return;
   const key='local-test-update:'+owner,prefs=await this.storage.get(key),ticket=await this.storage.get('local_update_verified');
   if(!prefs?.enabled || prefs.baseline===this.version || ticket?.version!==this.version || !/^[a-f0-9]{64}$/.test(ticket.digest))return;
   const consumed=this.version+':'+ticket.digest;if(prefs.consumed===consumed)return;
   const s=await this.agent.read();
   // Old evidence is never discarded or turned into another participant's trial.
   if(s.enabled || s.outbox?.length || s.work_slots?.length || s.note || s.note_id || s.note_url || s.enrichment || s.reopen || ['note','reopen_note','enrich'].includes(s.phase) || await this.isBusy())return;
   if(generation!==this.generation || owner!==await this.owner())return;
   await this.write(owner,generation,prior=>({...prior,consumed}));
   if(generation!==this.generation || owner!==await this.owner())return;
   this.starting=true;
   try {await this.start(async()=>generation===this.generation && owner===await this.owner());}catch(e){await this.write(owner,generation,prior=>({...prior,error:e.message}));}finally{this.starting=false;}
  }
 }
 root.CrowdLocalTest=CrowdLocalTest;
})(globalThis);
