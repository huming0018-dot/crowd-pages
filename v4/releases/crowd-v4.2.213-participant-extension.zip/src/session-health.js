/* Low-frequency observation of existing DOM pages. Never navigates or resumes work. */
(function(root){
  'use strict';
  const platforms=['xiaohongshu','bilibili'];
  const attachments=new Map();
  class Health {
    // Unpublished permission candidate; activation requires a reviewed installation.
    // Reattach the existing isolated scripts, then require a new DOM message.
    static async probePage(chrome,tab,message,valid=async()=>true){
      const bounded=async job=>{let timer;try{return await Promise.race([job,new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('probe_timeout')),1500);})]);}finally{clearTimeout(timer);}};
      if(!await valid())return null;
      try{return await bounded(chrome.tabs.sendMessage(tab.id,message,{frameId:0}));}
      catch(error){if(!/Receiving end does not exist/i.test(String(error?.message||'')))return null;}
      try{
        const manifest=chrome.runtime.getManifest();
        if(!manifest.permissions?.includes('scripting')||!chrome.scripting?.executeScript||!await valid())return null;
        const platform=message.type==='crowd_session_probe'?'xiaohongshu':message.input?.action==='session_health'?message.input.platform:null;
        const hosts=platform==='xiaohongshu'?['www.xiaohongshu.com','m.xiaohongshu.com']:platform==='bilibili'?['www.bilibili.com','space.bilibili.com']:[];
        const url=new URL(tab.url);
        if(tab.discarded||url.protocol!=='https:'||!hosts.includes(url.hostname))return null;
        const scripts=manifest.content_scripts?.find(entry=>(entry.world||'ISOLATED')==='ISOLATED'&&entry.matches?.includes(url.origin+'/*'))?.js;
        if(!scripts?.length)return null;
        const frame=await bounded(chrome.webNavigation.getFrame({tabId:tab.id,frameId:0}));
        if(!frame?.documentId||frame.url!==tab.url||frame.documentLifecycle&&frame.documentLifecycle!=='active'||!await valid())return null;
        let attachment=attachments.get(tab.id);
        if(attachment?.document!==frame.documentId){
          attachment={document:frame.documentId};
          // One bounded attempt per document/worker, shared by concurrent probes.
          attachment.ready=bounded(chrome.scripting.executeScript({target:{tabId:tab.id,documentIds:[frame.documentId]},world:'ISOLATED',files:scripts})).then(()=>true,()=>false);
          attachments.set(tab.id,attachment);
          if(attachments.size>64)attachments.delete(attachments.keys().next().value);
        }
        if(!await attachment.ready||!await valid())return null;
        return await bounded(chrome.tabs.sendMessage(tab.id,message,{documentId:frame.documentId}));
      }catch(_){return null;}
    }
    constructor(runtime){this.r=runtime;this.active=null;this.observedOwner=null;}
    async read(owner){owner=owner||await this.r.owner();return owner?await this.r.storage.get('platform-health:'+owner)||{}:{};}
    async check(force=false){
      if(this.active)return this.active;
      this.active=this.observe(force).finally(()=>{this.active=null;});return this.active;
    }
    async observe(force){
      const owner=await this.r.owner();if(!owner)return {};
      const state=await this.read(owner),now=this.r.now();
      // A new worker must prove its receivers before trusting a durable healthy row.
      if(!force&&this.observedOwner===owner&&state.checked_at&&now>=state.checked_at&&now-state.checked_at<60000)return state;
      let pages;try{pages=await this.r.probe();}catch(_){pages={xiaohongshu:{status:'unknown'},bilibili:{status:'unknown'}};}if(owner!==await this.r.owner())throw Error('cancelled');
      for(const platform of platforms){
        const old=state[platform]||{},page=pages[platform]||{status:'no_page'};
        const next={...old,status:page.status,checked_at:now,reason:null};
        if(page.status==='authenticated'&&page.principal_ref){
          next.observed_ref=page.principal_ref;
          next.expected_ref=old.expected_ref||page.principal_ref;
          if(next.expected_ref!==page.principal_ref){next.status='account_changed';next.reason='platform_identity_changed';}
          else{next.observed_at=now;next.recovered=!!old.reason||old.recovered===true;}
        }else if(page.status==='logged_out')next.reason='login_required';
        else if(page.status==='challenge')next.reason=['captcha','rate_limit'].includes(page.reason)?page.reason:'captcha';
        else if(old.reason||page.status!=='no_page'&&old.expected_ref)next.reason='identity_verification_required';
        state[platform]=next;
      }
      state.checked_at=now;
      if(owner!==await this.r.owner())throw Error('cancelled');
      await this.r.storage.set('platform-health:'+owner,state);this.observedOwner=owner;return state;
    }
    async confirm(platform,principal_ref){
      if(!platforms.includes(platform)||!/^[a-f0-9]{64}$/.test(principal_ref))throw Error('identity_verification_required');
      while(this.active)await this.active.catch(()=>{});
      this.active=this.bind(platform,principal_ref).finally(()=>{this.active=null;});return this.active;
    }
    async bind(platform,principal_ref){
      const owner=await this.r.owner();if(!owner)throw Error('backend_login_required');
      const state=await this.read(owner),now=this.r.now();state[platform]={status:'authenticated',expected_ref:principal_ref,observed_ref:principal_ref,checked_at:now,observed_at:now,reason:null,recovered:true};state.checked_at=0;
      if(owner!==await this.r.owner())throw Error('cancelled');await this.r.storage.set('platform-health:'+owner,state);return state;
    }
    async require(platform){const state=await this.check(),entry=state[platform];if(entry?.reason)throw Error(entry.reason);return entry;}
    async publicState(){const state=await this.read();return Object.fromEntries(platforms.map(platform=>{const p=state[platform]||{};return [platform,{status:p.status||'not_checked',reason:p.reason||null,checked_at:p.checked_at||null,observed_at:p.observed_at||null,recovered:p.recovered===true}];}));}
  }
  root.CrowdPlatformHealth=Health;
})(globalThis);
