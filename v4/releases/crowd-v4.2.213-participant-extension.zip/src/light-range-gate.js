/* Serialize source admissions for one bound page and one persisted media stage. */
(function(root){
 'use strict';
 const UUID=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
 class LightRangeGate {
  constructor({agent,api,workTabs,owner,uuid,wait}){Object.assign(this,{agent,api,workTabs,owner,uuid,wait});this.active=false;}
  async valid(message,sender,operation){
   const owner=await this.owner(),s=await this.agent.read(),p=s.light_processing,entry=(await this.workTabs.entries()).search,signal=this.agent.controller?.signal;
   if(!owner||!this.agent.active||this.agent.stopping||this.agent.pendingStop||signal?.aborted||!signal||s.run_generation!==this.agent.generation||p?.stage!=='audio_probe_running'||p.stage_id!==operation||
      sender.frameId!==0||sender.tab?.id!==entry?.tab||entry.state!=='opened'||entry.token!==message.token||entry.document!==message.document||
      !UUID.test(message.token||'')||!UUID.test(message.document||'')||!UUID.test(operation||'')||
      !this.agent.lightProcessingAuthorized({...s,light_processing:{...p,stage:'asr_running'}},owner,'asr'))throw Error('audio_mp4_authorization_denied');
   try{if(root.CrowdCore.noteURL(entry.url).id!==p.note)throw Error('invalid');}catch(_){throw Error('audio_mp4_authorization_denied');}
   return {s,p,signal};
  }
  async admit(message,sender){
   if(this.active)throw Error('audio_mp4_authorization_denied');if(![1,2].includes(message.count))throw Error('audio_mp4_authorization_denied');this.active=true;
   try{let current=await this.valid(message,sender,message.operation);for(let n=0;n<message.count;n++){
     const request=this.uuid();if(!UUID.test(request))throw Error('audio_mp4_authorization_denied');let elapsed=0;
     for(;;){current=await this.valid(message,sender,message.operation);const {p,signal}=current;let result;
      try{result=await this.api.rpc('base_light_audio_admit',{p_request:request,p_task:p.task,p_lease:p.lease,p_installation:p.installation,p_parent:p.parent,p_note:p.note},signal);}catch(_){throw Error(signal.aborted?'cancelled':'audio_mp4_admission_unknown');}
      await this.valid(message,sender,message.operation);
      if(result?.request===request&&result.parent===p.parent&&result.note_id===p.note&&result.allowed===true)break;
      if(result?.reason!=='action_gap'||!Number.isSafeInteger(result.wait_ms)||result.wait_ms<1||result.wait_ms>60000||elapsed+result.wait_ms>90000)throw Error('audio_mp4_budget_unavailable');
      elapsed+=result.wait_ms;await this.wait(result.wait_ms,signal);
     }
   }return {allowed:true};}finally{this.active=false;}
  }
 }
 root.CrowdLightRangeGate=LightRangeGate;
})(globalThis);
