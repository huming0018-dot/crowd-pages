/* Local MP4 audio index and bounded WebCodecs decoding. The caller owns all source
   admission, HTTP, cancellation and durable progress; this module never sees a URL. */
(function(root){
 'use strict';
 const MAX_INDEX=2*1024*1024,MAX_SAMPLES=60000,WINDOW=16;
 const bad=code=>{throw Error(code);};
 const uint64=(v,p)=>{const n=v.getUint32(p)*4294967296+v.getUint32(p+4);if(!Number.isSafeInteger(n))bad('audio_mp4_invalid');return n;};
 function validateMoov(bytes){const v=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),containers=new Set(['moov','trak','mdia','minf','stbl']),tables={stts:8,ctts:8,stsc:12,stco:4,co64:8,stss:4};let totalSamples=0,boxes=0;
  function walk(start,end,depth){if(depth>8)bad('audio_mp4_index_limit');let pos=start;while(pos<end){if(++boxes>5000||end-pos<8)bad('audio_mp4_invalid');let length=v.getUint32(pos),header=8;const type=String.fromCharCode(...bytes.subarray(pos+4,pos+8));if(length===1){if(end-pos<16)bad('audio_mp4_invalid');length=uint64(v,pos+8);header=16;}if(length===0)length=end-pos;if(length<header||pos+length>end)bad('audio_mp4_invalid');const body=pos+header,limit=pos+length;
    if(containers.has(type))walk(body,limit,depth+1);
    else if(type==='stsz'||type==='stz2'){if(limit-body<12)bad('audio_mp4_invalid');const count=v.getUint32(body+8);totalSamples+=count;if(count>100000||totalSamples>160000)bad('audio_mp4_index_limit');if(type==='stsz'&&v.getUint32(body+4)===0&&count*4>limit-body-12)bad('audio_mp4_invalid');if(type==='stz2'){const bits=v.getUint8(body+7);if(![4,8,16].includes(bits)||Math.ceil(count*bits/8)>limit-body-12)bad('audio_mp4_invalid');}}
    else if(Object.hasOwn(tables,type)){if(limit-body<8)bad('audio_mp4_invalid');const count=v.getUint32(body+4);if(count>100000||count*tables[type]>limit-body-8)bad('audio_mp4_index_limit');}
    pos=limit;}}
  walk(0,bytes.length,0);
 }
 class AudioIndex {
  constructor(read,signal){if(typeof read!=='function')bad('audio_mp4_invalid');this.read=read;this.signal=signal;this.size=null;this.track=null;this.samples=[];this.pending=[];this.nextSample=0;this.nextWindow=0;this.decoder=null;this.decodeError=null;}
  alive(){if(this.signal?.aborted)bad('cancelled');}
  async ranges(ranges){this.alive();if(!Array.isArray(ranges)||ranges.length<1||ranges.length>256)bad('audio_mp4_invalid');for(const [a,b] of ranges)if(!Number.isSafeInteger(a)||!Number.isSafeInteger(b)||a<0||b<=a||this.size!==null&&b>this.size)bad('audio_mp4_invalid');
   const r=await this.read(ranges,this.signal);this.alive();if(!r||!Number.isSafeInteger(r.size)||r.size<32||this.size!==null&&r.size!==this.size||!Array.isArray(r.parts)||r.parts.length!==ranges.length)bad('audio_mp4_source_changed');this.size=r.size;
   return r.parts.map((v,i)=>{if(!(v instanceof Uint8Array)||v.length!==ranges[i][1]-ranges[i][0])bad('audio_mp4_range_invalid');return v;});}
  async open(){
   if(!root.CrowdMP4Box||typeof AudioDecoder==='undefined')bad('audio_mp4_decoder_unavailable');
   const file=root.CrowdMP4Box.createFile();let info=null;file.onReady=value=>{info=value;};file.onError=()=>bad('audio_mp4_invalid');let pos=0,boxes=0,foundFtyp=false,foundMoov=false;const mediaRanges=[];let indexBytes=null;
   while(this.size===null||pos<this.size){if(++boxes>64)bad('audio_mp4_invalid');const head=(await this.ranges([[pos,pos+8]]))[0],v=new DataView(head.buffer,head.byteOffset,head.byteLength);let n=v.getUint32(0),header=8;const type=String.fromCharCode(...head.subarray(4,8));let extra=null;if(n===1){extra=(await this.ranges([[pos+8,pos+16]]))[0];n=uint64(new DataView(extra.buffer,extra.byteOffset,8),0);header=16;}if(n===0)n=this.size-pos;if(n<header||pos+n>this.size)bad('audio_mp4_invalid');if(type==='mdat')mediaRanges.push([pos+header,pos+n]);
    {if((type==='ftyp'||type==='moov')&&n>MAX_INDEX)bad('audio_mp4_index_limit');const length=(type==='ftyp'||type==='moov')?n:header,bytes=new Uint8Array(length);bytes.set(head);if(extra)bytes.set(extra,8);if(length>header)bytes.set((await this.ranges([[pos+header,pos+length]]))[0],header);if(type==='moov'){validateMoov(bytes);indexBytes=bytes.slice();}const buffer=bytes.buffer;buffer.fileStart=pos;file.appendBuffer(buffer);if(type==='ftyp')foundFtyp=true;if(type==='moov')foundMoov=true;}
    pos+=n;
   }
   if(!foundFtyp||!foundMoov||!info||!Array.isArray(info.audioTracks)||info.audioTracks.length!==1)bad('audio_mp4_track_unavailable');
   const track=info.audioTracks[0],raw=file.getTrackById(track.id),entry=raw?.mdia?.minf?.stbl?.stsd?.entries?.[0],description=(entry?.esds||entry?.wave?.esds)?.esd?.descs?.find(d=>d.tag===4)?.descs?.find(d=>d.tag===5)?.data;
   const codec=track.codec==='mp4a.40.2'?'mp4a.40.2':String(track.codec).toLowerCase()==='mp4a.6b'?'mp3':null;
   if(raw?.samples?.length>MAX_SAMPLES)bad('audio_mp4_index_limit');
   if(!codec||codec==='mp4a.40.2'&&!description||!raw?.samples||raw.samples.length<1||!Number.isFinite(track.audio?.sample_rate)||track.audio.sample_rate<8000||track.audio.sample_rate>96000||![1,2].includes(track.audio.channel_count))bad('audio_mp4_codec_unavailable');
   if(!Array.isArray(track.edits)||track.edits.length>1||track.edits.some(e=>e.media_rate_integer!==1||e.media_rate_fraction!==0||e.media_time<0))bad('audio_mp4_timeline_unavailable');
   const shift=track.edits[0]?.media_time||0,duration=track.movie_duration/track.movie_timescale;if(!Number.isFinite(duration)||duration<=0||duration>60||!Number.isSafeInteger(Math.ceil(duration/WINDOW)))bad('audio_duration_limit');
   const samples=raw.samples.map(s=>({offset:s.offset,size:s.size,time:(s.cts-shift)/s.timescale,duration:s.duration/s.timescale}));let lastOffset=-1,lastTime=-Infinity,totalBytes=0;
   for(const s of samples){if(!Number.isSafeInteger(s.offset)||!Number.isSafeInteger(s.size)||s.offset<0||s.size<1||s.size>131072||!mediaRanges.some(([a,b])=>s.offset>=a&&s.offset+s.size<=b)||s.offset<lastOffset||!Number.isFinite(s.time)||!Number.isFinite(s.duration)||s.duration<=0||s.time<lastTime)bad('audio_mp4_invalid');lastOffset=s.offset+s.size;lastTime=s.time;totalBytes+=s.size;}
   for(const other of info.tracks.filter(t=>t.id!==track.id)){const otherSamples=file.getTrackById(other.id)?.samples;if(!Array.isArray(otherSamples)||otherSamples.length>100000)bad('audio_mp4_invalid');let i=0,lastEnd=0;for(const v of otherSamples){if(!Number.isSafeInteger(v.offset)||!Number.isSafeInteger(v.size)||v.offset<lastEnd||v.size<0||v.offset+v.size>this.size)bad('audio_mp4_invalid');lastEnd=v.offset+v.size;while(i<samples.length&&samples[i].offset+samples[i].size<=v.offset)i++;if(i<samples.length&&samples[i].offset<v.offset+v.size)bad('audio_mp4_invalid');}}
   if(!Number.isSafeInteger(totalBytes))bad('audio_mp4_index_limit');
   const config={codec,sampleRate:track.audio.sample_rate,numberOfChannels:track.audio.channel_count,...(description?{description:new Uint8Array(description)}:{})};if(!(await AudioDecoder.isConfigSupported(config)).supported)bad('audio_mp4_codec_unavailable');this.alive();
   this.track={duration,rate:track.audio.sample_rate,channels:track.audio.channel_count,config};this.samples=samples;
   this.decoder=new AudioDecoder({output:data=>{try{const channels=[];for(let i=0;i<data.numberOfChannels;i++){const array=new Float32Array(data.numberOfFrames);data.copyTo(array,{planeIndex:i,format:'f32-planar'});channels.push(array);}this.pending.push({time:data.timestamp/1e6,rate:data.sampleRate,channels});}catch(_){this.decodeError='audio_mp4_decode_failed';}finally{data.close();}},error:()=>{this.decodeError='audio_mp4_decode_failed';}});this.decoder.configure(config);
   const digest=await crypto.subtle.digest('SHA-256',indexBytes);this.alive();const indexRef=Array.from(new Uint8Array(digest),v=>v.toString(16).padStart(2,'0')).join('');
   return {duration,total:Math.ceil(duration/WINDOW),audioBytes:totalBytes,size:this.size,indexRef};
  }
  resume(index){if(!this.track||this.nextWindow!==0||!Number.isInteger(index)||index<1||index>=Math.ceil(this.track.duration/WINDOW))bad('audio_checkpoint_unavailable');const start=index*WINDOW;this.nextSample=this.samples.findIndex(s=>s.time+s.duration>start-.05);if(this.nextSample<0)bad('audio_checkpoint_unavailable');this.nextWindow=index;}
  async chunk(index){this.alive();if(!this.track||index!==this.nextWindow||index>=Math.ceil(this.track.duration/WINDOW))bad('audio_checkpoint_unavailable');const start=index*WINDOW,end=Math.min(start+WINDOW,this.track.duration),selected=[];
   while(this.nextSample<this.samples.length&&this.samples[this.nextSample].time<end){selected.push(this.samples[this.nextSample++]);}
   if(!selected.length)bad('audio_mp4_timeline_unavailable');const ranges=[];for(const s of selected){const last=ranges[ranges.length-1];if(last&&last[1]===s.offset)last[1]+=s.size;else ranges.push([s.offset,s.offset+s.size]);}
   const buffers=[];for(let i=0;i<ranges.length;i+=256)buffers.push(...await this.ranges(ranges.slice(i,i+256)));
   let range=0,at=0;for(const s of selected){while(range<ranges.length&&s.offset>=ranges[range][1])range++;if(range>=ranges.length||s.offset<ranges[range][0]||s.offset+s.size>ranges[range][1])bad('audio_mp4_invalid');at=s.offset-ranges[range][0];this.decoder.decode(new EncodedAudioChunk({type:'key',timestamp:Math.round(s.time*1e6),duration:Math.round(s.duration*1e6),data:buffers[range].subarray(at,at+s.size)}));}
   await this.decoder.flush();this.alive();if(this.decodeError)bad(this.decodeError);const rate=this.track.rate,count=Math.ceil((end-start)*rate),mono=new Float32Array(count);let coveredStart=Infinity,coveredEnd=-Infinity;
   this.pending.sort((a,b)=>a.time-b.time);for(const row of this.pending){if(row.rate!==rate||!row.channels.length||row.channels.length>2)bad('audio_mp4_decode_failed');const begin=Math.round((row.time-start)*rate),length=row.channels[0].length;if(begin<count&&begin+length>0&&coveredEnd!==-Infinity&&begin>coveredEnd+rate*.05)bad('audio_mp4_timeline_unavailable');for(let k=Math.max(0,-begin);k<length&&begin+k<count;k++){let x=0;for(const channel of row.channels)x+=channel[k]/row.channels.length;mono[begin+k]=x;}if(begin<count&&begin+length>0){coveredStart=Math.min(coveredStart,Math.max(0,begin));coveredEnd=Math.max(coveredEnd,Math.min(count,begin+length));}}
   this.pending=this.pending.filter(row=>row.time+row.channels[0].length/row.rate>end);if(coveredStart>rate*.05||coveredEnd<count-rate*.05)bad('audio_mp4_timeline_unavailable');
   const outCount=Math.round((end-start)*16000),ctx=new OfflineAudioContext(1,outCount,16000),input=ctx.createBuffer(1,count,rate);input.copyToChannel(mono,0);const node=ctx.createBufferSource();node.buffer=input;node.connect(ctx.destination);node.start();const out=await ctx.startRendering();this.alive();const data=new Uint8Array(44+outCount*2),view=new DataView(data.buffer),tag=(p,s)=>{for(let i=0;i<s.length;i++)data[p+i]=s.charCodeAt(i);};tag(0,'RIFF');view.setUint32(4,36+outCount*2,true);tag(8,'WAVEfmt ');view.setUint32(16,16,true);view.setUint16(20,1,true);view.setUint16(22,1,true);view.setUint32(24,16000,true);view.setUint32(28,32000,true);view.setUint16(32,2,true);view.setUint16(34,16,true);tag(36,'data');view.setUint32(40,outCount*2,true);const values=out.getChannelData(0);for(let i=0;i<outCount;i++){const x=Math.max(-1,Math.min(1,values[i]));view.setInt16(44+2*i,Math.round(x*(x<0?32768:32767)),true);}this.nextWindow++;return {index,total:Math.ceil(this.track.duration/WINDOW),source_duration:this.track.duration,start,duration:end-start,data};
  }
  close(){try{this.decoder?.close();}catch(_){}this.decoder=null;this.pending=[];this.samples=[];}
 }
 root.CrowdLightMP4={AudioIndex,validateMoov};
})(globalThis);
