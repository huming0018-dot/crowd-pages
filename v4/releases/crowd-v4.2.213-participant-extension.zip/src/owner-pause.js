/* Owner base pause: never acknowledge a checkpoint containing unknown work. */
(function(root){
 'use strict';
 class OwnerPause {
  constructor(r){this.r=r;this.active=null;}
  async run(){if(this.active)return this.active;this.active=this.inspect().finally(async()=>{this.active=null;const owner=await this.r.owner();await this.r.schedule(!!owner&&!!await this.r.storage.get('owner-pause:'+owner));});return this.active;}
  async inspect(){
   const owner=await this.r.owner();if(!owner)return false;
   const key='owner-pause:'+owner;let mark=await this.r.storage.get(key);let s=await this.r.agent.read();
   if(s.owner_id!==owner)return false;
   if(!mark){
    if(s.control?.owner_pause_requested!==true||s.task?.owner_base_task!==true)return false;
    if(s.owner_reply_checkpoint?.state==='body_rejected')return true;
    if(['light_resume','light_reopen'].includes(s.phase)&&s.light_resume&&!s.owner_reply_checkpoint){
     const p=s.light_resume,installation=s.task.node_run?.installation_id;
     if(p.schema!=='crowd-light-resume-v1'||p.owner!==owner||p.task!==s.task.id||p.lease!==s.task.lease_token||p.installation!==installation||!p.parent||!p.last_request||p.intent?.request!==p.parent||p.body?.standard?.note_id!==p.note||!['acked','admitted','opened','opening','unknown'].includes(p.state)){s.last_error='light_checkpoint_mismatch';await this.r.agent.save(s);return true;}
     mark={task:p.task,lease:p.lease,installation,stage:'light_stopping'};await this.r.storage.set(key,mark);
    }
   }
   if(!mark){
    const e=s.enrichment;
    if(s.phase==='enrich'&&e?.stage==='comments'&&!e.structured&&!e.sdk_pending&&!e.repair&&!e.record?.extra?.comments&&
      s.task.comments_capture===false&&s.task.structured_capture!==true&&s.profiles!==true&&!s.test_run&&!s.outbox?.length&&!s.work_slots?.length&&
      !s.sdk_unknown&&!s.sdk_pending&&!s.pending_risk&&e.parent===s.detail_intent?.request&&
      (s.accepted_parents||[]).some(x=>x.parent===e.parent&&x.task===s.task.id&&x.lease===s.task.lease_token)){
      s.enrichment=null;s.phase='search_done';s.note_url=null;s.note_id=null;s.loaded_at=null;await this.r.agent.save(s);
    }
    const intent=s.detail_intent;
    const unresolved=(s.owner_pause_unresolved||[]).find(x=>x.request===intent?.request&&x.task===s.task.id&&x.lease===s.task.lease_token&&x.installation===s.task.node_run?.installation_id&&x.state==='unresolved');
    const settledIntent=!intent?.admitted||!!unresolved||(s.accepted_parents||[]).some(x=>x.parent===intent.request&&x.task===s.task.id)||(s.rejected||[]).some(x=>x.request===intent.request)||(s.interrupted||[]).some(x=>x.request===intent.request&&x.task===s.task.id&&x.outcome==='confirmed_not_opened');
    if(['note','reopen_note','search'].includes(s.phase)&&!s.outbox?.length&&!s.work_slots?.length&&!s.enrichment&&!s.pending_risk&&!s.sdk_unknown&&!s.sdk_pending)return false;
    if(!['idle','search_done'].includes(s.phase)||!settledIntent||s.outbox?.length||s.work_slots?.length||s.enrichment||s.navigation_stage||s.pending_risk||s.sdk_unknown||s.sdk_pending||this.r.agent.recoveryUnsafe(s)||this.r.agent.poolJobs?.size)return true;
    const installation=s.task.node_run?.installation_id;
    if(!installation||!s.task.lease_token)return true;
    mark={task:s.task.id,lease:s.task.lease_token,installation,stage:'stopping',...(unresolved?{unresolved:{request:unresolved.request,note_id:unresolved.note_id}}:{})};
    await this.r.storage.set(key,mark);
   }
   if(owner!==await this.r.owner())return true;
   if(mark.stage==='light_stopping'){
    try{await this.r.stop('owner_paused',{drain:true,expectedOwner:owner});}
    catch(error){mark.stage='light_unknown';await this.r.storage.set(key,mark);throw error;}
    s=await this.r.agent.read();const p=s.light_resume,q=s.light_processing;
    if(s.owner_id!==owner||s.enabled||s.task?.id!==mark.task||s.task?.lease_token!==mark.lease||!p||p.owner!==owner||p.task!==mark.task||p.lease!==mark.lease||p.installation!==mark.installation||s.light_stop_unsettled||s.light_source_unsettled||['opening','unknown'].includes(p.state)||q&&q.stage!=='observed'){
     mark.stage='light_unknown';await this.r.storage.set(key,mark);return true;
    }
    if(q){
     if(q.owner!==owner||q.task!==p.task||q.lease!==p.lease||q.installation!==p.installation||q.parent!==p.parent||q.note!==p.note){mark.stage='light_unknown';await this.r.storage.set(key,mark);return true;}
     const item=this.r.agent.queueLight(s,p.parent,p.note,{...q,note_id:p.note,reason:q.reason||'interrupted',asr_gap:q.asr_gap||(!q.asr_done?'asr_interrupted':null),ocr_gap:q.ocr_gap||(!q.ocr_done?'ocr_interrupted':null)},{sequence:p.sequence+1,previous:p.last_request});
     if(!item.record.gaps.includes('interrupted'))item.record.gaps.push('interrupted');
     p.sequence++;p.last_request=item.request;p.state='waiting_ack';p.pause_pending=true;p.progress=JSON.parse(JSON.stringify(q));delete s.light_processing;
    }else p.state='acked';
    delete p.new_lease;delete p.reopen_request;delete p.reopen_from_lease;s.phase='search_done';s.note_id=null;s.note_url=null;s.loaded_at=null;await this.r.agent.save(s);
    mark.stage='light_draining';await this.r.storage.set(key,mark);await this.r.agent.repairDelivery();
   }
   if(mark.stage==='light_draining'){
    s=await this.r.agent.read();const p=s.light_resume;
    if(s.outbox?.length){await this.r.agent.repairDelivery();return true;}
    if(s.owner_id!==owner||s.enabled||s.task?.id!==mark.task||s.task?.lease_token!==mark.lease||!p||p.state!=='acked'||p.lease!==mark.lease||p.installation!==mark.installation||s.outbox?.length||s.light_stop_unsettled||s.light_source_unsettled||this.r.agent.active||this.r.agent.poolJobs?.size)return true;
    let ack;try{ack=await this.r.rpc('owner_pause_ack',{p_task:mark.task,p_lease:mark.lease,p_installation:mark.installation});}catch(error){const status=await this.r.rpc('owner_pause_status',{p_task:mark.task,p_lease:mark.lease,p_installation:mark.installation});if(status?.state!=='resumed')throw error;ack={settled:true,task_id:mark.task,lease_token:mark.lease};}
    if(ack?.settled!==true||ack.task_id!==mark.task||ack.lease_token!==mark.lease)return true;
    mark={...mark,stage:'paused'};await this.r.storage.set(key,mark);
   }
   if(mark.stage==='stopping'){
    await this.r.stop('owner_paused',{drain:true,expectedOwner:owner});
    s=await this.r.agent.read();
    if(s.owner_id!==owner||s.enabled||s.task?.id!==mark.task||s.task?.lease_token!==mark.lease||s.outbox?.length||s.work_slots?.length||s.enrichment||s.navigation_stage||s.pool_cleanup_error||this.r.agent.active||this.r.agent.poolJobs?.size)return true;
    let ack;
    try{ack=await this.r.rpc(mark.unresolved?'owner_pause_defer':'owner_pause_ack',{p_task:mark.task,p_lease:mark.lease,p_installation:mark.installation,...(mark.unresolved?{p_request:mark.unresolved.request,p_note:mark.unresolved.note_id}:{})});}
    catch(error){const status=await this.r.rpc('owner_pause_status',{p_task:mark.task,p_lease:mark.lease,p_installation:mark.installation});if(status?.state!=='resumed')throw error;ack={settled:true,task_id:mark.task,lease_token:mark.lease};}
    if(ack?.settled!==true||ack.task_id!==mark.task||ack.lease_token!==mark.lease)return true;
    mark={...mark,stage:'paused'};await this.r.storage.set(key,mark);
   }
   if(mark.stage!=='paused')return true;
   const status=await this.r.rpc('owner_pause_status',{p_task:mark.task,p_lease:mark.lease,p_installation:mark.installation});
   if(status?.state!=='resumed')return true;
   const desired=async()=>owner===await this.r.owner()&&(await this.r.session.record(owner)).desired_running===true;
   if(!await desired())return true;
   s=await this.r.agent.read();
   if(s.light_resume){const p=s.light_resume;
    if(p.state==='waiting_reply'&&p.origin_lease===mark.lease&&p.lease===s.task?.lease_token&&p.owner===owner&&p.task===mark.task&&p.installation===mark.installation&&s.owner_reply_checkpoint?.parent===p.parent){
     if(s.enabled){await this.r.storage.set(key,null);return true;}
     if(['admitted','opened'].includes(s.owner_reply_checkpoint.state)&&s.phase==='reply_reopen'){await this.r.start(false,{valid:desired});s=await this.r.agent.read();if(s.enabled===true)await this.r.storage.set(key,null);return true;}
     s.last_error='light_reply_resume_unavailable';await this.r.agent.save(s);return true;
    }
    if(['admitted','opening','opened'].includes(p.state)&&(p.reopen_from_lease||p.origin_lease)===mark.lease&&p.lease===p.new_lease&&p.lease===s.task?.lease_token&&p.owner===owner&&p.task===mark.task&&p.installation===mark.installation){
     if(s.enabled){await this.r.storage.set(key,null);return true;}
     if(p.state==='opening'){s.last_error='light_source_unknown';await this.r.agent.save(s);return true;}
     s.phase='light_reopen';await this.r.agent.save(s);await this.r.start(false,{valid:desired});s=await this.r.agent.read();if(s.enabled===true)await this.r.storage.set(key,null);return true;
    }
    if(p.schema!=='crowd-light-resume-v1'||p.owner!==owner||p.task!==mark.task||p.lease!==mark.lease||p.installation!==mark.installation||!['acked','admitting'].includes(p.state)||!p.parent||!p.last_request||!p.note||p.body?.standard?.note_id!==p.note||p.intent?.request!==p.parent||!(s.accepted_parents||[]).some(x=>x.owner===owner&&x.task===p.task&&x.lease===(p.origin_lease||mark.lease)&&x.parent===p.parent&&x.note===p.note)){s.last_error='light_checkpoint_mismatch';await this.r.agent.save(s);return true;}
    try{if(!globalThis.CrowdCore||globalThis.CrowdCore.noteURL(p.url).id!==p.note)throw Error('invalid');}catch(_){s.last_error='light_checkpoint_mismatch';await this.r.agent.save(s);return true;}
   }
   if(s.owner_reply_checkpoint){
    const c=s.owner_reply_checkpoint;
    if(c.state==='unknown'||!['waiting','admitting'].includes(c.state)){s.last_error=c.state==='unknown'?'reply_action_unknown':'reply_resume_unavailable';await this.r.agent.save(s);return true;}
    try{if(!globalThis.CrowdCore||globalThis.CrowdCore.noteURL(c.url).id!==c.note)throw Error('invalid');}catch(_){s.last_error='reply_checkpoint_invalid';await this.r.agent.save(s);return true;}
    if(c.schema!=='crowd-owner-reply-checkpoint-v1'||c.owner!==owner||c.task!==mark.task||c.lease!==mark.lease||c.installation!==mark.installation||!c.parent||!c.note||!c.url||c.enrichment?.parent!==c.parent||c.enrichment?.record?.standard?.note_id!==c.note||c.enrichment?.action_pending!==false||!Array.isArray(c.receipts)||!(s.accepted_parents||[]).some(p=>p.owner===owner&&p.task===c.task&&p.lease===(c.origin_lease||c.lease)&&p.parent===c.parent&&p.note===c.note)){s.last_error='reply_checkpoint_invalid';await this.r.agent.save(s);return true;}
   }
   if(s.owner_id!==owner||s.task?.id!==mark.task||s.outbox?.length||s.work_slots?.length||s.enrichment||s.navigation_stage||this.r.agent.recoveryUnsafe(s))return true;
   if(s.enabled){s.enabled=false;await this.r.agent.save(s);}
   s.enabled=true;await this.r.agent.save(s);
   let claim;try{claim=await this.r.claim(mark.task);}finally{s=await this.r.agent.read();s.enabled=false;await this.r.agent.save(s);}
   if(!await desired()||claim?.task?.id!==mark.task||claim.task.lease_token===mark.lease||claim.task.node_run?.installation_id!==mark.installation)return true;
   s=await this.r.agent.read();s.task=claim.task;s.assignment_refresh=false;s.control=null;s.control_checked=0;s.control_expires=0;s.last_error=null;
   if(s.light_resume&&!s.owner_reply_checkpoint){const p=s.light_resume;
    if(p.new_lease&&p.new_lease!==claim.task.lease_token){p.state='unknown';s.last_error='light_source_unknown';await this.r.agent.save(s);return true;}
    p.new_lease=claim.task.lease_token;p.reopen_request ||= this.r.agent.r.uuid();p.state='admitting';await this.r.agent.save(s);
    const admission=await this.r.rpc('base_light_reopen',{p_request:p.reopen_request,p_task:p.task,p_lease:p.new_lease,p_installation:p.installation,p_parent:p.parent,p_previous:p.last_request});
    if(admission?.request!==p.reopen_request||admission?.parent!==p.parent||admission?.previous!==p.last_request||admission?.note_id!==p.note||typeof admission?.allowed!=='boolean'){s.last_error='light_resume_unavailable';await this.r.agent.save(s);return true;}
    if(!admission.allowed){p.state='acked';p.reopen_request=null;s.last_error=admission.reason||'light_resume_unavailable';await this.r.agent.save(s);return true;}
    p.origin_lease ||= p.lease;p.reopen_from_lease=mark.lease;p.lease=p.new_lease;p.intent.lease=p.new_lease;if(p.progress)p.progress.lease=p.new_lease;
    if(s.light_processing){if(s.light_processing.lease!==p.origin_lease){s.last_error='light_checkpoint_mismatch';await this.r.agent.save(s);return true;}s.light_processing.lease=p.new_lease;}
    p.state='admitted';s.phase='light_reopen';s.next_at=0;
   }
   if(s.owner_reply_checkpoint){
    const c=s.owner_reply_checkpoint;
    if(c.new_lease&&c.new_lease!==claim.task.lease_token){c.state='unknown';s.last_error='reply_action_unknown';await this.r.agent.save(s);return true;}
    c.new_lease=claim.task.lease_token;c.reopen_request ||= this.r.agent.r.uuid();c.state='admitting';await this.r.agent.save(s);
    const admission=await this.r.rpc('base_reply_reopen',{p_request:c.reopen_request,p_task:c.task,p_lease:c.new_lease,p_installation:c.installation,p_parent:c.parent});
    if(admission?.request!==c.reopen_request||admission?.parent!==c.parent||admission?.note_id!==c.note||typeof admission?.allowed!=='boolean'){s.last_error='reply_resume_unavailable';await this.r.agent.save(s);return true;}
    if(!admission.allowed){c.state='waiting';c.reopen_request=null;s.last_error=admission.reason||'reply_resume_unavailable';await this.r.agent.save(s);return true;}
    s.enrichment=JSON.parse(JSON.stringify(c.enrichment));s.enrichment.resumed_parent=true;
    s.enrichment.acked_comment_ids=[...new Set([...(s.enrichment.acked_comment_ids||[]),...c.receipts.filter(r=>r.kind==='root_comment'&&r.record?.kind==='comment').map(r=>r.record.comment_id)])];
    s.note_id=c.note;s.note_url=c.url;s.phase='reply_reopen';s.next_at=0;c.state='admitted';
    if(s.light_resume){const p=s.light_resume;if(p.parent!==c.parent||p.note!==c.note||p.lease!==mark.lease){s.last_error='light_checkpoint_mismatch';await this.r.agent.save(s);return true;}p.origin_lease ||= p.lease;p.lease=claim.task.lease_token;p.new_lease=p.lease;p.intent.lease=p.lease;if(p.progress)p.progress.lease=p.lease;p.state='waiting_reply';}
   }
   await this.r.agent.save(s);
   if(await desired())await this.r.start(false,{valid:desired});
   s=await this.r.agent.read();if(s.enabled===true)await this.r.storage.set(key,null);
   return true;
  }
 }
 root.CrowdOwnerPause=OwnerPause;
})(typeof globalThis!=='undefined'?globalThis:this);
