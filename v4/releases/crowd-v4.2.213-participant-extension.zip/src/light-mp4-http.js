/* HTTP range transport for the selected page media only. No URL leaves this closure. */
(function(root){
 'use strict';
 const fail=code=>{throw Error(code);};
 function reader(url,admit,signal){
  if(typeof url!=='string'||typeof admit!=='function')fail('audio_mp4_invalid');let expectedSize=null,validator=null;
  const ascii=new TextDecoder('ascii'),encode=new TextEncoder();
  const find=(data,needle,start)=>{outer:for(let i=start;i+needle.length<=data.length;i++){for(let j=0;j<needle.length;j++)if(data[i+j]!==needle[j])continue outer;return i;}return -1;};
  const read=async ranges=>{
   if(signal?.aborted)fail('cancelled');if(!Array.isArray(ranges)||!ranges.length||ranges.length>256)fail('audio_mp4_invalid');
   const header='bytes='+ranges.map(([a,b])=>`${a}-${b-1}`).join(',');if(header.length>7500)fail('audio_mp4_range_limit');
   // A cross-origin multi-range request may first issue a browser CORS preflight.
   // Reserve both attempts before starting; an unused preflight reserve is conservative.
   await admit(ranges.length>1?2:1,signal);if(signal?.aborted)fail('cancelled');let response;
   try{response=await fetch(url,{headers:{Range:header},mode:'cors',credentials:'omit',redirect:'error',cache:'no-store',referrerPolicy:'no-referrer',signal});}catch(_){if(signal?.aborted)fail('cancelled');fail('audio_mp4_access_denied');}
   if(response.status!==206||!response.body){await response.body?.cancel().catch(()=>{});fail('audio_mp4_range_unsupported');}
   const tag=response.headers.get('etag');if(!tag||tag.startsWith('W/')){await response.body.cancel();fail('audio_mp4_validator_unavailable');}if(validator!==null&&tag!==validator){await response.body.cancel();fail('audio_mp4_source_changed');}if(validator===null)validator=tag;
   const contentType=response.headers.get('content-type')||'',single=ranges.length===1,headerRange=response.headers.get('content-range');let boundary=null;
   if(!single){const m=/^multipart\/byteranges\s*;\s*boundary=(?:"([!#$%&'*+.^_`|~0-9A-Za-z-]{1,70})"|([!#$%&'*+.^_`|~0-9A-Za-z-]{1,70}))/i.exec(contentType);if(!m){await response.body.cancel();fail('audio_mp4_range_unsupported');}boundary=m[1]||m[2];}
   const wanted=ranges.reduce((n,[a,b])=>n+b-a,0),limit=wanted+(single?0:Math.min(131072,ranges.length*512+1024));if(wanted>2*1024*1024||limit>2300000){await response.body.cancel();fail('audio_mp4_range_limit');}
   const input=response.body.getReader(),chunks=[];let length=0;try{for(;;){const row=await input.read();if(row.done)break;length+=row.value.byteLength;if(length>limit){await input.cancel();fail('audio_mp4_range_invalid');}chunks.push(row.value);}}finally{input.releaseLock();}
   const bytes=new Uint8Array(length);let pos=0;for(const item of chunks){bytes.set(item,pos);pos+=item.length;}
   const parts=[];let size=null;
   const validate=(text,a,b)=>{const m=/^bytes (\d+)-(\d+)\/(\d+)$/i.exec(text||'');if(!m||+m[1]!==a||+m[2]!==b-1||!Number.isSafeInteger(+m[3])||+m[3]<b)fail('audio_mp4_range_invalid');if(size!==null&&size!==+m[3])fail('audio_mp4_source_changed');size=+m[3];};
   if(single){validate(headerRange,...ranges[0]);if(bytes.length!==wanted)fail('audio_mp4_range_invalid');parts.push(bytes);}
   else{const marker=encode.encode('--'+boundary+'\r\n'),endMarker=encode.encode('--'+boundary+'--\r\n'),separator=encode.encode('\r\n\r\n');let offset=0;
    for(const [a,b] of ranges){if(find(bytes,marker,offset)!==offset)fail('audio_mp4_range_invalid');offset+=marker.length;const end=find(bytes,separator,offset);if(end<0||end-offset>512)fail('audio_mp4_range_invalid');const fields=ascii.decode(bytes.subarray(offset,end)).split('\r\n');const values=fields.filter(x=>/^content-range\s*:/i.test(x));if(values.length!==1)fail('audio_mp4_range_invalid');validate(values[0].replace(/^content-range\s*:\s*/i,''),a,b);offset=end+separator.length;const count=b-a;if(offset+count+2>bytes.length||bytes[offset+count]!==13||bytes[offset+count+1]!==10)fail('audio_mp4_range_invalid');parts.push(bytes.slice(offset,offset+count));offset+=count+2;}
    if(find(bytes,endMarker,offset)!==offset||offset+endMarker.length!==bytes.length)fail('audio_mp4_range_invalid');
   }
   if(expectedSize!==null&&size!==expectedSize)fail('audio_mp4_source_changed');expectedSize=size;return {size,parts};
  };read.identity=()=>validator;return read;
 }
 root.CrowdLightMP4HTTP={reader};
})(globalThis);
