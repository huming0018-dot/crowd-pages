(function (root) {
  'use strict';
  const clock=()=>root.performance?.now?.() ?? Date.now();
  const elapsed=start=>Math.max(0,Math.round(clock()-start));
  class CrowdAPI {
    constructor(config, storage, fetcher = (...args) => root.fetch(...args)) {
      this.config = config; this.storage = storage; this.fetcher = fetcher;
      this.authRevision = 0; this.refreshing = null;
      const u = new URL(config.url);
      if (u.protocol !== 'https:' || !u.hostname.endsWith('.supabase.co')) throw new Error('invalid_backend');
      if (!config.key || config.key.startsWith('sb_secret_')) throw new Error('public_key_required');
    }
    async request(path, body, token, signal, metrics = null) {
      const diagnosticAt=clock(),requestAt=metrics?diagnosticAt:0;let abortKind=null,httpStatus=null;
      const timeout = new AbortController();
      const abort = () => {abortKind ||= 'cancelled';timeout.abort();};
      signal?.addEventListener('abort', abort, {once: true});
      if (signal?.aborted) abort();
      const timer = setTimeout(()=>{abortKind ||= 'timeout';timeout.abort();}, 20000);
      try {
        const encoded=JSON.stringify(body),fetchAt=metrics?clock():0;
        const response = await this.fetcher(this.config.url + path, {method: 'POST', signal: timeout.signal,
          headers: {apikey: this.config.key, 'Content-Type': 'application/json',
            ...(token ? {Authorization: 'Bearer ' + token} : {})}, body:encoded});
        if(metrics)metrics.fetch_ms=elapsed(fetchAt);
        httpStatus=Number.isInteger(response.status)&&response.status>=100&&response.status<=599?response.status:null;
        const jsonAt=metrics?clock():0;let data;
        try{data=await response.json();}catch(error){
          // HTTP failure remains HTTP even when an intermediary returned non-JSON.
          if(!response.ok){const e=new Error('http_'+(httpStatus??'unknown'));e.status=httpStatus;throw e;}
          if(error&&typeof error==='object')error.requestDiagnosticKind='invalid_json';throw error;
        }
        if(metrics)metrics.json_ms=elapsed(jsonAt);
        if (!response.ok) {
          const err = new Error(data?.msg || data?.message || data?.error_description || 'http_' + response.status);
          err.status = response.status; err.code = data?.code; throw err;
        }
        return data;
      } catch(error) {
        const failure=error&&typeof error==='object'?error:new Error('request_failed');
        const kind=abortKind||(httpStatus!==null&&httpStatus>=400?(httpStatus<500?'http_4xx':'http_5xx'):failure.requestDiagnosticKind==='invalid_json'?'invalid_json':'network_unknown');
        failure.request_diagnostic={kind,http_status:httpStatus,elapsed_ms:Math.min(300000,elapsed(diagnosticAt))};
        throw failure;
      } finally {if(metrics)metrics.request_ms=elapsed(requestAt);clearTimeout(timer);signal?.removeEventListener('abort',abort);}
    }
    async saveSession(value, revision, valid = async()=>true) {
      // Serialize only commits, so a delayed storage write cannot undo logout/login.
      const pending=(this.sessionWrite || Promise.resolve()).catch(()=>{}).then(async()=>{
        if (revision !== this.authRevision || !await valid() || revision !== this.authRevision) throw new Error('cancelled');
        await this.storage.set('session', value);
        if (revision !== this.authRevision) throw new Error('cancelled');
      });
      this.sessionWrite=pending;return pending;
    }
    async login(email, password, signup = false) {
      const revision = ++this.authRevision;
      const data = await this.request(signup ? '/auth/v1/signup' : '/auth/v1/token?grant_type=password', {email, password});
      if (revision !== this.authRevision) throw new Error('cancelled');
      if (!data.access_token) return {confirmation_required: true};
      await this.saveSession({...data, expires_at: Date.now() + data.expires_in * 1000}, revision);
      return {confirmation_required: false};
    }
    async restoreSession(valid = async()=>true) {
      const revision=++this.authRevision;
      const original=await this.storage.get('session'), secret=await this.storage.get('install_secret');
      const current=async()=>{
        const s=await this.storage.get('session'), installed=await this.storage.get('install_secret');
        if (!await valid() || revision!==this.authRevision ||
            s?.user?.id!==original?.user?.id || s?.user?.email!==original?.user?.email ||
            s?.access_token!==original?.access_token || s?.refresh_token!==original?.refresh_token ||
            secret!==installed) throw new Error('cancelled');
        return true;
      };
      try {
        if (!await valid() || revision!==this.authRevision) throw new Error('cancelled');
        if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(original?.user?.id || '') ||
            typeof secret!=='string' || !/^[a-f0-9]{64}$/.test(secret) || typeof original.user.email!=='string') throw new Error('backend_restore_unavailable');
        await current();
        const hash=Array.from(new Uint8Array(await root.crypto.subtle.digest('SHA-256', new TextEncoder().encode(secret))), b=>b.toString(16).padStart(2,'0')).join('');
        // Enrollment's existing contract; never try an installation password on a manual account.
        if (original.user.email!==hash+'@crowd.invalid') throw new Error('backend_restore_unavailable');
        await current();
        const next=await this.request('/auth/v1/token?grant_type=password', {email:original.user.email, password:'Cr4!'+secret});
        await current();
        if (next?.user?.id!==original.user.id || next?.user?.email!==original.user.email) throw new Error('backend_identity_mismatch');
        if (typeof next.access_token!=='string' || !next.access_token || typeof next.refresh_token!=='string' || !next.refresh_token || !Number.isFinite(next.expires_in) || next.expires_in<=0) throw new Error('backend_unavailable');
        // Check the existing participation grant using the candidate token before persisting it.
        const status=await this.request('/rest/v1/rpc/crowd_v4_status', {}, next.access_token);
        await current();
        if (status?.error || status?.participant?.status!=='approved' || status.participant.consent!=='crowd-public-v4') throw new Error('backend_permission_denied');
        await this.saveSession({...next, expires_at:Date.now()+next.expires_in*1000}, revision, current);
        if (revision!==this.authRevision || !await valid()) throw new Error('cancelled');
        return {restored:true};
      } catch (error) {
        if (revision!==this.authRevision || !await valid()) throw new Error('cancelled');
        // Auth responses can contain account material; only fixed product errors leave recovery.
        const known=['cancelled','backend_restore_unavailable','backend_identity_mismatch','backend_permission_denied','backend_unavailable'];
        throw new Error(known.includes(error.message)?error.message:error.status===403?'backend_permission_denied':[400,401].includes(error.status)?'backend_login_required':'backend_unavailable');
      }
    }
    async enroll(payload) {
      let portal; try { portal = new URL(this.config.portal); } catch (_) { throw new Error('portal_not_configured'); }
      if (portal.protocol !== 'https:' || portal.username || portal.password || portal.pathname !== '/' || portal.search || portal.hash) throw new Error('portal_not_configured');
      const controller = new AbortController(), timer = setTimeout(() => controller.abort(), 20000);
      try {
        const runtime = root.chrome?.runtime;
        const extension = /^[a-p]{32}$/.test(runtime?.id || '') && runtime.getURL?.('') === 'chrome-extension://' + runtime.id + '/';
        // Installed extensions call the same invitation service directly;
        // their origin must also be accepted by its server-side configuration.
        const endpoint = extension ? this.config.url + '/functions/v1/crowd-access/enroll' : portal.origin + '/api/crowd/enroll';
        const response = await this.fetcher(endpoint, {method: 'POST', credentials: 'omit', signal: controller.signal,
          headers: {'Content-Type': 'application/json', ...(extension ? {apikey: this.config.key} : {})},
          body: JSON.stringify(extension ? {...payload, client: 'extension', extension_id: runtime.id} : payload)});
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || 'backend_unavailable');
        return data;
      } finally { clearTimeout(timer); }
    }
    async session(signal, metrics = null, rejectedToken = null, binding = null) {
      const revision = binding?.revision ?? this.authRevision;
      if(binding && (revision!==this.authRevision || !binding.owner))throw new Error('cancelled');
      const readAt=metrics?clock():0;let s = await this.storage.get('session');
      if(metrics)metrics.session_read_ms=elapsed(readAt);
      if (signal?.aborted || revision !== this.authRevision || binding && s?.user?.id!==binding.owner) throw new Error('cancelled');
      if (!s?.refresh_token) throw Object.assign(new Error('backend_login_required'), {status: 401});
      if ((rejectedToken && s.access_token === rejectedToken) || !s.access_token || !Number.isFinite(s.expires_at) || s.expires_at < Date.now() + 60000) {
        // Status, collection and diagnostics share this API in the worker.
        // Refresh once; cancelling one caller must not consume the token and
        // lose the new session for all other callers.
        if (!this.refreshing || this.refreshing.revision !== revision) {
          const entry = {revision};
          entry.promise = (async () => {
            let next;
            try { next = await this.request('/auth/v1/token?grant_type=refresh_token', {refresh_token: s.refresh_token}); }
            catch (error) {
              if ([400,401].includes(error.status)) { error.message = 'backend_login_required'; error.status = 401; }
              throw error;
            }
            const current = await this.storage.get('session');
            if (revision !== this.authRevision || current?.refresh_token !== s.refresh_token) throw new Error('cancelled');
            if (!next.access_token || !next.refresh_token || !Number.isFinite(next.expires_in) || next.expires_in <= 0 ||
                (s.user?.id && next.user?.id !== s.user.id)) throw new Error('backend_unavailable');
            next = {...next, expires_at: Date.now() + next.expires_in * 1000};
            await this.saveSession(next, revision, async()=> (await this.storage.get('session'))?.refresh_token===s.refresh_token); return next;
          })().finally(() => { if (this.refreshing === entry) this.refreshing = null; });
          this.refreshing = entry;
        }
        const refreshAt=metrics?clock():0;try{s=await this.refreshing.promise;}finally{if(metrics)metrics.refresh_ms=elapsed(refreshAt);}
      }
      if (signal?.aborted || revision !== this.authRevision || binding && s?.user?.id!==binding.owner) throw new Error('cancelled');
      return s;
    }
    async rpc(name, params = {}, signal, metrics = null, binding = null) {
      const rpcAt=metrics?clock():0, revision=binding?.revision ?? this.authRevision;
      const checkBinding=s=>{
        if(binding && (revision!==this.authRevision || !binding.owner || s?.user?.id!==binding.owner || signal?.aborted))throw Error('cancelled');
      };
      if(binding && (revision!==this.authRevision || !binding.owner))throw Error('cancelled');
      try{
        const sessionAt=metrics?clock():0;let s;
        try{s=await this.session(signal,metrics,null,binding);}finally{if(metrics)metrics.session_ms=elapsed(sessionAt);}
        checkBinding(s);
        try { const result=await this.request('/rest/v1/rpc/crowd_v4_' + name,params,s.access_token,signal,metrics);checkBinding(s);return result; }
        catch (error) {
          checkBinding(s);
          // PostgREST rejected the JWT before entering the RPC. Only this
          // definitive pre-execution rejection permits one retry of a write.
          // A delayed rejection of an older token reuses an already refreshed
          // session; it must not rotate the new refresh token a second time.
          if (binding || error.status !== 401 || !['PGRST301','PGRST303'].includes(error.code)) throw error;
          if (revision !== this.authRevision) throw Error('cancelled');
          const owner = s.user?.id;
          s = await this.session(signal, metrics, s.access_token);
          if (revision !== this.authRevision || s.user?.id !== owner) throw Error('cancelled');
          return await this.request('/rest/v1/rpc/crowd_v4_' + name,params,s.access_token,signal,metrics);
        }
      }catch(error){if(error.status===401||error.message==='login_required')error.message='backend_login_required';else if(error.status===403)error.message='backend_permission_denied';throw error;}
      finally{if(metrics)metrics.rpc_ms=elapsed(rpcAt);}
    }
    async logout() {
      const revision=++this.authRevision;
      const s = await this.storage.get('session');
      await this.saveSession(null, revision);
      if (s) await this.request('/auth/v1/logout', {}, s.access_token);
    }
  }
  root.CrowdAPI = CrowdAPI;
})(globalThis);
