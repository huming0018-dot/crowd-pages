/* Fixed native protocol; no scripts/paths/URLs are accepted from a message. */
(function(root){
 'use strict';
 const NATIVE_ERRORS=new Set(["invalid_signature", "hash_mismatch", "permission_change", "replayed_release", "recovery_required", "handshake_mismatch", "version_mismatch", "busy", "invalid_manifest", "invalid_package", "unsafe_archive", "too_large", "invalid_url", "wrong_extension", "operation_failed", "lock_failed", "swap_failed", "process_check_failed", "ota_network_dns", "ota_network_connect", "ota_network_timeout", "ota_network_tls", "ota_network_http", "ota_network_transfer", "ota_io_permission", "ota_io_missing", "ota_io_space", "ota_io_failed", "ota_package_tool_failed", "ota_service_failed", "ota_process_terminated", "ota_process_launch_failed", "ota_unknown_exit"]);
 const OTA_ERRORS=new Set(["ota_network_dns", "ota_network_connect", "ota_network_timeout", "ota_network_tls", "ota_network_http", "ota_network_transfer", "ota_io_permission", "ota_io_missing", "ota_io_space", "ota_io_failed", "ota_package_tool_failed", "ota_service_failed", "ota_process_terminated", "ota_process_launch_failed", "ota_unknown_exit", "ota_signature_invalid", "ota_hash_mismatch", "ota_permission_change", "ota_replayed_release", "ota_recovery_required", "ota_handshake_mismatch", "ota_version_mismatch", "ota_busy", "ota_invalid_package", "ota_invalid_url", "ota_wrong_extension", "ota_unknown", "ota_io_failed"]);
 const OTA_ERROR_MAP={"invalid_signature": "ota_signature_invalid", "hash_mismatch": "ota_hash_mismatch", "permission_change": "ota_permission_change", "replayed_release": "ota_replayed_release", "recovery_required": "ota_recovery_required", "handshake_mismatch": "ota_handshake_mismatch", "version_mismatch": "ota_version_mismatch", "busy": "ota_busy", "invalid_manifest": "ota_invalid_package", "invalid_package": "ota_invalid_package", "unsafe_archive": "ota_invalid_package", "too_large": "ota_invalid_package", "invalid_url": "ota_invalid_url", "wrong_extension": "ota_wrong_extension", "operation_failed": "ota_unknown", "lock_failed": "ota_io_failed", "swap_failed": "ota_io_failed", "process_check_failed": "ota_unknown"};
 const safeNativeError=value=>NATIVE_ERRORS.has(value)?value:'update_failed';
 const otaError=value=>OTA_ERRORS.has(value)?value:(typeof value==='string'&&Object.hasOwn(OTA_ERROR_MAP,value)?OTA_ERROR_MAP[value]:'ota_unknown');
 class CrowdUpdater {
  constructor({chrome,storage,agent,version,releaseHash,isBusy=()=>false,reportOTA=async()=>false,beforeApply=async()=>{},beforeReload=async()=>{},afterReload=async()=>{}}) {Object.assign(this,{chrome,storage,agent,version,releaseHash,isBusy,reportOTA,beforeApply,beforeReload,afterReload});this.active=null;this.updatePeriod=60;}
  async telemetry(status,error=null) {
   // Diagnostics failure cannot change signed update or restart behavior.
   try {return await this.reportOTA({status,error_code:status==='failed'?otaError(error):null});}catch(_){return false;}
  }
  async applied(r) {
   try {
    if(r.status!=='applied'||r.version!==this.version)return;
    if(await this.storage.get('updater_telemetry_applied')===this.version)return;
    if(await this.telemetry('completed'))await this.storage.set('updater_telemetry_applied',this.version);
   }catch(_){}
  }
  async send(action, extra={}) {
   const message={action,version:this.version,...extra};if(action==='ack')message.release_sha256=await this.releaseHash();
   const host='com.crowd.v4.updater';
   let result;try{result=await this.chrome.runtime.sendNativeMessage(host,message);}catch(_){throw Error('helper_unavailable');}
   if(!result || typeof result.status!=='string')throw Error('invalid_response');
   if(result.status==='error')throw Error(safeNativeError(result.error));
   return result;
  }
  async lightOCR(data, signal, operation) {return this.lightMedia('light_ocr','image/png',data,signal,operation);}
  async lightASR(data, signal, operation) {return this.lightMedia('light_asr','audio/wav',data,signal,operation);}
  async lightBarrier() {
   let timeout;
   try{const value=await Promise.race([this.chrome.runtime.sendNativeMessage('com.crowd.v4.updater',{action:'light_barrier',version:this.version}),new Promise((_,reject)=>{timeout=setTimeout(()=>reject(Error('native_stop_unknown')),2000);})]);if(value?.status!=='settled')throw Error('native_stop_unknown');}
   catch(_){throw Error('native_stop_unknown');}finally{clearTimeout(timeout);}
  }
  async lightMedia(action, mime, data, signal, operationId) {
   if(typeof data!=='string'||!data||data.length>700000||!/^[A-Za-z0-9+/]+={0,2}$/.test(data))throw Error('invalid_image');
   if(signal?.aborted)throw Error('cancelled');
   const operation=operationId||crypto.randomUUID();
   if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(operation))throw Error('invalid_operation');
   return await new Promise((resolve,reject)=>{
    let port,settled=false,timer,stopTimer,cancelling=false,checking=false,cancelAcknowledged=false,cancelReason='cancelled';
    const finish=(error,value)=>{if(settled)return;settled=true;clearTimeout(timer);clearTimeout(stopTimer);signal?.removeEventListener('abort',abort);try{port?.disconnect();}catch(_){}error?reject(Error(error)):resolve(value);};
    const checkStopped=async()=>{if(checking||settled)return;checking=true;for(let i=0;i<20;i++){
     try{const value=await Promise.race([this.chrome.runtime.sendNativeMessage('com.crowd.v4.updater',{action:'light_barrier',version:this.version}),new Promise((_,reject)=>setTimeout(()=>reject(Error('barrier_timeout')),2000))]);if(value?.status==='settled')return finish(cancelReason);if(value?.error!=='busy')return finish('native_stop_unknown');}
     catch(_){return finish('native_stop_unknown');}
     await new Promise(resolve=>setTimeout(resolve,250));
    }finish('native_stop_unknown');};
    const cancel=(reason)=>{if(cancelling||settled)return;cancelReason=reason;cancelling=true;clearTimeout(timer);try{port.postMessage({action:'light_cancel',operation_id:operation});}catch(_){return finish('native_stop_unknown');}stopTimer=setTimeout(()=>finish('native_stop_unknown'),5000);};
    const abort=()=>cancel('cancelled');
    try{port=this.chrome.runtime.connectNative('com.crowd.v4.updater');
     port.onMessage.addListener(value=>{
      if(cancelling){if(value?.status==='cancelled'&&value.operation_id===operation)cancelAcknowledged=true;return;}
      const isSpeech=action==='light_asr';
      if(value?.status==='error'&&value.error==='busy')return finish(isSpeech?'local_asr_busy':'local_ocr_busy');
      if(value?.status==='error'&&value.error==='version_mismatch')return finish('helper_version_mismatch');
      if(value?.status==='error'&&isSpeech&&['speech_permission_required','speech_model_unavailable','invalid_audio','speech_empty','speech_recognition_failed','speech_timeout'].includes(value.error))return finish(value.error);
      if(value?.status!=='completed'||value.processor!==(isSpeech?'apple_speech_ondevice':'apple_vision_local')||typeof value.text!=='string'||value.text.length>8000||typeof value.truncated!=='boolean')return finish(isSpeech?'local_asr_failed':'local_ocr_failed');
      if(isSpeech&&(!Array.isArray(value.segments)||value.segments.length>100||value.segments.some(row=>!row||!Number.isFinite(row.start)||!Number.isFinite(row.end)||row.start<0||row.end<=row.start||row.end>60||typeof row.text!=='string'||row.text.length>2000)))return finish('local_asr_failed');
      finish(null,{processor:value.processor,text:value.text,truncated:value.truncated,...(isSpeech?{segments:value.segments}: {})});
     });
     port.onDisconnect.addListener(()=>{if(cancelling){if(cancelAcknowledged)checkStopped();else finish('native_stop_unknown');return;}finish(action==='light_asr'?'local_asr_unavailable':'local_ocr_unavailable');});
     signal?.addEventListener('abort',abort,{once:true});if(signal?.aborted)return abort();
     timer=setTimeout(()=>cancel(action==='light_asr'?'local_asr_timeout':'local_ocr_timeout'),120000);
     port.postMessage({action,version:this.version,mime,data,operation_id:operation});
    }catch(_){finish(action==='light_asr'?'local_asr_unavailable':'local_ocr_unavailable');}
   });
  }
  async status() {
   const saved=await this.storage.get('updater_status')||{};
   let poll=await this.storage.get('updater_poll')||{};
   if(this.chrome.runtime.sendNativeMessage && !this.active && (!this.pollAt || Date.now()-this.pollAt>=60000)){
    this.pollAt=Date.now();
    try{const r=await this.send('status');
     if(poll.poll_status!==r.poll_status || (r.poll_status==='error' && poll.poll_error!==safeNativeError(r.poll_error))){
      if(r.poll_status==='error')await this.telemetry('failed',r.poll_error);
      else if(['downloaded','pending_reload'].includes(r.poll_status))await this.telemetry('waiting');
     }
     poll={};
     if(Number.isFinite(r.last_poll_at)&&r.last_poll_at>0&&r.last_poll_at<=Date.now()/1000+60)poll.last_poll_at=r.last_poll_at;
     if(['current','downloaded','pending_reload','error'].includes(r.poll_status))poll.poll_status=r.poll_status;
     if(typeof r.poll_error==='string')poll.poll_error=safeNativeError(r.poll_error);
     await this.storage.set('updater_poll',poll);
    }catch(e){poll={...poll,poll_query_error:['busy','invalid_response'].includes(e.message)?e.message:'helper_unavailable'};await this.storage.set('updater_poll',poll);}
   }
   return {system_ota:await this.storage.get('updater_protocol')===2,enabled:await this.storage.get('updater_enabled')!==false,...saved,...poll,poll_stale:await this.storage.get('updater_enabled')!==false&&Number.isFinite(poll.last_poll_at)&&Date.now()/1000-poll.last_poll_at>7200,busy:!!this.active};
  }
  serializePreferences(work) {
   const next=(this.preferenceTail||Promise.resolve()).catch(()=>{}).then(work);
   this.preferenceTail=next;return next;
  }
  async setEnabled(enabled) {
   if(typeof enabled!=='boolean')throw Error('invalid_request');
   if(this.active)throw Error('update_in_progress');
   return this.serializePreferences(async()=>{
    if(await this.isBusy())throw Error('executor_busy');
    if(await this.storage.get('updater_protocol')===2)await this.send('settings',{enabled});
    await this.storage.set('updater_enabled',enabled);
    if(enabled)await this.initialize();else {await this.chrome.alarms.clear('crowd_update');await this.chrome.alarms.clear('crowd_update_bootstrap');}
   });
  }
  async recoverMismatch(error) {
   if(!['version_mismatch','handshake_mismatch'].includes(error))return false;
   try {const r=await this.send('status');if(['rolled_back','pending_reload'].includes(r.status)&&/^4\.\d+\.\d+$/.test(r.version)&&r.version!==this.version){await this.telemetry(r.status==='rolled_back'?'failed':'waiting');await this.reloadSettled(r.version);return true;}}catch(_){}
   return false;
  }
  async reloadSettled(target) {
   // Stop remains available during updates; persist it before replacing the worker.
   const settle=async()=>{
    for(;;){
     if(this.agent.updateStopFailed)throw Error('executor_busy');
     const stop=this.agent.pendingStop||this.agent.stopActive,write=this.agent.writeTail;
     try {await stop;await write;}catch(_){throw Error('executor_busy');}
     if(this.agent.updateStopFailed)throw Error('executor_busy');
     if(!this.agent.pendingStop && !this.agent.stopActive && write===this.agent.writeTail)break;
    }
   };
   await settle();
   // Let Chrome observe the settled Native-swapped files before reloading.
   if(typeof root.setTimeout==='function')await new Promise(resolve=>root.setTimeout(resolve,2000));
   await settle();
   try{await this.beforeReload(target);}catch(error){if(error.message==='executor_busy')await this.chrome.alarms.create('crowd_update',{delayInMinutes:1,periodInMinutes:this.updatePeriod});throw error;}
   this.chrome.runtime.reload();
  }
  async bootstrap() {
   if(this.bootstrapping)return this.bootstrapping;
   this.bootstrapping=this.serializePreferences(()=>this.initialize()).finally(()=>{this.bootstrapping=null;});return this.bootstrapping;
  }
  async initialize() {
   if(!this.chrome.runtime.sendNativeMessage)return;
   await this.storage.set('local_update_verified',null);
   await this.storage.set('local_updater_ready',null);
   try {
    const r=await this.send('ack');
    if(r.status==='pending_reload'&&r.version!==this.version){await this.telemetry('waiting');await this.reloadSettled(r.version);return;}
    if(r.status==='applied'&&r.version===this.version)await this.afterReload();
    await this.applied(r);
    await this.storage.set('updater_protocol',r.protocol===2?2:1);
    if(r.protocol===2)await this.send('settings',{enabled:await this.storage.get('updater_enabled')!==false});
    await this.storage.set('updater_status',{state:r.status,version:this.version,checked_at:Date.now()});
    await this.chrome.alarms.clear('crowd_update_bootstrap');
    if(await this.storage.get('updater_enabled')!==false){
     const alarm=await this.chrome.alarms.get('crowd_update');
     if(!alarm || alarm.periodInMinutes!==this.updatePeriod)await this.chrome.alarms.create('crowd_update',{delayInMinutes:1,periodInMinutes:this.updatePeriod});
    }
   }catch(e){if(!await this.recoverMismatch(e.message)){
    await this.telemetry(['busy','executor_busy'].includes(e.message)?'waiting':'failed',e.message);
    await this.storage.set('local_update_verified',null);
    await this.storage.set('local_updater_ready',null);
    await this.storage.set('updater_status',{state:['busy','executor_busy'].includes(e.message)?'checking':'helper_unavailable',error:e.message,version:this.version});
    if(await this.storage.get('updater_enabled')!==false)await this.chrome.alarms.create('crowd_update_bootstrap',{delayInMinutes:1,periodInMinutes:1});
    if(['busy','executor_busy'].includes(e.message))await this.chrome.alarms.create('crowd_update',{delayInMinutes:1,periodInMinutes:this.updatePeriod});
   }}
  }
  async check() {
   if(this.active)return this.active;
   this.active=this.serializePreferences(()=>this.perform()).finally(()=>{this.active=null;this.agent.maintenance=false;});return this.active;
  }
  async perform() {
   const blocked=async error=>{if(error!=='update_disabled')await this.telemetry(error==='executor_busy'?'waiting':'failed');await this.storage.set('updater_status',{state:'error',error,version:this.version,checked_at:Date.now()});return {blocked:error};};
   if(await this.storage.get('updater_enabled')===false)return blocked('update_disabled');
   if(!this.chrome.runtime.sendNativeMessage)return blocked('helper_unavailable');
   if(await this.isBusy()){await this.chrome.alarms.create('crowd_update',{delayInMinutes:1,periodInMinutes:this.updatePeriod});return blocked('executor_busy');}
   this.agent.maintenance=true;
   await this.agent.active?.catch(()=>{});
   await this.agent.writeTail?.catch(()=>{});
   if(await this.isBusy()){await this.chrome.alarms.create('crowd_update',{delayInMinutes:1,periodInMinutes:this.updatePeriod});return blocked('executor_busy');}
   try {
    await this.storage.set('updater_status',{state:'checking',version:this.version,checked_at:Date.now()});
    await this.telemetry('started');
    await this.beforeApply();
    const r=await this.send('apply');
    await this.storage.set('updater_status',{state:r.status,version:this.version,target:r.version,checked_at:Date.now()});
    if(r.status==='current'&&r.version===this.version)await this.telemetry('skipped');
    if(r.status==='pending_reload') {
     await this.telemetry('waiting');
     // Evidence/session/consent/stop state stay in extension storage. Reload self only.
     await this.reloadSettled(r.version);
    }
   }catch(e){if(!await this.recoverMismatch(e.message)){
    await this.telemetry(['busy','executor_busy'].includes(e.message)?'waiting':'failed',e.message);
    await this.storage.set('updater_status',{state:'error',error:e.message,version:this.version,checked_at:Date.now()});
    // The OS poll may briefly own the host lock. Do not collide again at the
    // same hourly boundary or postpone a prepared update for another hour.
    if(['busy','executor_busy'].includes(e.message))await this.chrome.alarms.create('crowd_update',{delayInMinutes:1,periodInMinutes:this.updatePeriod});
   }}
  }
 }
 root.CrowdUpdater=CrowdUpdater;
})(globalThis);
