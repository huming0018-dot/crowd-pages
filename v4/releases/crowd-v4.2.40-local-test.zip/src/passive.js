/* Fixed passive observer. The website's CSP can refuse it; no nonce/CSP bypass. */
(function(root){
 'use strict';
 function pageObserver() {
  'use strict';
  const marker=new URL(location.href).searchParams.get('crowd_capture'),id=location.pathname.match(/^\/(?:explore|discovery\/item|search_result)\/([a-f0-9]{24})\/?$/i)?.[1]?.toLowerCase();
  if(window.top!==window || !id || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(marker||''))return;
  const emit=data=>{if(location.pathname.match(/^\/(?:explore|discovery\/item|search_result)\/([a-f0-9]{24})\/?$/i)?.[1]?.toLowerCase()===id)window.postMessage({type:'crowd_public_response_v1',nonce:marker,note_id:id,...data},location.origin);};
  const descriptor=(value,method)=>{
   try{
    const u=new URL(value,location.href);if(method!=='GET'||u.protocol!=='https:'||u.hostname!=='edith.xiaohongshu.com'||u.username||u.password||u.port||u.searchParams.get('note_id')!==id)return null;
    const kind=u.pathname==='/api/sns/web/v2/comment/page'?'main':u.pathname==='/api/sns/web/v2/comment/sub/page'?'reply':null;
    if(!kind)return null;const cursor=u.searchParams.get('cursor')||'',parent=kind==='reply'?u.searchParams.get('root_comment_id'):null;
    if(cursor.length>100 || kind==='reply'&&!/^[a-f0-9]{24}$/.test(parent||''))return null;
    return {kind,input_cursor:cursor,root_id:parent};
   }catch(_){return null;}
  };
  const item=(c,withReplies=false)=>{
   if(!c||c.note_id!==id||typeof c.content!=='string')throw Error('wrong_note');
   const v={id:c.id,note_id:c.note_id,content:c.content,author_id:c.user_info?.user_id||null,author_display:c.user_info?.nickname||null,
    like_count:c.like_count??null,create_time:c.create_time??null,target_comment_id:c.target_comment?.id||null,
    pictures:(c.pictures||[]).map(p=>{const u=new URL(p.url_default);if(!['http:','https:'].includes(u.protocol)||u.hostname!=='sns-webpic-qc.xhscdn.com'||u.username||u.password||u.port||u.search||u.hash||!/^\/[^\s?#]+\/comment(?:_uhdr)?\/[a-zA-Z0-9_-]+![a-zA-Z0-9_-]+$/.test(u.pathname))throw Error('invalid_picture');return {url_default:p.url_default,width:p.width,height:p.height};})};
   if(withReplies)Object.assign(v,{sub_comment_count:c.sub_comment_count,sub_comment_has_more:c.sub_comment_has_more,sub_comment_cursor:c.sub_comment_cursor,sub_comments:(c.sub_comments||[]).map(r=>item(r))});
   return v;
  };
  const deliver=(meta,value,status)=>{
   if(!meta)return;
   if(status===429 || ['300011','300012','300013'].includes(String(value?.code))){emit({gate:'rate_limit'});return;}
   if(status===461||status===471){emit({gate:'captcha'});return;}
   if(status!==200||value?.success!==true){emit({error:'response_failed'});return;}
   try{
    const d=value.data;if(!d||!Array.isArray(d.comments)||d.comments.length>50||typeof d.cursor!=='string'||typeof d.has_more!=='boolean')throw Error('invalid_page');
    const page={cursor:d.cursor,has_more:d.has_more,comments:d.comments.map(c=>item(c,meta.kind==='main'))};
    if(JSON.stringify(page).length>1000000)throw Error('page_budget');
    emit({page:{...meta,data:page}});
   }catch(_){emit({error:'invalid_page'});}
  };
  const originalFetch=window.fetch;
  if(typeof originalFetch==='function')window.fetch=function(...args){
   // Read only the public URL/method; never request headers/body/cookies.
   const meta=descriptor(typeof args[0]==='string'?args[0]:args[0]?.url,String(args[1]?.method||args[0]?.method||'GET').toUpperCase());
   const result=originalFetch.apply(this,args);
   if(meta)result.then(response=>{const size=Number(response.headers.get('content-length')||0);if(size>1000000){emit({error:'page_budget'});return;}
    response.clone().text().then(text=>{if(text.length>1000000){emit({error:'page_budget'});return;}try{deliver(meta,JSON.parse(text),response.status);}catch(_){emit({error:'response_failed'});}}).catch(()=>emit({error:'response_failed'}));
   }).catch(()=>{});
   return result;
  };
  if(typeof XMLHttpRequest==='function'){
   const savedOpen=XMLHttpRequest.prototype.open,savedSend=XMLHttpRequest.prototype.send,metadata=new WeakMap();
   XMLHttpRequest.prototype.open=function(method,url,...rest){metadata.set(this,descriptor(url,String(method).toUpperCase()));return savedOpen.call(this,method,url,...rest);};
   XMLHttpRequest.prototype.send=function(...args){const meta=metadata.get(this);
    if(meta)this.addEventListener('load',()=>{try{const value=this.responseType==='json'?this.response:JSON.parse(this.responseText);if(JSON.stringify(value).length<=1000000)deliver(meta,value,this.status);else emit({error:'page_budget'});}catch(_){emit({error:'response_failed'});}}, {once:true});
    return savedSend.apply(this,args);
   };
  }
  emit({installed:true});
 }
 root.CrowdPassive={pageObserver};
})(globalThis);
