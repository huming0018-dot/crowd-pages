/* Whitelisted public page observations, never credentials or executable page data. */
(function(root){
'use strict';

// Parse data literals, never evaluate a webpage's executable JavaScript.
function structuredBody(script,noteId) {
 const prefix='window.__INITIAL_STATE__=';
 if(typeof script!=='string'||script.length>2000000||!script.startsWith(prefix)||! /^[a-f0-9]{24}$/.test(noteId))throw Error('invalid_hydration');
 const input=script.slice(prefix.length).replace(/;\s*$/,''), boundary=c=>!c||!/[A-Za-z0-9_$]/.test(c);
 let out='',quoted=false,escaped=false;
 for(let i=0;i<input.length;i++){
  const c=input[i];
  if(quoted){out+=c;if(escaped)escaped=false;else if(c==='\\')escaped=true;else if(c==='"')quoted=false;}
  else if(c==='"'){quoted=true;out+=c;}
  else if(input.slice(i,i+9)==='undefined'&&boundary(input[i-1])&&boundary(input[i+9])){out+='null';i+=8;}
  else if(input.slice(i,i+11)==='new Map([])'&&boundary(input[i-1])&&boundary(input[i+11])){out+='{}';i+=10;}
  else out+=c;
 }
 const note=JSON.parse(out).note?.noteDetailMap?.[noteId]?.note;
 if(!note||note.noteId!==noteId||typeof note.title!=='string'||typeof note.desc!=='string'||note.title.length>300||note.desc.length>24000)throw Error('missing_or_wrong_note');
 return {source:'page_hydration',note_id:noteId,title:note.title,text:note.desc,original_length:note.desc.length,truncated:false};
}


// Independent implementation: normal-page response observations, never DOM evidence.
// No request signing, credentials, network calls, or silent retry in this module.
class StructuredPages {
 constructor(note) {this.note=note;this.items=new Map();this.roots=new Map();this.pages=new Map();this.main={cursor:'',ended:false};this.failures=[];this.bytes=0;}
 accept(kind,inputCursor,data,root=null) {
  if(!['main','reply'].includes(kind)||typeof inputCursor!=='string'||!data||typeof data.cursor!=='string'||typeof data.has_more!=='boolean'||!Array.isArray(data.comments))throw Error('invalid_page');
  if(kind==='reply'&&!this.roots.has(root))throw Error('unknown_parent');
  const state=kind==='main'?this.main:this.roots.get(root),key=kind+':'+(root||'')+':'+inputCursor;
  if(inputCursor.length>100 || data.cursor.length>100 || data.comments.length>50)throw Error('page_budget');
  const payload=JSON.stringify(data);if(payload.length>1000000)throw Error('page_budget');
  if(this.pages.has(key)){if(this.pages.get(key)!==payload)throw Error('page_conflict');return;}
  if(this.pages.size>=250||this.bytes+new TextEncoder().encode(payload).length>1500000)throw Error('page_budget');
  if(state.ended||state.cursor!==inputCursor)throw Error('cursor_out_of_order');
  if(data.has_more&&(!data.cursor||data.cursor===inputCursor))throw Error('cursor_stalled');
  const next=[],pendingRoots=new Map();
  const add=(item,parent)=>{
   if(!item||typeof item.id!=='string'||! /^[a-f0-9]{24}$/.test(item.id)||item.note_id!==this.note||typeof item.content!=='string'||item.content.length>24000)throw Error('wrong_note_or_item');
   const pictures=item.pictures===undefined?[]:item.pictures;
   if(!Array.isArray(pictures)||pictures.some(p=>{try{const u=new URL(p.url_default);return !['http:','https:'].includes(u.protocol)||u.hostname!=='sns-webpic-qc.xhscdn.com'||u.port||u.username||u.password||u.search||u.hash||!/\/comment(?:_uhdr)?\//.test(u.pathname)||!Number.isInteger(p.width)||!Number.isInteger(p.height)||p.width<=0||p.height<=0||p.width>100000||p.height>100000;}catch(_){return true;}}))throw Error('invalid_pictures');
   const authorId=item.author_id??null,targetId=item.target_comment_id??null,author=item.author_display??null;
   if([authorId,targetId].some(id=>id!==null&&(typeof id!=='string'||!/^[a-f0-9]{24}$/.test(id))) || author!==null&&(typeof author!=='string'||author.length>100))throw Error('invalid_comment_metadata');
   const likes=item.like_count??null,time=item.create_time??null;
   if(likes!==null&&(!/^[0-9]+$/.test(String(likes))||!Number.isSafeInteger(Number(likes))||Number(likes)<0) || time!==null&&(!Number.isSafeInteger(time)||time<0))throw Error('invalid_comment_metadata');
   const record={id:item.id,parent,text:item.content,pictures,author_id:authorId,author_display:author,like_count:likes===null?null:Number(likes),create_time:time,reply_target_id:targetId,source:'page_response'};
   const existing=this.items.get(item.id)||next.find(v=>v.id===item.id);
   if(existing&&(existing.parent!==parent||existing.text!==record.text||existing.author_id!==record.author_id||existing.reply_target_id!==record.reply_target_id))throw Error('item_conflict');
   next.push(record);
  };
  for(const item of data.comments){
   add(item,root);
   if(kind==='main'){
    const count=Number(item.sub_comment_count);
    if(!Number.isSafeInteger(count)||count<0||count>10000||typeof item.sub_comment_has_more!=='boolean'||typeof item.sub_comment_cursor!=='string'||!Array.isArray(item.sub_comments))throw Error('invalid_reply_state');
    const snapshot=JSON.stringify([count,item.sub_comment_has_more,item.sub_comment_cursor]);
    if((this.roots.has(item.id)&&this.roots.get(item.id).snapshot!==snapshot)||(pendingRoots.has(item.id)&&pendingRoots.get(item.id)!==snapshot))throw Error('root_metadata_conflict');
    pendingRoots.set(item.id,snapshot);
    for(const reply of item.sub_comments)add(reply,item.id);
   }
  }
  if(new Set([...this.items.keys(),...next.map(v=>v.id)]).size>2000)throw Error('page_budget');
  // Commit a whole validated page; malformed rows cannot advance a cursor.
  for(const record of next)this.items.set(record.id,record);
  if(kind==='main')for(const item of data.comments){
   const previous=this.roots.get(item.id);
   if(!previous)this.roots.set(item.id,{cursor:item.sub_comment_cursor,ended:!item.sub_comment_has_more,declared:Number(item.sub_comment_count),snapshot:JSON.stringify([Number(item.sub_comment_count),item.sub_comment_has_more,item.sub_comment_cursor])});
  }
  state.cursor=data.cursor;state.ended=!data.has_more;this.pages.set(key,payload);this.bytes+=new TextEncoder().encode(payload).length;
 }
 summary(){
  const counts=new Map();let replies=0,images=0;
  for(const item of this.items.values()){
   if(item.parent!==null){replies++;counts.set(item.parent,(counts.get(item.parent)||0)+1);}
   images+=item.pictures.length;
  }
  const groups=[...this.roots].map(([id,s])=>({id,declared:s.declared,captured:counts.get(id)||0,ended:s.ended}));
  return {source:'page_response',roots:this.roots.size,replies,images,main_ended:this.main.ended,groups,complete:this.main.ended&&groups.every(g=>g.ended&&g.captured===g.declared)&&!this.failures.length};
 }
}


root.CrowdStructured={structuredBody,StructuredPages};
})(globalThis);

(function(root){
'use strict';
// Fixed cached public comment client; source commands remain backend-admitted and document-bound.
function createSitePager({window,document,enabled=false,binding,current,graph,admit,responseReady,now=Date.now}){
 let revoked=false,busy=false,sdk=null,captured=false,context=null;const used=new Set();
 const same=()=>{const c=current();if(!c||['owner','note','document','nonce','generation','test','lease'].some(k=>c[k]!==binding[k])||c.stopped||c.risk)revoked=true;return !revoked;};
 const frontier=(kind,root)=>{const g=kind==='main'?graph.main:graph.roots.get(root);return !g||g.ended?null:g.cursor;};
 const capture=()=>{
  if(captured)return sdk;captured=true;
  const base='https://fe-static.xhscdn.com/formula-static/xhs-pc-web/public/resource/js/';
  const required=['vendor-dynamic.8866efa7.js','index.6613bd4c.js','bundler-runtime.1200f52d.js'];
  if(!required.every(name=>Array.from(document?.scripts||[]).some(s=>s.src===base+name)))return null;
  const chunks=Object.getOwnPropertyDescriptor(window,'webpackChunkxhs_pc_web')?.value;
  if(!Array.isArray(chunks)||typeof chunks.push!=='function')return null;
  // One fixed cache lookup. Never require/initialize a module, enumerate it, or inject source factories.
  chunks.push([['crowd_public_comment_sdk_capture_v1'],{},require=>{
   const entry=Object.getOwnPropertyDescriptor(require.c||{},'25717')?.value;
   if(entry?.loaded!==true||!entry.exports)return;
   const main=entry.exports.S9,reply=entry.exports.z1;
   if(typeof main==='function'&&typeof reply==='function')sdk={main,reply};
  }]);return sdk;
 };
 return {
  available(){return enabled&&same()&&!!context&&now()>=context.at&&now()-context.at<=30000&&!!capture();},
  acceptedResponse(){if(context&&same())context.at=now();},
  observe(url,method='GET'){
   if(!enabled||!same()||method!=='GET')return false;
   try{const u=new URL(url);if(u.origin!=='https://edith.xiaohongshu.com'||u.pathname!=='/api/sns/web/v2/comment/page'||u.hash||u.username||u.password||u.searchParams.get('note_id')!==binding.note)return false;
    const allowed=['note_id','cursor','top_comment_id','image_formats','xsec_token'];if([...u.searchParams.keys()].some(k=>!allowed.includes(k))||allowed.some(k=>u.searchParams.getAll(k).length>1))return false;
    const image=u.searchParams.get('image_formats')||'',top=u.searchParams.get('top_comment_id')||'',token=u.searchParams.get('xsec_token')||'';
    if(image.length>100||top.length>100||token.length>2048)return false;
    context={image,top,token,at:now()};return true;
   }catch(_){return false;}
  },
  async next({kind,root=null,cursor}){
   if(!enabled||busy||!same())throw Error('disabled_or_busy');
   if(!['main','reply'].includes(kind)||frontier(kind,root)===null||frontier(kind,root)!==cursor||!context||now()-context.at>30000||now()<context.at){const e=Error('scope_or_context');e.notSent=true;throw e;}
   if(kind==='reply'&&!/^[a-f0-9]{24}$/.test(root||''))throw Error('root');busy=true;let sent=false;
   try{
    const grant=await admit({kind,root,cursor});if(!same()||grant?.allowed!==true||typeof grant.id!=='string'||used.has(grant.id)||!Number.isFinite(grant.expires)||grant.expires>now()+10000||['owner','note','document','nonce','generation','test','lease'].some(k=>grant[k]!==binding[k])||grant.kind!==kind||grant.root!==root||grant.cursor!==cursor)throw Error('grant');
    used.add(grant.id);if(grant.expires<=now()){const e=Error('expired_before_send');e.notSent=true;throw e;}if(frontier(kind,root)!==cursor)throw Error('cursor_changed');
    const transport=capture();if(!transport)throw Error('loaded_sdk_missing');
    if(!same()||grant.expires<=now()||frontier(kind,root)!==cursor||now()-context.at>30000)throw Error('revoked_or_expired');
    const params={noteId:binding.note,cursor,topCommentId:context.top,imageFormats:context.image,xsecToken:context.token};if(kind==='reply'){params.rootCommentId=root;params.num=10;}
    // The site's existing configured client owns serialization, signing, SSK, Mns, Sc-T and credentials.
    sent=true;await transport[kind]({params});
    if(!same())throw Error('revoked');
    // Do not treat the transformed SDK return as DOM/API evidence. The existing observer must accept its raw response.
    await responseReady({kind,root,cursor});
    if(!same()||frontier(kind,root)===cursor)throw Error('observer_response_missing');return {accepted:true};
   }catch(e){e.notSent=!sent&&['expired_before_send','cursor_changed','revoked_or_expired'].includes(e.message);if(!e.notSent)revoked=true;throw e;}finally{busy=false;}
  }
 };
}
root.CrowdSiteSDK={createSitePager};
})(globalThis);

/* Fixed packaged MAIN observer; no dynamic scripts, extra requests or CSP changes. */
(function(root){
 'use strict';
 function pageObserver() {
  'use strict';
  const marker=new URL(location.href).searchParams.get('crowd_capture'),id=location.pathname.match(/^\/(?:explore|discovery\/item|search_result)\/([a-f0-9]{24})\/?$/i)?.[1]?.toLowerCase();
  if(window.top!==window || !id || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(marker||''))return;
  const sdkGraph=new root.CrowdStructured.StructuredPages(id);let sdkBinding=null,sdkPager=null,sdkContextURL=null,sdkGrant=null,sdkOperation=null,pendingReads=0;
  let bridgeReady=false,pendingBytes=0,overflow=false,pendingGate=null;
  const pending=[];
  const counts={fetch_calls:0,xhr_calls:0,matched_requests:0,responses:0,parse_failures:0,wrong_note:0,invalid_picture:0,invalid_page:0,page_budget:0,response_failed:0};
  let fetchHook=null,xhrOpenHook=null,xhrSendHook=null;
  const count=key=>{counts[key]=Math.min(10000,counts[key]+1);};
  const diagnostics=()=>({...counts,fetch_hook_current:fetchHook!==null&&window.fetch===fetchHook,xhr_hook_current:xhrOpenHook!==null&&typeof XMLHttpRequest==='function'&&!!XMLHttpRequest.prototype&&XMLHttpRequest.prototype.open===xhrOpenHook&&XMLHttpRequest.prototype.send===xhrSendHook});
  let revoked=false;
  const current=()=>{
   const url=new URL(location.href),noteNow=location.pathname.match(/^\/(?:explore|discovery\/item|search_result)\/([a-f0-9]{24})\/?$/i)?.[1]?.toLowerCase(),markerNow=url.searchParams.get('crowd_capture');
   if(!revoked&&(noteNow!==id || markerNow!==null&&markerNow!==marker)){revoked=true;window.postMessage({type:'crowd_public_response_v1',nonce:marker,note_id:id,revoked:true},location.origin);}
   return !revoked;
  };
  // Same-document SPA cleanup may remove the marker; another owner/note revokes permanently.
  if(window.history)for(const key of ['pushState','replaceState']){const original=window.history[key];if(typeof original==='function')window.history[key]=function(...args){const result=original.apply(this,args);current();return result;};}
  window.addEventListener('popstate',current);
  const sdkCurrent=()=>sdkBinding&&current()?{...sdkBinding,stopped:false,risk:pendingGate}:null;
  const send=data=>{if(current())window.postMessage({type:'crowd_public_response_v1',nonce:marker,note_id:id,...data},location.origin);};
  const emit=data=>{
   if(!current())return;if(data.gate)pendingGate=data.gate;
   if(bridgeReady){send(data);return;}
   if(data.gate){pendingGate=data.gate;return;}
   const bytes=JSON.stringify(data).length;
   if(pending.length<4&&pendingBytes+bytes<=1000000){pending.push(data);pendingBytes+=bytes;}else overflow=true;
  };
  window.addEventListener('message',event=>{
   const m=event.data;
   if(event.source!==window||event.origin!==location.origin||m?.type!=='crowd_public_ready_v1'||m.nonce!==marker||m.note_id!==id||!current())return;
   bridgeReady=true;send({installed:true,diagnostics:diagnostics()});
   if(m.sdk && root.CrowdSiteSDK){
    const q=m.sdk,b=q.binding;
    if(!b||b.note!==id||b.nonce!==marker||!b.document||!b.owner||!b.test||!/^[a-f0-9]{64}$/.test(b.lease||'')||!Number.isInteger(b.generation))return;
    if(sdkBinding&&['owner','note','document','nonce','generation','test','lease'].some(k=>sdkBinding[k]!==b[k])){revoked=true;return;}
    if(!sdkBinding){sdkBinding={...b};sdkPager=root.CrowdSiteSDK.createSitePager({window,document,enabled:true,binding:sdkBinding,current:sdkCurrent,graph:sdkGraph,
     admit:async()=>sdkGrant,responseReady:async()=>{for(let i=0;i<20;i++){await new Promise(r=>setTimeout(r,50));if(sdkGraph.pages.has(sdkOperation.kind+':'+(sdkOperation.root||'')+':'+sdkOperation.cursor))return;}throw Error('observer_response_missing');}});if(sdkContextURL)sdkPager.observe(sdkContextURL);}
    if(q.type==='plan'&&(pendingReads>0||sdkContextURL&&!sdkGraph.pages.size)){send({sdk_result:{id:q.id,status:'wait'}});return;}
    if(q.type==='plan'){send({sdk_result:{id:q.id,status:sdkPager.available()?'available':'unavailable'}});return;}
    if(q.type==='action'){
     if(pendingReads>0){send({sdk_result:{id:q.id,status:'not_sent'}});return;}
     sdkGrant=q.grant;sdkOperation=q.operation;
     sdkPager.next(q.operation).then(()=>send({sdk_result:{id:q.id,status:'accepted'}})).catch(error=>send({sdk_result:{id:q.id,status:error.notSent?'not_sent':'unknown'}}));return;
    }
   }
   if(pendingGate)send({gate:pendingGate});
   for(const value of pending.splice(0))send(value);
   pendingBytes=0;if(overflow){send({error:'page_budget'});overflow=false;}
  });
  const descriptor=(value,method)=>{
   try{
    const u=new URL(value,location.href);if(method!=='GET'||u.protocol!=='https:'||u.hostname!=='edith.xiaohongshu.com'||u.username||u.password||u.port||u.searchParams.get('note_id')!==id)return null;
    const kind=u.pathname==='/api/sns/web/v2/comment/page'?'main':u.pathname==='/api/sns/web/v2/comment/sub/page'?'reply':null;
    if(!kind)return null;const cursor=u.searchParams.get('cursor')||'',parent=kind==='reply'?u.searchParams.get('root_comment_id'):null;
    if(cursor.length>100 || kind==='reply'&&!/^[a-f0-9]{24}$/.test(parent||''))return null;
    return {kind,input_cursor:cursor,root_id:parent};
   }catch(_){return null;}
  };
  const item=(c,withReplies=false)=>{
   if(!c||c.note_id!==id||typeof c.content!=='string')throw Error('wrong_note');
   const v={id:c.id,note_id:c.note_id,content:c.content,author_id:c.user_info?.user_id||null,author_display:c.user_info?.nickname||null,
    like_count:c.like_count??null,create_time:c.create_time??null,target_comment_id:c.target_comment?.id||null,
    pictures:(c.pictures||[]).map(p=>{const u=new URL(p.url_default);if(!['http:','https:'].includes(u.protocol)||u.hostname!=='sns-webpic-qc.xhscdn.com'||u.username||u.password||u.port||u.search||u.hash||!/^\/[^\s?#]+\/comment(?:_uhdr)?\/[a-zA-Z0-9_-]+![a-zA-Z0-9_-]+$/.test(u.pathname))throw Error('invalid_picture');return {url_default:p.url_default,width:p.width,height:p.height};})};
   if(withReplies)Object.assign(v,{sub_comment_count:c.sub_comment_count,sub_comment_has_more:c.sub_comment_has_more,sub_comment_cursor:c.sub_comment_cursor,sub_comments:(c.sub_comments||[]).map(r=>item(r))});
   return v;
  };
  const deliver=(meta,value,status)=>{
   if(!meta)return;
   if(status===403||status===429 || ['300011','300012','300013'].includes(String(value?.code))){emit({gate:'rate_limit'});return;}
   if(status===461||status===471){emit({gate:'captcha'});return;}
   if(status!==200||value?.success!==true){count('response_failed');send({diagnostics:diagnostics()});emit({error:'response_failed'});return;}
   try{
    const d=value.data;if(!d||!Array.isArray(d.comments)||d.comments.length>50||typeof d.cursor!=='string'||typeof d.has_more!=='boolean')throw Error('invalid_page');
    const page={cursor:d.cursor,has_more:d.has_more,comments:d.comments.map(c=>item(c,meta.kind==='main'))};
    if(JSON.stringify(page).length>1000000)throw Error('page_budget');
    sdkGraph.accept(meta.kind,meta.input_cursor,page,meta.root_id);sdkPager?.acceptedResponse();emit({page:{...meta,data:page}});
   }catch(error){count(['wrong_note','invalid_picture','page_budget'].includes(error.message)?error.message:'invalid_page');emit({error:'invalid_page'});}
   send({diagnostics:diagnostics()});
  };
  const originalFetch=window.fetch;
  if(typeof originalFetch==='function')window.fetch=function(...args){
   count('fetch_calls');
   // Read only the public URL/method; never request headers/body/cookies.
   const meta=current()?descriptor(typeof args[0]==='string'?args[0]:args[0]?.url,String(args[1]?.method||args[0]?.method||'GET').toUpperCase()):null;
   if(meta){count('matched_requests');pendingReads++;if(meta.kind==='main'){sdkContextURL=typeof args[0]==='string'?args[0]:args[0]?.url;sdkPager?.observe(sdkContextURL);}}
   const result=originalFetch.apply(this,args);
   if(meta)result.then(response=>{count('responses');const size=Number(response.headers.get('content-length')||0);if(size>1000000){count('page_budget');pendingReads=Math.max(0,pendingReads-1);send({diagnostics:diagnostics()});emit({error:'page_budget'});return;}
    response.clone().text().then(text=>{pendingReads=Math.max(0,pendingReads-1);if(text.length>1000000){count('page_budget');send({diagnostics:diagnostics()});emit({error:'page_budget'});return;}try{deliver(meta,JSON.parse(text),response.status);}catch(_){count('parse_failures');send({diagnostics:diagnostics()});emit({error:'response_failed'});}}).catch(()=>{pendingReads=Math.max(0,pendingReads-1);count('parse_failures');send({diagnostics:diagnostics()});emit({error:'response_failed'});});
   }).catch(()=>{pendingReads=Math.max(0,pendingReads-1);emit({error:'response_failed'});});
   return result;
  };
  if(typeof originalFetch==='function')fetchHook=window.fetch;
  if(typeof XMLHttpRequest==='function'){
   const savedOpen=XMLHttpRequest.prototype.open,savedSend=XMLHttpRequest.prototype.send,metadata=new WeakMap();
   XMLHttpRequest.prototype.open=function(method,url,...rest){count('xhr_calls');const meta=current()?descriptor(url,String(method).toUpperCase()):null;if(meta){count('matched_requests');if(meta.kind==='main'){sdkContextURL=new URL(url,location.href).href;sdkPager?.observe(sdkContextURL);}}metadata.set(this,meta);return savedOpen.call(this,method,url,...rest);};
   XMLHttpRequest.prototype.send=function(...args){const meta=metadata.get(this);
    if(meta){pendingReads++;let settled=false;const settle=()=>{if(!settled){settled=true;pendingReads=Math.max(0,pendingReads-1);}};for(const event of ['error','abort','timeout'])this.addEventListener(event,()=>{settle();emit({error:'response_failed'});},{once:true});this.addEventListener('load',()=>{settle();count('responses');try{const value=this.responseType==='json'?this.response:JSON.parse(this.responseText);if(JSON.stringify(value).length<=1000000)deliver(meta,value,this.status);else {count('page_budget');send({diagnostics:diagnostics()});emit({error:'page_budget'});}}catch(_){count('parse_failures');send({diagnostics:diagnostics()});emit({error:'response_failed'});}}, {once:true});}
    return savedSend.apply(this,args);
   };
   xhrOpenHook=XMLHttpRequest.prototype.open;xhrSendHook=XMLHttpRequest.prototype.send;
  }
  // ISOLATED requests the installation ACK after registering its receiver.
 }
 root.CrowdPassive={pageObserver};
})(globalThis);

/* The build prepends the reviewed passive observer; this file is the static MAIN entry. */
if (globalThis.CrowdPassive) globalThis.CrowdPassive.pageObserver();
