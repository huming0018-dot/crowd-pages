#!/bin/zsh
# Reconnect the existing participant installation with the reviewed native helper.
set -u
setopt PIPE_FAIL
umask 077
HERE="${0:A:h}"
SUPPORT="$HOME/Library/Application Support/CrowdV4Updater"
CANDIDATE="$HERE/crowd-v4-updater"
EXPECTED='8198638abe0013ff3540e3d1a41f682a8fc206d793bd61e4d97cc666f3272a91'
OLD_EXPECTED='b3b059d7be6eaf88b4ca3dd4652eb95a7f5faf65db91e03f5793b8bc0662b212'
finish() {
  local result="$1"
  shift
  print -r -- "$@"
  print '原参与身份、浏览器登录和采集进度保留。不要卸载插件或重新报名。'
  if [[ -t 0 ]]; then read -r '?按回车关闭。'; fi
  exit "$result"
}
owned_file() {
  [[ -f "$1" && ! -L "$1" && "${1:A}" == "$1" && "$(/usr/bin/stat -f '%u' "$1" 2>/dev/null)" == "$(/usr/bin/id -u)" ]]
}
field() { /usr/bin/plutil -extract "$2" raw -o - "$1" 2>/dev/null; }
checksum() { local result; result="$(/usr/bin/shasum -a 256 "$1" 2>/dev/null)" || return 1; print -r -- "${result%% *}"; }
print '更新采集器的自动更新助手'
print '无需退出 Chrome 或 Edge，无需重新登录。此工具不关闭浏览器。'
[[ -d "$SUPPORT" && ! -L "$SUPPORT" && "${SUPPORT:A}" == "$SUPPORT" ]] || finish 1 '未找到原安装。请把本提示交给邀请人，不要重新安装。'
owned_file "$CANDIDATE" && [[ -x "$CANDIDATE" ]] || finish 1 '请完整解压后再双击，更新助手文件缺失。'
[[ "$(checksum "$CANDIDATE")" == "$EXPECTED" ]] || finish 1 '更新工具校验失败，未执行更新。请重新取得原安装包。'
/usr/bin/codesign --verify --strict "$CANDIDATE" >/dev/null 2>&1 || finish 1 '助手签名校验未通过，未执行更新。'
owned_file "$SUPPORT/crowd-v4-updater" && owned_file "$SUPPORT/config.json" || finish 1 '原助手或配置无法安全核对，请联系邀请人。'
OLD="$(checksum "$SUPPORT/crowd-v4-updater")" || finish 1 '无法核验原助手。'
[[ "$OLD" == "$OLD_EXPECTED" || "$OLD" == "$EXPECTED" ]] || finish 1 '原助手不属于本轮已核验版本，未替换。请联系邀请人。'
if [[ -e "$SUPPORT/state.json" || -L "$SUPPORT/state.json" ]]; then
  owned_file "$SUPPORT/state.json" || finish 1 '原更新状态无法安全核对，未替换。'
  [[ -z "$(field "$SUPPORT/state.json" pending)" && -z "$(field "$SUPPORT/state.json" staging_at)" ]] || finish 2 '有一轮更新等待确认。请先在原浏览器打开插件等待完成，再双击此工具。'
fi
DIRECTORY="$(field "$SUPPORT/config.json" directory)" || finish 1 '无法读取原安装位置，未替换。'
[[ "$DIRECTORY" == /* && -d "$DIRECTORY" && ! -L "$DIRECTORY" && "${DIRECTORY:A}" == "$DIRECTORY" ]] || finish 1 '原插件位置无法安全核对，未替换。'
"$CANDIDATE" --check-install "$DIRECTORY" >/dev/null 2>&1 || finish 1 '原插件与本轮助手不兼容，未替换。'
typeset -a BROWSERS
for BROWSER in 'Google Chrome' 'Microsoft Edge'; do
  if [[ "$BROWSER" == 'Google Chrome' ]]; then BROWSER_ROOT='Google/Chrome'; else BROWSER_ROOT='Microsoft Edge'; fi
  HOST="$HOME/Library/Application Support/$BROWSER_ROOT/NativeMessagingHosts/com.crowd.v4.updater.json"
  if [[ -e "$HOST" || -L "$HOST" ]]; then
    owned_file "$HOST" || finish 1 '原浏览器助手登记无法安全核对，未替换。'
    [[ "$(field "$HOST" path)" == "$SUPPORT/crowd-v4-updater" ]] || finish 1 '原浏览器助手路径不匹配，未替换。'
    BROWSERS+=("$BROWSER")
  fi
done
(( ${#BROWSERS} > 0 )) || finish 1 '未找到原浏览器的助手连接，未替换。请联系邀请人。'
for BROWSER in "${BROWSERS[@]}"; do
  OUTPUT="$("$CANDIDATE" --reconnect "$BROWSER" 2>&1)"
  RESULT=$?
  if (( RESULT != 0 )); then
    case "$OUTPUT" in
      busy) finish 2 '另一轮更新正在进行，请稍等一分钟后再双击。' ;;
      recovery_required) finish 2 '原更新尚未完成确认，请先打开原插件等待，再重试。' ;;
      *) finish 1 '助手更新没有全部完成，尚未确认成功。请把本提示交给邀请人；原安装及助手备份保留。' ;;
    esac
  fi
done
[[ "$(checksum "$SUPPORT/crowd-v4-updater")" == "$EXPECTED" ]] || finish 1 '助手返回后校验未通过，请保留安装并联系邀请人。'
finish 0 '助手已更新。保持原浏览器联网，插件会沿原签名通道继续更新。插件版本和真实采集回执由邀请人另行核对；此提示不等于插件已经升级或采集成功。'
