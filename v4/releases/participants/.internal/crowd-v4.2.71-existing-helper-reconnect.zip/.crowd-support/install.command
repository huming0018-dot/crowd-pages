#!/bin/zsh
set -eu
PACKAGE_DIR="${0:A:h}"
cd "$PACKAGE_DIR"
if ./reconnect.command; then /usr/bin/open "$PACKAGE_DIR/existing.html" || true; else /usr/bin/open "$PACKAGE_DIR/help.html" || true; exit 1; fi
