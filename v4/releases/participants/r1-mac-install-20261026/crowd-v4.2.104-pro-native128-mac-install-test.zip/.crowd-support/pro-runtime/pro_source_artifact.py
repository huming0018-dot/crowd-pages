"""Verify the complete frozen licensed source; hashes are not SDK distribution."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import tempfile

MANIFEST_SHA256 = '2695ee9f8b899d622b18d759e947f507738428cf486845b624666fa663d6aeb9'


def load_pins():
    path = Path(__file__).with_name('PRO-LOCAL-SOURCE-PINS.json')
    if path.is_symlink() or path.stat().st_size > 1024*1024:
        raise ValueError('pro_artifact_manifest_changed')
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != MANIFEST_SHA256:
        raise ValueError('pro_artifact_manifest_changed')
    value = json.loads(raw)
    if set(value) != {'schema', 'projects'} or value['schema'] != 'crowd-pro-local-source-pins-v1' or set(value['projects']) != {'pro', 'signer'}:
        raise ValueError('pro_artifact_manifest_changed')
    return value['projects']


def verify(root, role):
    root = Path(root)
    if not root.is_absolute() or root.resolve() != root or not root.is_dir():
        raise ValueError('pro_artifact_source_changed')
    pin = load_pins()[role]
    expected = pin['files']; actual = set(); entries = 0
    for path in root.rglob('*'):
        entries += 1
        if entries > len(expected)*4 + 512 or path.is_symlink():
            raise ValueError('pro_artifact_source_changed')
        mode = path.stat().st_mode
        if stat.S_ISREG(mode):
            name = path.relative_to(root).as_posix()
            if name not in expected or path.stat().st_size != expected[name]['bytes']:
                raise ValueError('pro_artifact_source_changed')
            if hashlib.sha256(path.read_bytes()).hexdigest() != expected[name]['sha256']:
                raise ValueError('pro_artifact_source_changed')
            actual.add(name)
        elif not stat.S_ISDIR(mode):
            raise ValueError('pro_artifact_source_changed')
    if actual != set(expected):
        raise ValueError('pro_artifact_source_changed')
    return {'commit': pin['commit'], 'dirty': False,
            'source_basis': 'complete_frozen_pro_source_manifest',
            'source_manifest_sha256': MANIFEST_SHA256}


def factory_bytes(root, name, pin):
    """Only trusted manifest paths are opened; Git metadata and extras are ignored."""
    fd = os.open(root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        parts = Path(name).parts
        for part in parts[:-1]:
            next_fd = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd); fd = next_fd
        file_fd = os.open(parts[-1], os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=fd)
        with os.fdopen(file_fd, 'rb') as stream:
            before = os.fstat(stream.fileno())
            if not stat.S_ISREG(before.st_mode) or before.st_uid != os.getuid() or before.st_mode & 0o022 or before.st_size != pin['bytes']:
                raise ValueError('pro_artifact_source_changed')
            raw = stream.read(pin['bytes'] + 1); after = os.fstat(stream.fileno())
            if (before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) != (after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns) or len(raw) != pin['bytes'] or hashlib.sha256(raw).hexdigest() != pin['sha256']:
                raise ValueError('pro_artifact_source_changed')
            return raw
    finally:
        os.close(fd)


def materialize(source, destination, role):
    """Mac installer only: copy pinned factory bytes into a private immutable root."""
    import fcntl
    source = Path(source); destination = Path(destination)
    if source.resolve() != source or destination.resolve() != destination:
        raise ValueError('pro_artifact_source_changed')
    parent = destination.parent
    parent.mkdir(mode=0o700, exist_ok=True)
    if parent.is_symlink() or parent.stat().st_uid != os.getuid() or parent.stat().st_mode & 0o077:
        raise ValueError('pro_artifact_source_changed')
    lock = os.open(parent/'.prepare.lock', os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW | os.O_NONBLOCK, 0o600)
    stage = None
    try:
        st = os.fstat(lock)
        if not stat.S_ISREG(st.st_mode) or st.st_uid != os.getuid() or st.st_mode & 0o077:
            raise ValueError('pro_artifact_source_changed')
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if destination.exists() or destination.is_symlink():
            return {**verify(destination, role), 'root': str(destination), 'reused': True}
        stage = Path(tempfile.mkdtemp(prefix='.stage-', dir=parent))
        for name, pin in load_pins()[role]['files'].items():
            raw = factory_bytes(source, name, pin)
            path = stage/name; path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
            with os.fdopen(fd, 'wb') as stream:
                stream.write(raw); stream.flush(); os.fsync(stream.fileno())
        verified = verify(stage, role)
        for directory in sorted([stage, *[p for p in stage.rglob('*') if p.is_dir()]], key=lambda p: len(p.parts), reverse=True):
            fd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
            try: os.fsync(fd)
            finally: os.close(fd)
        os.rename(stage, destination); stage = None
        fd = os.open(parent, os.O_RDONLY | os.O_DIRECTORY)
        try: os.fsync(fd)
        finally: os.close(fd)
        return {**verified, 'root': str(destination), 'reused': False}
    except OSError:
        raise ValueError('pro_artifact_source_changed') from None
    finally:
        if stage is not None: shutil.rmtree(stage)
        os.close(lock)
