/* Owned detail tabs. A browser-session marker prevents stale tab-ID adoption. */
(function(root) {
  'use strict';
  class CrowdWorkTabs {
    constructor({chrome,storage,owner,probe,uuid}) {Object.assign(this,{chrome,storage,owner,probe,uuid});this.tail=Promise.resolve();this.instance=uuid();}
    async session() {
      if(this.sessionPromise)return this.sessionPromise;
      this.sessionPromise=this.loadSession();return this.sessionPromise;
    }
    async loadSession() {
      if (!this.chrome.storage.session) throw Error('parallel_unavailable');
      const key='crowd_work_session';
      let value=(await this.chrome.storage.session.get(key))[key];
      if (!value) {value=this.uuid();await this.chrome.storage.session.set({[key]:value});}
      return value;
    }
    async key() {const owner=await this.owner();if(!owner)throw Error('backend_login_required');return 'work_tabs:'+owner;}
    matches(current,expected) {
      try {
        const a=new URL(root.CrowdCore.navigationURL(current)),b=new URL(expected);
        try{return root.CrowdCore.noteURL(a.href).id===root.CrowdCore.noteURL(b.href).id;}catch(_){}
        return a.pathname===b.pathname && a.searchParams.get('keyword')===b.searchParams.get('keyword');
      }catch(_){return false;}
    }
    async entries() {return await this.storage.get(await this.key()) || {};}
    async assertKey(expected) {if(await this.key()!==expected)throw Error('cancelled');}
    write(fn,expected) {
      const pending=this.tail.catch(()=>{}).then(async()=>{
        const key=await this.key(),entries=await this.storage.get(key)||{};
        if(expected && key!==expected)throw Error('cancelled');
        const result=await fn(entries);await this.storage.set(key,entries);return result;
      });this.tail=pending;return pending;
    }
    async open(url, slot) {
      const key=await this.key(),destination=root.CrowdCore.navigationURL(url),session=await this.session();
      let entry=(await this.entries())[slot];
      if(entry) {
        if(entry.session!==session || !entry.tab || entry.state!=='opened')throw Error('pool_recovery_required');
        const {pending}=await this.target(slot);
        const proof=await this.probe(entry.tab,'ownership');
        if(pending || !entry.document || proof?.response?.token!==entry.token || proof?.response?.document!==entry.document)throw Error('pool_recovery_required');
        entry={...entry,url:destination,token:this.uuid(),state:'opening',previous_document:entry.document,document:null,instance:this.instance};
        await this.write(entries=>{entries[slot]=entry;},key);await this.assertKey(key);
        await this.chrome.tabs.update(entry.tab,{url:destination,active:false});
      } else {
        entry={url:destination,token:this.uuid(),state:'opening',session,tab:null,instance:this.instance,document:null};
        // A crash after creation and before saving the ID remains unknown;
        // recovery refuses a second creation under the same admission.
        await this.write(entries=>{entries[slot]=entry;},key);
        const [window]=await this.chrome.windows.getAll({windowTypes:['normal']});
        await this.assertKey(key);
        const tab=window ? await this.chrome.tabs.create({url:destination,active:false}) :
          (await this.chrome.windows.create({url:destination,type:'normal',state:'minimized',focused:false})).tabs[0];
        entry={...entry,tab:tab.id};
      }
      await this.write(entries=>{entries[slot]={...entry,state:'opened'};},key);
    }
    async target(slot) {
      const key=await this.key();
      const entry=(await this.entries())[slot];
      if (!entry || entry.session!==await this.session() || !entry.tab || entry.state!=='opened')throw Error('pool_recovery_required');
      const tab=await this.chrome.tabs.get(entry.tab).catch(()=>null);
      if(!tab || tab.discarded)throw Error('pool_recovery_required');
      // Chrome may omit URL/pendingUrl before host permission applies at commit.
      // Only a newly created, unbound tab in this worker may wait in that state.
      const uncommitted=entry.instance===this.instance && !entry.document && tab.status==='loading' && (!tab.url || tab.url==='about:blank');
      const pending=!this.matches(tab.url,entry.url) && (this.matches(tab.pendingUrl,entry.url) || uncommitted);
      if(!pending && !this.matches(tab.url,entry.url))throw Error('pool_recovery_required');
      await this.assertKey(key);return {entry,tab,pending};
    }
    async read(action,slot) {
      const ownerKey=await this.key();
      const {entry,tab,pending}=await this.target(slot);
      if(pending)return {ready:false,reason:'page_loading'};
      if(tab.frozen)return {ready:false,reason:'page_frozen'};
      const identity=(await this.probe(entry.tab,'ownership')).response;
      if(!identity)return {ready:false,reason:'content_unavailable'};
      if(entry.document) {
        if(identity.token!==entry.token || identity.document!==entry.document)throw Error('pool_recovery_required');
      } else {
        if(entry.instance!==this.instance)throw Error('pool_recovery_required');
        if(identity.document===entry.previous_document)return {ready:false,reason:'page_loading'};
        await this.assertKey(ownerKey);
        const bound=await this.chrome.tabs.sendMessage(entry.tab,{type:'crowd_bind',token:entry.token});
        if(!bound?.document)throw Error('pool_recovery_required');
        await this.write(entries=>{if(entries[slot]?.token===entry.token)entries[slot].document=bound.document;},ownerKey);
      }
      const response=await this.probe(entry.tab,action);
      return response.response || {ready:false,reason:tab.status==='loading'?'page_loading':'content_unavailable'};
    }
    async ready(sender,message) {
      const session=await this.session();
      for(const [slot,entry] of Object.entries(await this.entries())) {
        if(entry.tab!==sender.tab?.id || entry.session!==session || entry.state!=='opened')continue;
        const {pending}=await this.target(slot);if(pending)return null;
        if(!message.token) {
          if(entry.document || entry.instance!==this.instance)continue;
          await this.read('ownership',slot);
        } else if(message.token!==entry.token)continue;
        return slot;
      }
      return null;
    }
    async close(slot, expectedOwner = null) {
      if(!await this.owner())return;
      const ownerKey=await this.key();
      if(expectedOwner && ownerKey!=='work_tabs:'+expectedOwner)throw Error('cancelled');
      await this.assertKey(ownerKey);
      const entries=await this.storage.get(ownerKey)||{},selected=slot ? [[slot,entries[slot]]] : Object.entries(entries);
      for(const [key,entry] of selected) {
        if(!entry)continue;
        if(entry.session!==await this.session()) {
          // Browser restart invalidates tab IDs; retire our mapping without touching a user's tab.
          await this.write(all=>{if(all[key]?.token===entry.token)delete all[key];},ownerKey);
          continue;
        }
        if(!entry.tab)throw Error('pool_recovery_required');
        const tab=await this.chrome.tabs.get(entry.tab).catch(()=>null);
        if(tab) {
          if(!this.matches(tab.url,entry.url) && !this.matches(tab.pendingUrl,entry.url))throw Error('pool_recovery_required');
          if(entry.document) {
            const proof=(await this.probe(entry.tab,'ownership')).response;
            if(proof?.token!==entry.token || proof?.document!==entry.document)throw Error('pool_recovery_required');
          } else if(entry.instance!==this.instance)throw Error('pool_recovery_required');
          await this.assertKey(ownerKey);await this.chrome.tabs.remove(entry.tab);
        }
        await this.write(all=>{if(all[key]?.token===entry.token)delete all[key];},ownerKey);
      }
    }
    async first() {
      if(!await this.owner())return null;
      for(const [slot,entry] of Object.entries(await this.entries())) {
        try {const proof=await this.read('ownership',slot);if(proof.token===entry.token)return entry.tab;}catch(_){}
      }
      return null;
    }
    async removed(id) {await this.write(entries=>{for(const entry of Object.values(entries))if(entry.tab===id)entry.state='missing';});}
  }
  root.CrowdWorkTabs=CrowdWorkTabs;
})(globalThis);
