/* Whitelisted public page observations, never credentials or executable page data. */
(function(root){
'use strict';

// Parse data literals, never evaluate a webpage's executable JavaScript.
function structuredBody(script,noteId) {
 const prefix='window.__INITIAL_STATE__=';
 if(typeof script!=='string'||script.length>2000000||!script.startsWith(prefix)||! /^[a-f0-9]{24}$/.test(noteId))throw Error('invalid_hydration');
 const input=script.slice(prefix.length).replace(/;\s*$/,''), boundary=c=>!c||!/[A-Za-z0-9_$]/.test(c);
 let out='',quoted=false,escaped=false;
 for(let i=0;i<input.length;i++){
  const c=input[i];
  if(quoted){out+=c;if(escaped)escaped=false;else if(c==='\\')escaped=true;else if(c==='"')quoted=false;}
  else if(c==='"'){quoted=true;out+=c;}
  else if(input.slice(i,i+9)==='undefined'&&boundary(input[i-1])&&boundary(input[i+9])){out+='null';i+=8;}
  else if(input.slice(i,i+11)==='new Map([])'&&boundary(input[i-1])&&boundary(input[i+11])){out+='{}';i+=10;}
  else out+=c;
 }
 const note=JSON.parse(out).note?.noteDetailMap?.[noteId]?.note;
 if(!note||note.noteId!==noteId||typeof note.title!=='string'||typeof note.desc!=='string'||note.title.length>300||note.desc.length>24000)throw Error('missing_or_wrong_note');
 return {source:'page_hydration',note_id:noteId,title:note.title,text:note.desc,original_length:note.desc.length,truncated:false};
}


// Independent implementation: normal-page response observations, never DOM evidence.
// No request signing, credentials, network calls, or silent retry in this module.
class StructuredPages {
 constructor(note) {this.note=note;this.items=new Map();this.roots=new Map();this.pages=new Map();this.main={cursor:'',ended:false};this.failures=[];this.bytes=0;}
 accept(kind,inputCursor,data,root=null) {
  if(!['main','reply'].includes(kind)||typeof inputCursor!=='string'||!data||typeof data.cursor!=='string'||typeof data.has_more!=='boolean'||!Array.isArray(data.comments))throw Error('invalid_page');
  if(kind==='reply'&&!this.roots.has(root))throw Error('unknown_parent');
  const state=kind==='main'?this.main:this.roots.get(root),key=kind+':'+(root||'')+':'+inputCursor;
  if(inputCursor.length>100 || data.cursor.length>100 || data.comments.length>50)throw Error('page_budget');
  const payload=JSON.stringify(data);if(payload.length>1000000)throw Error('page_budget');
  if(this.pages.has(key)){if(this.pages.get(key)!==payload)throw Error('page_conflict');return;}
  if(this.pages.size>=250||this.bytes+new TextEncoder().encode(payload).length>1500000)throw Error('page_budget');
  if(state.ended||state.cursor!==inputCursor)throw Error('cursor_out_of_order');
  if(data.has_more&&(!data.cursor||data.cursor===inputCursor))throw Error('cursor_stalled');
  const next=[],pendingRoots=new Map();
  const add=(item,parent)=>{
   if(!item||typeof item.id!=='string'||! /^[a-f0-9]{24}$/.test(item.id)||item.note_id!==this.note||typeof item.content!=='string'||item.content.length>24000)throw Error('wrong_note_or_item');
   const pictures=item.pictures===undefined?[]:item.pictures;
   if(!Array.isArray(pictures)||pictures.some(p=>{try{const u=new URL(p.url_default);return !['http:','https:'].includes(u.protocol)||u.hostname!=='sns-webpic-qc.xhscdn.com'||u.port||u.username||u.password||u.search||u.hash||!/\/comment(?:_uhdr)?\//.test(u.pathname)||!Number.isInteger(p.width)||!Number.isInteger(p.height)||p.width<=0||p.height<=0||p.width>100000||p.height>100000;}catch(_){return true;}}))throw Error('invalid_pictures');
   const authorId=item.author_id??null,targetId=item.target_comment_id??null,author=item.author_display??null;
   if([authorId,targetId].some(id=>id!==null&&(typeof id!=='string'||!/^[a-f0-9]{24}$/.test(id))) || author!==null&&(typeof author!=='string'||author.length>100))throw Error('invalid_comment_metadata');
   const likes=item.like_count??null,time=item.create_time??null;
   if(likes!==null&&(!/^[0-9]+$/.test(String(likes))||!Number.isSafeInteger(Number(likes))||Number(likes)<0) || time!==null&&(!Number.isSafeInteger(time)||time<0))throw Error('invalid_comment_metadata');
   const record={id:item.id,parent,text:item.content,pictures,author_id:authorId,author_display:author,like_count:likes===null?null:Number(likes),create_time:time,reply_target_id:targetId,source:'page_response'};
   const existing=this.items.get(item.id)||next.find(v=>v.id===item.id);
   if(existing&&(existing.parent!==parent||existing.text!==record.text||existing.author_id!==record.author_id||existing.reply_target_id!==record.reply_target_id))throw Error('item_conflict');
   next.push(record);
  };
  for(const item of data.comments){
   add(item,root);
   if(kind==='main'){
    const count=Number(item.sub_comment_count);
    if(!Number.isSafeInteger(count)||count<0||count>10000||typeof item.sub_comment_has_more!=='boolean'||typeof item.sub_comment_cursor!=='string'||!Array.isArray(item.sub_comments))throw Error('invalid_reply_state');
    const snapshot=JSON.stringify([count,item.sub_comment_has_more,item.sub_comment_cursor]);
    if((this.roots.has(item.id)&&this.roots.get(item.id).snapshot!==snapshot)||(pendingRoots.has(item.id)&&pendingRoots.get(item.id)!==snapshot))throw Error('root_metadata_conflict');
    pendingRoots.set(item.id,snapshot);
    for(const reply of item.sub_comments)add(reply,item.id);
   }
  }
  if(new Set([...this.items.keys(),...next.map(v=>v.id)]).size>2000)throw Error('page_budget');
  // Commit a whole validated page; malformed rows cannot advance a cursor.
  for(const record of next)this.items.set(record.id,record);
  if(kind==='main')for(const item of data.comments){
   const previous=this.roots.get(item.id);
   if(!previous)this.roots.set(item.id,{cursor:item.sub_comment_cursor,ended:!item.sub_comment_has_more,declared:Number(item.sub_comment_count),snapshot:JSON.stringify([Number(item.sub_comment_count),item.sub_comment_has_more,item.sub_comment_cursor])});
  }
  state.cursor=data.cursor;state.ended=!data.has_more;this.pages.set(key,payload);this.bytes+=new TextEncoder().encode(payload).length;
 }
 summary(){
  const groups=[...this.roots].map(([id,s])=>({id,declared:s.declared,captured:[...this.items.values()].filter(v=>v.parent===id).length,ended:s.ended}));
  return {source:'page_response',roots:this.roots.size,replies:[...this.items.values()].filter(v=>v.parent!==null).length,images:[...this.items.values()].reduce((n,v)=>n+v.pictures.length,0),main_ended:this.main.ended,groups,complete:this.main.ended&&groups.every(g=>g.ended&&g.captured===g.declared)&&!this.failures.length};
 }
}


root.CrowdStructured={structuredBody,StructuredPages};
})(globalThis);

/* Fixed packaged MAIN observer; no dynamic scripts, extra requests or CSP changes. */
(function(root){
 'use strict';
 function pageObserver() {
  'use strict';
  const marker=new URL(location.href).searchParams.get('crowd_capture'),id=location.pathname.match(/^\/(?:explore|discovery\/item|search_result)\/([a-f0-9]{24})\/?$/i)?.[1]?.toLowerCase();
  if(window.top!==window || !id || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(marker||''))return;
  let bridgeReady=false,pendingBytes=0,overflow=false,pendingGate=null;
  const pending=[];
  const current=()=>location.pathname.match(/^\/(?:explore|discovery\/item|search_result)\/([a-f0-9]{24})\/?$/i)?.[1]?.toLowerCase()===id&&new URL(location.href).searchParams.get('crowd_capture')===marker;
  const send=data=>{if(current())window.postMessage({type:'crowd_public_response_v1',nonce:marker,note_id:id,...data},location.origin);};
  const emit=data=>{
   if(!current())return;
   if(bridgeReady){send(data);return;}
   if(data.gate){pendingGate=data.gate;return;}
   const bytes=JSON.stringify(data).length;
   if(pending.length<4&&pendingBytes+bytes<=1000000){pending.push(data);pendingBytes+=bytes;}else overflow=true;
  };
  window.addEventListener('message',event=>{
   const m=event.data;
   if(event.source!==window||event.origin!==location.origin||m?.type!=='crowd_public_ready_v1'||m.nonce!==marker||m.note_id!==id||!current())return;
   bridgeReady=true;send({installed:true});
   if(pendingGate)send({gate:pendingGate});
   for(const value of pending.splice(0))send(value);
   pendingBytes=0;if(overflow){send({error:'page_budget'});overflow=false;}
  });
  const descriptor=(value,method)=>{
   try{
    const u=new URL(value,location.href);if(method!=='GET'||u.protocol!=='https:'||u.hostname!=='edith.xiaohongshu.com'||u.username||u.password||u.port||u.searchParams.get('note_id')!==id)return null;
    const kind=u.pathname==='/api/sns/web/v2/comment/page'?'main':u.pathname==='/api/sns/web/v2/comment/sub/page'?'reply':null;
    if(!kind)return null;const cursor=u.searchParams.get('cursor')||'',parent=kind==='reply'?u.searchParams.get('root_comment_id'):null;
    if(cursor.length>100 || kind==='reply'&&!/^[a-f0-9]{24}$/.test(parent||''))return null;
    return {kind,input_cursor:cursor,root_id:parent};
   }catch(_){return null;}
  };
  const item=(c,withReplies=false)=>{
   if(!c||c.note_id!==id||typeof c.content!=='string')throw Error('wrong_note');
   const v={id:c.id,note_id:c.note_id,content:c.content,author_id:c.user_info?.user_id||null,author_display:c.user_info?.nickname||null,
    like_count:c.like_count??null,create_time:c.create_time??null,target_comment_id:c.target_comment?.id||null,
    pictures:(c.pictures||[]).map(p=>{const u=new URL(p.url_default);if(!['http:','https:'].includes(u.protocol)||u.hostname!=='sns-webpic-qc.xhscdn.com'||u.username||u.password||u.port||u.search||u.hash||!/^\/[^\s?#]+\/comment(?:_uhdr)?\/[a-zA-Z0-9_-]+![a-zA-Z0-9_-]+$/.test(u.pathname))throw Error('invalid_picture');return {url_default:p.url_default,width:p.width,height:p.height};})};
   if(withReplies)Object.assign(v,{sub_comment_count:c.sub_comment_count,sub_comment_has_more:c.sub_comment_has_more,sub_comment_cursor:c.sub_comment_cursor,sub_comments:(c.sub_comments||[]).map(r=>item(r))});
   return v;
  };
  const deliver=(meta,value,status)=>{
   if(!meta)return;
   if(status===429 || ['300011','300012','300013'].includes(String(value?.code))){emit({gate:'rate_limit'});return;}
   if(status===461||status===471){emit({gate:'captcha'});return;}
   if(status!==200||value?.success!==true){emit({error:'response_failed'});return;}
   try{
    const d=value.data;if(!d||!Array.isArray(d.comments)||d.comments.length>50||typeof d.cursor!=='string'||typeof d.has_more!=='boolean')throw Error('invalid_page');
    const page={cursor:d.cursor,has_more:d.has_more,comments:d.comments.map(c=>item(c,meta.kind==='main'))};
    if(JSON.stringify(page).length>1000000)throw Error('page_budget');
    emit({page:{...meta,data:page}});
   }catch(_){emit({error:'invalid_page'});}
  };
  const originalFetch=window.fetch;
  if(typeof originalFetch==='function')window.fetch=function(...args){
   // Read only the public URL/method; never request headers/body/cookies.
   const meta=descriptor(typeof args[0]==='string'?args[0]:args[0]?.url,String(args[1]?.method||args[0]?.method||'GET').toUpperCase());
   const result=originalFetch.apply(this,args);
   if(meta)result.then(response=>{const size=Number(response.headers.get('content-length')||0);if(size>1000000){emit({error:'page_budget'});return;}
    response.clone().text().then(text=>{if(text.length>1000000){emit({error:'page_budget'});return;}try{deliver(meta,JSON.parse(text),response.status);}catch(_){emit({error:'response_failed'});}}).catch(()=>emit({error:'response_failed'}));
   }).catch(()=>{});
   return result;
  };
  if(typeof XMLHttpRequest==='function'){
   const savedOpen=XMLHttpRequest.prototype.open,savedSend=XMLHttpRequest.prototype.send,metadata=new WeakMap();
   XMLHttpRequest.prototype.open=function(method,url,...rest){metadata.set(this,descriptor(url,String(method).toUpperCase()));return savedOpen.call(this,method,url,...rest);};
   XMLHttpRequest.prototype.send=function(...args){const meta=metadata.get(this);
    if(meta)this.addEventListener('load',()=>{try{const value=this.responseType==='json'?this.response:JSON.parse(this.responseText);if(JSON.stringify(value).length<=1000000)deliver(meta,value,this.status);else emit({error:'page_budget'});}catch(_){emit({error:'response_failed'});}}, {once:true});
    return savedSend.apply(this,args);
   };
  }
  // ISOLATED requests the installation ACK after registering its receiver.
 }
 root.CrowdPassive={pageObserver};
})(globalThis);

/* This adapter observes a marked, owned note only. It never initiates a platform request. */
(function(root){
 'use strict';
 function createHybrid({window,document,location,bodyReader=root.CrowdStructured.structuredBody}) {
  const note=location.pathname.match(/^\/(?:explore|discovery\/item|search_result)\/([a-f0-9]{24})\/?$/i)?.[1]?.toLowerCase(),nonce=new URL(location.href).searchParams.get('crowd_capture');
  if(!note||!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(nonce||''))return null;
  const graph=new root.CrowdStructured.StructuredPages(note),pending=[],errors=[];
  let bound=false,installed=false,attempted=0,body=null,gate=null;
  const fault=reason=>{if(!errors.includes(reason))errors.push(reason);};
  const consume=page=>{try{graph.accept(page.kind,page.input_cursor,page.data,page.root_id);}catch(e){fault(['unknown_parent','cursor_out_of_order','cursor_stalled','page_conflict','root_metadata_conflict','item_conflict','page_budget'].includes(e.message)?e.message:'invalid_page');}};
  window.addEventListener('message',event=>{
   const m=event.data;
   if(event.source!==window||event.origin!==location.origin||m?.type!=='crowd_public_response_v1'||m.nonce!==nonce||m.note_id!==note)return;
   try{if(JSON.stringify(m).length>1100000){fault('page_budget');return;}}catch(_){fault('invalid_page');return;}
   if(m.installed===true){installed=true;return;}
   if(['captcha','rate_limit'].includes(m.gate)){gate=m.gate;return;}
   if(m.error){fault(['response_failed','invalid_page','page_budget'].includes(m.error)?m.error:'invalid_page');return;}
   if(!m.page)return;
   if(bound)consume(m.page);else if(pending.length<4)pending.push(m.page);else fault('late_binding');
  });
  const install=()=>{
   if(installed||attempted>=4)return;
   attempted++;
   window.postMessage({type:'crowd_public_ready_v1',nonce,note_id:note},location.origin);
   if(!installed&&attempted<4)window.setTimeout(install,250);
  };
  // The fixed MAIN file owns installation. READY can be repeated without network traffic.
  install();
  return {
   bind(token){bound=token===nonce;if(bound)for(const page of pending.splice(0))consume(page);return bound;},
   snapshot(noteId,dom,documentId){
    if(!bound||noteId!==note)return null;
    if(!body){const script=[...(document.scripts||[])].find(s=>!s.src&&s.textContent?.startsWith('window.__INITIAL_STATE__='));if(script)try{body=bodyReader(script.textContent,note);}catch(_){fault('body_unavailable');}}
    const summary=graph.summary(),items=[...graph.items.values()],domIds=[...new Set((dom?.extra?.comments?.items||[]).map(i=>i.comment_id).filter(Boolean))];
    const witness=domIds.length>0&&domIds.every(id=>graph.items.has(id));
    const current=location.pathname.match(/^\/(?:explore|discovery\/item|search_result)\/([a-f0-9]{24})\/?$/i)?.[1]?.toLowerCase();
    if(current!==note)return null;
    return {version:1,note_id:note,document:documentId,source:'page_response',mode:installed?'passive_hybrid':'dom_fallback',observer_status:installed?'installed':attempted?'csp_or_not_installed':'waiting',
     gate,body,items,groups:summary.groups,main_ended:summary.main_ended,pages:[...graph.pages.keys()],
     complete:summary.complete&&installed&&witness&&errors.length===0,errors:errors.slice(0,12),
     dom_witness:{note_id:note,comment_ids:domIds,matched:witness,reported_count:dom?.standard?.comment_count??null},
     body_dom_match:!!body&&body.text.replace(/\[[^\]\r\n]{1,40}R\]/g,'').replace(/\[话题\]#/g,'').trim()===dom?.evidence?.text};
   }
  };
 }
 root.CrowdHybrid={createHybrid};
})(globalThis);

/* Only rendered public content. Never intercept private APIs, cookies or network. */
(function (root) {
  'use strict';
  const C = root.CrowdCore, platform = C.platform('xiaohongshu');
  let workDocument=null,workToken=null;
  const hybrid=root.CrowdHybrid?.createHybrid({window,document,location});
  const visible = el => !!el && !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length) && getComputedStyle(el).visibility !== 'hidden';
  const first = selectors => [...document.querySelectorAll(selectors)].find(visible);
  const text = el => el?.innerText?.trim() || '';
  const ownPost = el => visible(el) && !el.closest('.comments-container, .comments-list, .comment-list, .comment-item, .note-item');
  // A comma-separated query returns DOM order, not selector priority. Prefer
  // explicit detail fields before fallbacks, excluding recommendations/comments.
  const postFirst = selectors => {
    const scope = noteScope();
    for (const selector of selectors.split(',')) {
      const node = [...scope.querySelectorAll(selector.trim())].find(ownPost);
      if (node) return node;
    }
  };
  const noteBody = () => postFirst('#detail-desc, .note-detail .note-text, .note-container .note-text, .note-scroller .desc, .note-content .desc, .note-container .desc, #noteContainer .desc');
  const noteLinks = () => {
    // Prefer each result card's own links (crawler-extension v1.0.0 pattern).
    const cards = [...document.querySelectorAll('section.note-item, div.note-item')];
    const selectors = 'a[href*="/explore/"], a[href*="/discovery/item/"], a[href*="/search_result/"]';
    const links = cards.length ? cards.flatMap(card => [...card.querySelectorAll(selectors)]) : [...document.querySelectorAll(selectors)];
    return links.filter(a => {
    if (!visible(a)) return false;
    try { platform.noteURL(a.href); return true; } catch (_) { return false; }
    });
  };
  function gate() {
    if (first('[class*="captcha"], [id*="captcha"], iframe[src*="captcha"], [class*="verify-slider"]')) return 'captcha';
    const modal = first('[role="dialog"], .error-page, .error-container, .login-container, .login-modal');
    const message = text(modal);
    if(/^\/website-login\/error\/?$/.test(location.pathname) && /访问频繁|请求过于频繁|300013/.test(text(document.body)))return 'rate_limit';
    if (/访问频繁|操作频繁|请求过于频繁|稍后再试|访问受限/.test(message)) return 'rate_limit';
    if (first('.login-container input, .login-modal input, input[placeholder*="手机号"]') || /登录后查看|请先登录/.test(message)) return 'login_required';
    return null;
  }
  function parseCount(label) {
    const value = label.replace(/,/g, '').trim();
    const m = value.match(/^(?:(?:阅读|浏览|观看|点赞|收藏|评论|共)\s*)?(\d+(?:\.\d+)?)\s*([万wWkK千]?)\+?\s*(?:次(?:浏览|阅读|观看)?|条(?:评论)?|浏览|阅读|观看|点赞|收藏|评论)?$/);
    if (!m) return null;
    const valueNumber = Math.round(Number(m[1]) * ({万: 10000, w: 10000, W: 10000, k: 1000, K: 1000, 千: 1000}[m[2]] || 1));
    return Number.isSafeInteger(valueNumber) && valueNumber <= 2147483647 ? valueNumber : null;
  }
  function metric(label) {
    const value = parseCount(label || '');
    return {value, label: label || null, status: value === null ? (label ? 'unparsed' : 'not_visible') : /[万wWkK千+]/.test(label) ? 'approximate' : 'exact'};
  }
  function cards() {
    return noteLinks().map(a => {
      const card = a.closest('section.note-item, div.note-item');
      return {url: a.href, title: text(card?.querySelector('.title')).slice(0,300), author_display: text(card?.querySelector('.author .name')).slice(0,100) || null};
    });
  }
  function profile() {
    let p; try { p = platform.profileURL(location.href); } catch (_) { return {ready:false}; }
    const scope = first('.user-info, .user-page .info-part, .user-profile, [data-profile-header]');
    if (!scope) return {ready:false};
    const own = selector => [...scope.querySelectorAll(selector)].find(visible);
    const nickname = text(own('.user-name, .nickname, .username')).slice(0,100);
    if (!nickname) return {ready:false};
    const metrics = {};
    for (const [key,label] of Object.entries({followers:'粉丝',notes:'笔记',likes_collected:'获赞与收藏'})) {
      const row = [...scope.querySelectorAll('.user-interactions > *, .data-info > *, .interaction, [data-profile-metric]')].find(el => visible(el) && text(el).includes(label));
      metrics[key] = metric(text(row?.querySelector('.count, .number, [data-value]')) || null);
    }
    return {ready:true, profile:{author_id:p.id,url:p.url,nickname,public_handle:text(own('.user-redId, .red-id')).replace(/^小红书号[：:\s]*/, '').slice(0,100) || null,
      metrics, notes:cards().slice(0,12).map(card => ({note_id:platform.noteURL(card.url).id,title:card.title})),
      captured_at:new Date().toISOString(),source:'rendered_public_dom',parser_version:C.VERSION}};
  }
  const noteScope = () => {
    const scopes = [...document.querySelectorAll('#noteContainer, .note-detail, .note-container')].filter(ownPost);
    const overlay = scopes.find(el => el.closest('[role="dialog"], .note-detail-mask'));
    if (overlay) return overlay;
    const anchor = [...document.querySelectorAll('#detail-desc, #detail-title')].find(ownPost);
    if (anchor) {
      const owner = scopes.find(el => el.contains(anchor));
      if (owner) return owner;
    }
    // Prefer the visible overlay. Do not fall through to recommendation cards.
    return scopes.at(-1) || document;
  };
  const commentPanel = () => [...noteScope().querySelectorAll('.comments-container, .comments-list, .comment-list, .comments-el')].find(visible);
  function expandControl(panel) {
    return [...(panel?.querySelectorAll('.show-more, .show-more-container, .load-more, .more-replies, button') || [])].find(el =>
      visible(el) && !el.disabled && /^(?:展开(?:更多)?|查看更多|加载更多)\s*(?:\d+\s*条)?\s*(?:回复|评论)/.test(text(el)) &&
      (!el.getAttribute('href') || el.getAttribute('href').startsWith('#')));
  }
  function commentScroller(panel) {
    for(let node=panel;node&&node!==document.body;node=node.parentElement)
      if(node.scrollHeight>node.clientHeight && /auto|scroll/.test(getComputedStyle(node).overflowY))return node;
    return first('.note-scroller, .note-detail .scroll-container') || window;
  }
  function commentImage(img) {
    const kind=img.matches('img.note-content-emoji')?'emoji':'image';
    let url=img.currentSrc || img.src || '';
    // Chrome upgrades this observed public CDN's HTTP markup to HTTPS for rendering.
    if(kind==='image' && url.startsWith('http://sns-webpic-qc.xhscdn.com/'))url=url.replace(/^http:/,'https:');
    return C.commentMediaURL(url,kind)?{kind,url,alt:img.getAttribute('alt')?.slice(0,100)||null}:null;
  }
  function comments(record, full = false) {
    const panel = commentPanel();
    const result = {items: [], coverage: 'visible_loaded_only', complete: false, panel_found: !!panel,
      loaded_count: 0, captured_count: 0, omitted_count: 0, truncated: false, more_available: !!expandControl(panel)};
    if (!panel) return result;
    // Own fields only: parent.innerText would incorrectly include all nested replies.
    const selector = panel.querySelector('.comment-item') ? '.comment-item' : '.comment-inner-container';
    const allNodes=[...panel.querySelectorAll(selector)], nodes=allNodes.filter(visible);
    result.dom_census={document:workDocument,visible_count:nodes.length,hidden_count:allNodes.length-nodes.length,skipped_count:0,duplicate_count:0,unresolved_parent_count:0};
    result.loading=[...panel.querySelectorAll('.loading, .loading-container, .spinner, [aria-busy="true"]')].some(visible);
    result.loaded_count = nodes.length;
    const keys = new Map(nodes.map((node, index) => [node, 'comment-' + (index + 1)]));
    const own = (node, selectors) => [...node.querySelectorAll(selectors)].find(el => visible(el) && el.closest(selector) === node);
    // Keep headroom below the existing client/SQL envelope limits, including long note evidence.
    const budget = full ? Infinity : Math.min(20000, Math.max(0, 55000 - JSON.stringify(record).length));
    let size = 0;
    for (const node of nodes) {
      const content=own(node, '.content .note-text, .content, .comment-content, .comment-text');
      const original = text(content);
      const images=full?[...node.querySelectorAll('img.note-content-emoji, .img-box img.inner')].filter(img=>img.closest(selector)===node && visible(img)):[];
      const media=images.map(commentImage).filter(Boolean).slice(0,20);
      for(const img of images)if(!commentImage(img)) {
        const url=img.currentSrc || img.src || '';
        if(!url || /^(?:data:|blob:)/.test(url))result.media_pending=true;
        else result.truncated=true;
      }
      if(images.length>20)result.truncated=true;
      if (!original && !media.length) continue;
      const ancestor = node.parentElement?.closest(selector);
      const group = node.closest('.parent-comment');
      const parent = ancestor || (group && group.querySelector(selector) !== node ? group.querySelector(selector) : null);
      const parentKey = keys.get(parent) || null;
      // A reply with a missing/unreadable parent is explicitly unresolved, never attached to another comment.
      const idNode = node.closest('.comment-inner-container');
      const candidateID = node.getAttribute('data-comment-id') || node.id || (idNode && idNode.querySelector(selector) === node ? idNode.id : '') || '';
      const commentID = candidateID.replace(/^comment-/, '');
      const likeLabel = text(own(node, '.like .count, .like-wrapper .count, .like-container .count, .like-count'));
      const item = {key: keys.get(node), comment_id: /^[a-zA-Z0-9_-]{1,80}$/.test(commentID) ? commentID : null,
        parent_key: parentKey, is_reply: !!parent || node.matches('.comment-item-sub, .reply-item') || !!node.closest('.reply-container, .replies'),
        author_display: text(own(node, '.author-wrapper .name, .author .name, .user-name')).slice(0, 100) || null,
        text: original.slice(0, 2000), original_length: original.length, truncated: original.length > 2000,
        like_count: parseCount(likeLabel), like_label: likeLabel.slice(0, 80) || null,
        published_label: text(own(node, '.date, .time')).slice(0, 100) || null};
      if (parentKey && !result.items.some(p => p.key === parentKey)) item.parent_key = null;
      if(media.length){item.media=media;item.content_kind=original?'mixed':'media_only';}
      const length = JSON.stringify(item).length;
      if ((!full && result.items.length >= 50) || size + length > budget) { result.truncated = true; break; }
      result.items.push(item); size += length;
      result.truncated ||= item.truncated;
    }
    result.captured_count = result.items.length;
    result.omitted_count = nodes.length - result.items.length;
    result.identity_uncertain=result.items.some(item=>!item.comment_id);
    const capturedIDs=new Set(result.items.map(item=>item.comment_id));
    result.dom_census.skipped_count=result.omitted_count;
    result.dom_census.duplicate_count=result.items.length-capturedIDs.size;
    const box = commentScroller(panel), bounds = panel.getBoundingClientRect();
    const viewport = box === window ? {top:0,bottom:innerHeight} : box.getBoundingClientRect();
    const scroll = box === window ? document.scrollingElement : box;
    const roots=[...panel.querySelectorAll('.parent-comment > .comment-item')];
    const replyGroups=[...panel.querySelectorAll('.parent-comment')].map(group=>{
      const root=group.querySelector(selector),label=text(root?.querySelector('.reply .count'));
      const declared=/^\d+$/.test(label)?Number(label):label==='回复'?0:null;
      const loaded=[...group.querySelectorAll(selector)].filter(node=>node!==root && visible(node)).length;
      return {root,declared,loaded,expand:!!expandControl(group)};
    }).filter(group=>visible(group.root));
    result.reply_coverage={root_count:replyGroups.length,declared_count:replyGroups.every(group=>group.declared!==null)?replyGroups.reduce((n,group)=>n+group.declared,0):null,
      loaded_count:replyGroups.reduce((n,group)=>n+group.loaded,0),pending_groups:replyGroups.filter(group=>group.declared!==null && group.loaded<group.declared).length,
      loading_groups:replyGroups.filter(group=>group.declared!==null && group.loaded<group.declared && !group.expand).length};
    // Reply controls disappear during their request; their declared count still exposes unfinished loading.
    result.loading ||= result.reply_coverage.loading_groups>0;
    const lastRoot=roots[roots.length-1],lastBounds=lastRoot?.getBoundingClientRect();
    result.progress = {top:Math.round(scroll.scrollTop),height:scroll.scrollHeight,client:scroll.clientHeight,
      page_visible:!document.hidden,last_root_comment_id:lastRoot?.id||null,last_root_vertical_percent:lastBounds?.height?Math.round(Math.max(0,Math.min(lastBounds.bottom,viewport.bottom)-Math.max(lastBounds.top,viewport.top))/lastBounds.height*100):null,
      at_end:scroll.scrollTop+scroll.clientHeight>=scroll.scrollHeight-3 && bounds.bottom<=viewport.bottom+3,
      end_marker:!![...panel.querySelectorAll('.end-container')].find(el=>visible(el)&&/^-?\s*THE END\s*-?$/i.test(text(el))),
      expand_count:[...panel.querySelectorAll('.show-more, .show-more-container, .load-more, .more-replies, button')].filter(el=>visible(el)&&/^(?:展开(?:更多)?|查看更多|加载更多)\s*(?:\d+\s*条)?\s*(?:回复|评论)/.test(text(el))).length,
      empty:!![...panel.querySelectorAll('.empty-container,.empty-comment,.no-comment,.no-comments')].find(el=>visible(el)&&/荒地|暂无评论|没有评论/.test(text(el)))};
    for (const item of result.items) item.parent_comment_id = result.items.find(parent=>parent.key===item.parent_key)?.comment_id || null;
    result.dom_census.unresolved_parent_count=result.items.filter(item=>item.is_reply && (!item.parent_comment_id || !capturedIDs.has(item.parent_comment_id))).length;
    return result;
  }
  function note() {
    let identity;
    try { identity = platform.noteURL(location.href); } catch (_) { return {ready: false}; }
    const body = noteBody();
    const original = text(body);
    const title = text(postFirst('#detail-title, .note-content .title, .note-detail .title, .note-container .title, #noteContainer .title')).slice(0, 300);
    const media = [...noteScope().querySelectorAll('.note-slider img, .note-content img, .note-video video, video')].some(visible);
    if (!original && !title && !media) return {ready: false};
    const raw = original.slice(0, 24000);
    const date = text(postFirst('.note-content .date, .note-detail .date, .note-container .date')) || null;
    const dateISO = date?.match(/\b(20\d{2}-\d{2}-\d{2})\b/);
    const hashtags = [...new Set([...raw.matchAll(/#([^\s#]{1,60})/g)].map(m => m[1]))];
    const metricSelectors = {
      like_count: '.interact-container .like-wrapper .count',
      collect_count: '.interact-container .collect-wrapper .count',
      comment_count: '.interact-container .chat-wrapper .count',
      view_count: '.interact-container .view-wrapper .count, .interact-container .read-wrapper .count, .note-detail .view-count, .note-container .view-count, #noteContainer .view-count, .note-detail .read-count, .note-container .read-count'
    };
    const metricLabels = Object.fromEntries(Object.entries(metricSelectors).map(([key, selectors]) => {
      let node = postFirst(selectors);
      if (!node) {
        // Some layouts render one detached interaction bar beside the detail.
        const detached = [...document.querySelectorAll(selectors)].filter(el => visible(el) && !el.closest('.comment-item, .comments-container, .note-item, .note-detail, .note-container, #noteContainer'));
        if (detached.length === 1) node = detached[0];
      }
      return [key, text(node).slice(0, 80) || null];
    }));
    const authorLink = postFirst('.author-wrapper a[href*="/user/profile/"], .author a[href*="/user/profile/"]');
    let author = null;
    try { const p = platform.profileURL(authorLink?.href); author = {id: p.id, url: p.url}; } catch (_) {}
    const record = {schema_version: 4,
      standard: {platform: platform.id, note_id: identity.id, url: identity.url, title,
        captured_at: new Date().toISOString(), published_at: dateISO ? dateISO[1] : null,
        author_display: text(postFirst('.author-wrapper .username, .author-wrapper .name, .author .name, .author .username')).slice(0, 100) || null,
        ...Object.fromEntries(Object.entries(metricLabels).map(([key, label]) => [key, parseCount(label || '')]))},
      extra: {author, media_present: media, field_observations: Object.fromEntries(Object.entries(metricLabels).map(([key,label]) => [key, metric(label)])), hashtags, published_label: date, metric_labels: metricLabels, author_opinion_quotes: raw.split(/\n+/).filter(x => /好吃|难吃|推荐|踩雷|鲜|咸|甜|辣|油腻|服务|排队|价格/.test(x)).slice(0, 30)},
      evidence: {text: raw, original_length: original.length, truncated: original.length > raw.length,
        selector: body ? (body.id ? '#' + body.id : '.' + String(body.className).trim().replace(/\s+/g, '.')) : null,
        parser_version: C.VERSION, source: 'rendered_public_dom'}};
    record.extra.comments = comments(record);
    return {ready: true, record, author_navigation: author ? authorLink.href : null};
  }
  let observed = null;
  function readyNote() {
    const page = note();
    if (!page.ready || document.readyState === 'loading') return {ready:false, reason:'body_pending'};
    const scope = noteScope(), body = noteBody();
    const loading = [...scope.querySelectorAll('[aria-busy="true"], .loading, .skeleton')].some(ownPost);
    const collapsed = [...scope.querySelectorAll('[aria-expanded="false"], .show-more, .expand-text')].some(el => ownPost(el) && /全文|展开|更多/.test(text(el)));
    const style = body && getComputedStyle(body);
    const clipped = body && body.scrollHeight > body.clientHeight+2 &&
      (/hidden|clip/.test(style.overflowY) || Number.parseInt(style.webkitLineClamp)>0);
    const declared = scope.getAttribute?.('data-note-id');
    if (declared && declared !== page.record.standard.note_id) return {ready:false, reason:'body_pending'};
    // A title alone can precede the body. An explicit body node or loaded media
    // distinguishes an empty-body post from a detail which has not rendered yet.
    const loadedMedia = [...scope.querySelectorAll('.note-slider img, .note-content img, .note-video video, video')].some(el => visible(el) &&
      (el.tagName === 'IMG' ? el.complete && el.naturalWidth>0 : el.readyState>=1));
    if (loading || collapsed || clipped || (!page.record.evidence.text && !loadedMedia)) return {ready:false, reason:'body_pending'};
    const fingerprint = JSON.stringify([page.record.standard.note_id,page.record.standard.title,page.record.evidence.text,!!body,page.record.extra.media_present,declared]);
    const now = Date.now();
    if (!observed || observed.fingerprint !== fingerprint || observed.scope !== scope) {
      // A same-document route which still shows the old body is not a new note.
      const stale = observed && (observed.stale || observed.id !== page.record.standard.note_id) &&
        observed.body === page.record.evidence.text && declared !== page.record.standard.note_id;
      observed = {fingerprint,scope,id:page.record.standard.note_id,body:page.record.evidence.text,at:now,stale};
    }
    if (observed.stale || now-observed.at < 300) return {ready:false, reason:'body_pending'};
    page.record.extra.body_observation = {status:page.record.evidence.text ? 'rendered_stable' : 'empty_body',loading:false,collapsed:false};
    return page;
  }
  function probe(action, boundWork = false) {
    // Opt-in diagnostics use categories/counts, never page text or navigation tokens.
    if (action === 'diagnostics') return {ready: true, page: {
      kind: /^\/search_result\/?$/.test(location.pathname) ? 'search' : /^\/(explore|discovery\/item|search_result)\/[a-f0-9]{24}\/?$/i.test(location.pathname) ? 'note' : 'other',
      document: document.readyState, gate: gate(), links: Math.min(noteLinks().length, 500),
      body_chars: Math.min(text(noteBody()).length, 24000), visible: !document.hidden,
      search_note_links: Math.min([...document.querySelectorAll('a[href*="/search_result/"]')].filter(visible).length, 500)
    }};
    const blocked = gate(); if (blocked) return {ready: false, gate: blocked};
    if (action === 'note_ready') return readyNote();
    if (action === 'profile') return profile();
    if (action === 'comment_read') {const page=note();if(page.ready)page.record.extra.comments=comments(page.record,true);return page;}
    if (action === 'comments') {
      try { platform.noteURL(location.href); } catch (_) { return {ready: false}; }
      const panel = commentPanel(), expand = expandControl(panel);
      const pendingImage=[...(panel?.querySelectorAll('img.note-content-emoji, .img-box img.inner')||[])].find(img=>visible(img) && visible(img.closest('.comment-item, .comment-inner-container')) && !commentImage(img) && (!img.src || /^(?:data:|blob:)/.test(img.src)));
      if(pendingImage){pendingImage.scrollIntoView({block:'center',behavior:'instant'});return {ready:true};}
      if(boundWork&&panel&&!expand&&document.hidden){
        const box=commentScroller(panel),scroll=box===window?document.scrollingElement:box;
        const ended=[...panel.querySelectorAll('.end-container')].some(el=>visible(el)&&/^-?\s*THE END\s*-?$/i.test(text(el)));
        const page=note(),captured=page.ready?comments(page.record,true):null;
        const complete=Number.isInteger(page.record?.standard.comment_count)&&captured?.captured_count===page.record.standard.comment_count&&!captured.truncated;
        if(scroll.scrollTop+scroll.clientHeight>=scroll.scrollHeight-3&&!ended&&!complete)return {ready:true,needs_visible_page:true};
      }
      if (expand) { expand.scrollIntoView({block: 'center',behavior:'instant'}); expand.click(); }
      else if (panel) {
        const box = commentScroller(panel);
        const viewport = box === window ? {top: 0, bottom: innerHeight} : box.getBoundingClientRect();
        const bounds = panel.getBoundingClientRect();
        if (bounds.top >= viewport.bottom || bounds.bottom <= viewport.top) panel.scrollIntoView({block: 'start',behavior:'instant'});
        // Background tabs can suspend smooth-scroll animation before the pagination threshold.
        else {
          const scroll=box===window?document.scrollingElement:box;
          const atBottom=scroll.scrollTop+scroll.clientHeight>=scroll.scrollHeight-3;
          const ended=[...panel.querySelectorAll('.end-container')].some(el=>visible(el)&&/^-?\s*THE END\s*-?$/i.test(text(el)));
          // A clamped scroll does not trigger the next page; return upward in this admitted action, downward in the next.
          if(atBottom&&!ended)box.scrollBy({top:-Math.round((box===window?innerHeight:box.clientHeight)*.2),behavior:'instant'});
          else box.scrollTo({top:scroll.scrollHeight,behavior:'instant'});
        }
      }
      else (first('.note-scroller, .note-detail .scroll-container') || window).scrollBy({top: Math.round(innerHeight * .8), behavior: 'instant'});
      return {ready: true};
    }
    if (action === 'scroll') {
      const box = first('.note-scroller, .note-detail .scroll-container');
      (box || window).scrollBy({top: Math.round(innerHeight * C.between(35, 65) / 100), behavior: 'smooth'});
      return {ready: true};
    }
    if (action === 'search') {
      const links = noteLinks().map(a => a.href);
      const keyword = /^\/search_result\/?$/.test(location.pathname) ? new URL(location.href).searchParams.get('keyword') : null;
      return {ready: links.length > 0 || !!first('.search-empty, .empty-page, .no-result'), links, cards: cards(), keyword};
    }
    return note();
  }
  // The browser/native transport only needs this uniform page-probe contract.
  function hybridProbe(action,boundWork=false){const page=probe(action,boundWork);if(page.ready&&page.record){const value=hybrid?.snapshot(page.record.standard.note_id,page.record,workDocument);if(value){page.structured=value;if(value.gate)return {ready:false,gate:value.gate};}}return page;}
  root.CrowdPage = {platform: platform.id, capabilities: platform.capabilities, probe:hybridProbe};
  if (typeof chrome !== 'undefined' && chrome.runtime?.onMessage) {
    workDocument=crypto.randomUUID();
    chrome.runtime.onMessage.addListener((message, sender, reply) => {
      if (sender.id !== chrome.runtime.id) return;
      if (message.type === 'crowd_bind') {workToken=message.token;hybrid?.bind(workToken);reply({bound:true,document:workDocument});return;}
      if (message.type !== 'crowd_probe') return;
      if (message.action === 'ownership') {reply({token:workToken,document:workDocument});return;}
      try { reply(hybridProbe(message.action,!!workToken)); } catch (e) { reply({ready: false, error: e.message}); }
    });
    // Register at document_start: a parser-blocking script must not hide an
    // already rendered search or gate from the worker. Probes decide readiness.
    let timer, observer;
    const notifyUntil = Date.now()+180000;
    const notify = () => {
      let target = null;
      try { target = platform.noteURL(location.href).id; } catch (_) {}
      if (target && !gate() && !readyNote().ready) {
        if (Date.now()<notifyUntil) {clearTimeout(timer);timer=setTimeout(notify,350);}
        return;
      }
      chrome.runtime.sendMessage({type:'page_ready',token:workToken, target, keyword:target ? null : new URL(location.href).searchParams.get('keyword')}).catch(() => {});
    };
    const changed = () => { clearTimeout(timer); timer = setTimeout(notify, 350); };
    notify();
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', changed, {once:true});
    changed();
    observer = new MutationObserver(changed);
    observer.observe(document, {childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:['class','aria-busy','aria-expanded','data-note-id']});
    setTimeout(() => {observer.disconnect(); clearTimeout(timer);},180000);
  }
})(globalThis);
